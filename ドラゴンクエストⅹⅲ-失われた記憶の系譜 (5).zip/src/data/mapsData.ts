import { MapData } from '../types/game';

// Tile Legend:
// 0: Grass / Ground (walkable)
// 1: Cobblestone Path (walkable)
// 2: Water (blocked)
// 3: Mountain (blocked)
// 4: Wall / Building / Tree (blocked)
// 5: Church Altar (interactive save)
// 6: Pedestal (interactive tablet stone)
// 7: Gate / Warp / Door (interactive warp)
// 8: Inn Bed (interactive rest)
// 9: Tavern Counter (Luida's pub)

export const MAPS: Record<string, MapData> = {
  // 1. ココヤしの村 (Kokoya Village)
  kokoya_village: {
    id: 'kokoya_village',
    name: 'ココヤしの村',
    bgm: 'village',
    battleBackground: 'town',
    width: 14,
    height: 12,
    tiles: [
      [4, 4, 4, 4, 4, 7, 7, 4, 4, 4, 4, 4, 4, 4],
      [4, 0, 0, 0, 4, 1, 1, 4, 0, 0, 0, 0, 0, 4],
      [4, 0, 4, 0, 4, 1, 1, 4, 0, 4, 4, 4, 0, 4], // House Left (Elina's), House Right (Church)
      [4, 0, 0, 0, 1, 1, 1, 1, 0, 4, 5, 4, 0, 4],
      [4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4], // Main street
      [4, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 4], // Pond
      [4, 0, 9, 9, 1, 2, 2, 1, 4, 4, 8, 4, 0, 4], // (2,6)-(3,6): Luida's Tavern! Inn at (10,6)
      [4, 0, 0, 0, 1, 1, 1, 1, 4, 4, 0, 4, 0, 4],
      [4, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 4],
      [4, 0, 4, 0, 1, 1, 1, 1, 0, 4, 0, 0, 0, 4],
      [4, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 4],
      [4, 4, 4, 4, 7, 7, 7, 7, 4, 4, 4, 4, 4, 4],
    ],
    npcs: [
      {
        id: 'luida',
        x: 2,
        y: 6,
        name: 'ルイーダ',
        role: '酒場の女主人',
        sprite: '🍷',
        dialogueBefore: [
          '「いらっしゃい！ ここは ルイーダの酒場よ。」',
          '「仲間と出会い、別れる場所……新しい冒険者を登録したり、パーティを編成できるわ！」',
        ],
        dialogueAfter: [
          '「どんな仲間と旅をするかも勇者の腕の見せ所よ。いつでも声をかけてね！」',
        ],
        questTrigger: 'open_tavern',
      },
      {
        id: 'elina',
        x: 2,
        y: 3,
        name: 'エリーナ',
        role: '幼馴染の少女',
        sprite: '👧',
        dialogueBefore: [
          '「あっ、来てくれたんだね！ 今日もいい天気……」',
          '「……ねえ、なんだか最近、胸の奥がチクチク痛むの。」',
          '「悲しいことなんて何もないはずなのに、大切な何かを忘れてしまっているような……」',
          '「キャッ……！？ なにこれ……身体から黒いモヤが……！」',
          '（エリーナの身体が　黒い影となって　空間へと溶けて消えてしまった……！）',
        ],
        dialogueAfter: [
          '（エリーナのいた場所には、かすかな花の香りが残されているだけだ……）',
        ],
        questTrigger: 'elina_disappear',
      },
      {
        id: 'kokoya_father',
        x: 10,
        y: 3,
        name: '神父',
        role: '教会の神父',
        sprite: '🧙‍♂️',
        dialogueBefore: [
          '「おお　神よ！ 我らを導きし12人の聖職者に祈りを捧げましょう。」',
          '「つらい事や悲しい記憶があれば、いつでも神の奇跡によって清らかな無へと還してさしあげますよ。」',
          '「冒険の書に　記録（セーブ）してまいりますか？」',
        ],
        dialogueAfter: [
          '「……神の奇跡が、人を黒い影に変えていたと……？ バカな、12人の教えが過ちだったというのか……！」',
        ],
      },
      {
        id: 'kokoya_inn',
        x: 9,
        y: 7,
        name: '宿屋の女将',
        role: '宿屋',
        sprite: '👩',
        dialogueBefore: [
          '「旅の若者かい？ ぐっすり眠れば HPとMPが全回復するよ！ 泊まっていくかい？」',
        ],
        dialogueAfter: [
          '「いつでも休んでおくれ！ あなたが無事でいてくれることが村の希望だよ。」',
        ],
      },
      {
        id: 'kokoya_elder',
        x: 8,
        y: 8,
        name: '村の長老',
        role: '長老',
        sprite: '👴',
        dialogueBefore: [
          '「……おや？ 若者よ、その胸に小さな違和感を抱いておるな。」',
          '「エリーナという娘？ ふぉふぉ、そんな娘はこの村には一度もおらんかったぞい。」',
          '「……だが、お前が嘘をついておるようには見えん。北の裏山にある『古びた台座』を調べてみるのじゃ。」',
        ],
        dialogueAfter: [
          '「お前さんが世界の記憶を取り戻してくれることを信じておるぞ！」',
        ],
      },
      {
        id: 'kokoya_villager',
        x: 2,
        y: 8,
        name: '村人トム',
        role: '村人',
        sprite: '👨',
        dialogueBefore: [
          '「教会で嫌な記憶を消してもらったら、毎日がすっごく気楽だよ！ 悩みなんてひとつもないね！」',
        ],
        dialogueAfter: [
          '「悲しいことにも意味があったんだな……。消し去るだけじゃ、人間じゃなくなっちまう。」',
        ],
      },
    ],
    chests: [
      { id: 'chest_k1', x: 1, y: 1, item: 'yakusou', opened: false },
      { id: 'chest_k2', x: 12, y: 1, item: 'seisui', gold: 30, opened: false },
    ],
    warps: [
      { x: 5, y: 0, targetMap: 'kokoya_hill', targetX: 6, targetY: 9 },
      { x: 6, y: 0, targetMap: 'kokoya_hill', targetX: 7, targetY: 9 },
      { x: 5, y: 11, targetMap: 'world_map', targetX: 3, targetY: 10 },
      { x: 6, y: 11, targetMap: 'world_map', targetX: 3, targetY: 10 },
    ],
  },

  // 2. ココヤの裏山・古びた台座 (Ancient Pedestal)
  kokoya_hill: {
    id: 'kokoya_hill',
    name: 'ココヤの裏山・古びた台座',
    bgm: 'dungeon',
    battleBackground: 'plains',
    width: 14,
    height: 11,
    tiles: [
      [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
      [3, 0, 0, 0, 0, 4, 6, 6, 4, 0, 0, 0, 0, 3],
      [3, 0, 1, 1, 0, 4, 1, 1, 4, 0, 1, 1, 0, 3],
      [3, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 3],
      [3, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 3],
      [3, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 3],
      [3, 3, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 3, 3],
      [3, 3, 3, 0, 0, 0, 1, 1, 0, 0, 0, 3, 3, 3],
      [3, 3, 3, 3, 0, 0, 1, 1, 0, 0, 3, 3, 3, 3],
      [3, 3, 3, 3, 3, 3, 7, 7, 3, 3, 3, 3, 3, 3],
      [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
    ],
    npcs: [
      {
        id: 'pedestal_spirit',
        x: 6,
        y: 2,
        name: '台座の導き',
        role: '古代の残思',
        sprite: '✨',
        dialogueBefore: [
          '「……聞こえますか、記憶を失わぬ若者よ。」',
          '「ここにある【記憶の石版・青】に触れなさい。」',
          '「お前の胸にある小さな違和感こそが、この世界を偽りの平和から救う光となるであろう……」',
        ],
        dialogueAfter: [
          '「石版が目覚めた！ さあ、広大なる世界へ旅立ち、失われた真実を解き明かすのです！」',
        ],
        questTrigger: 'pedestal_activate',
      },
    ],
    symbolMonsters: [
      { type: 'slime', x: 3, y: 4 },
      { type: 'dracky', x: 10, y: 4 },
    ],
    chests: [
      { id: 'chest_h1', x: 2, y: 1, item: 'dounotsurugi', opened: false },
      { id: 'chest_h2', x: 11, y: 1, item: 'jouyakusou', opened: false },
    ],
    warps: [
      { x: 6, y: 9, targetMap: 'kokoya_village', targetX: 5, targetY: 1 },
      { x: 7, y: 9, targetMap: 'kokoya_village', targetX: 6, targetY: 1 },
    ],
  },

  // 3. フィールド (Overworld)
  world_map: {
    id: 'world_map',
    name: '広大なるフィールド',
    bgm: 'field',
    battleBackground: 'plains',
    width: 18,
    height: 14,
    tiles: [
      [3, 3, 3, 3, 3, 7, 7, 3, 3, 3, 3, 3, 3, 7, 7, 3, 3, 3],
      [3, 0, 0, 0, 1, 1, 1, 1, 0, 0, 3, 3, 4, 1, 1, 4, 3, 3],
      [3, 0, 4, 0, 1, 1, 1, 1, 0, 0, 3, 3, 4, 1, 1, 4, 3, 3],
      [3, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 3],
      [3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 3],
      [3, 7, 7, 4, 1, 1, 1, 0, 0, 0, 0, 4, 7, 7, 4, 0, 0, 3],
      [3, 4, 4, 4, 0, 0, 1, 1, 1, 1, 1, 4, 4, 4, 4, 0, 0, 3],
      [3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 3],
      [3, 0, 2, 2, 2, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 3],
      [3, 0, 2, 2, 2, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 3],
      [3, 0, 0, 7, 7, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3],
      [3, 0, 0, 4, 4, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3],
      [3, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3],
      [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
    ],
    symbolMonsters: [
      { type: 'slime', x: 5, y: 8 },
      { type: 'dracky', x: 8, y: 7 },
      { type: 'ghost', x: 8, y: 3 },
      { type: 'magician', x: 14, y: 4 },
      { type: 'skeleton', x: 10, y: 2 },
    ],
    npcs: [
      {
        id: 'traveler_field',
        x: 7,
        y: 4,
        name: '旅の詩人',
        role: '吟遊詩人',
        sprite: '🧝',
        dialogueBefore: [
          '「西には恋の記憶を捨てた街【バーレン】……東には不敗を誇る【ガルガルド城】……」',
          '「そして北には12人の聖職者を統べる【グランゼイル王都】があります。」',
          '「記憶を奪われた世界は、まるで静かに眠る人形劇のようだ……」',
        ],
        dialogueAfter: [
          '「あなたの戦いが、風となって世界を揺り動かしているのが分かります！」',
        ],
      },
    ],
    chests: [
      { id: 'chest_w1', x: 10, y: 1, item: 'hagane', gold: 120, opened: false },
      { id: 'chest_w2', x: 16, y: 4, item: 'sekaiju', opened: false },
    ],
    warps: [
      { x: 3, y: 10, targetMap: 'kokoya_village', targetX: 5, targetY: 10 },
      { x: 4, y: 10, targetMap: 'kokoya_village', targetX: 6, targetY: 10 },
      { x: 1, y: 5, targetMap: 'town_baren', targetX: 12, targetY: 6 },
      { x: 2, y: 5, targetMap: 'town_baren', targetX: 12, targetY: 6 },
      { x: 12, y: 5, targetMap: 'castle_galgard', targetX: 2, targetY: 6 },
      { x: 13, y: 5, targetMap: 'castle_galgard', targetX: 2, targetY: 6 },
      { x: 5, y: 0, targetMap: 'cathedral_grandzeil', targetX: 6, targetY: 9 },
      { x: 6, y: 0, targetMap: 'cathedral_grandzeil', targetX: 7, targetY: 9 },
      { x: 13, y: 0, targetMap: 'demon_castle_f1', targetX: 9, targetY: 14 },
      { x: 14, y: 0, targetMap: 'demon_castle_f1', targetX: 10, targetY: 14 },
    ],
  },

  // 4. 悲恋の街バーレン (Town of Tragic Romance)
  town_baren: {
    id: 'town_baren',
    name: '悲恋の街バーレン',
    bgm: 'village',
    battleBackground: 'town',
    width: 14,
    height: 12,
    tiles: [
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
      [4, 0, 4, 4, 0, 0, 4, 4, 0, 4, 5, 4, 0, 4],
      [4, 0, 4, 4, 0, 0, 4, 4, 0, 4, 0, 4, 0, 4],
      [4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4],
      [4, 1, 0, 0, 1, 2, 2, 1, 0, 0, 1, 0, 1, 4],
      [4, 1, 0, 0, 1, 2, 2, 1, 0, 0, 1, 0, 1, 4],
      [4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 7, 4],
      [4, 1, 4, 4, 1, 0, 0, 1, 4, 8, 4, 1, 7, 4],
      [4, 0, 4, 4, 1, 0, 0, 1, 4, 0, 4, 0, 0, 4],
      [4, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 4],
      [4, 0, 0, 0, 0, 6, 6, 0, 0, 0, 0, 0, 0, 4],
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
    ],
    npcs: [
      {
        id: 'baren_leon',
        x: 4,
        y: 4,
        name: '青年レオン',
        role: '悲恋の青年',
        sprite: '👦',
        dialogueBefore: [
          '「……カレンという娘の顔を見ても、何も感じないんだ。」',
          '「失恋の激痛に耐えかねて、教会に恋の記憶を消してもらったはずなのに……」',
          '「なぜか胸がポッカリ空洞になって、笑うことすらできなくなってしまった……」',
        ],
        dialogueAfter: [
          '「思い出したんだ！ あのとき感じた痛みも、全部カレンを本気で愛した証だったんだ！」',
          '「もう二度と、大切な想いから逃げたりしないよ！」',
        ],
      },
      {
        id: 'baren_karen',
        x: 7,
        y: 4,
        name: '娘カレン',
        role: '悲恋の乙女',
        sprite: '👧',
        dialogueBefore: [
          '「恋なんて無駄な感情ですわ。教会に捧げてしまえば、失恋の涙なんて流さずに済みますもの。」',
          '「……でも、どうしてかしら。時々、理由もなく涙が頬を伝うの……」',
        ],
        dialogueAfter: [
          '「レオン……！ 私たち、すれ違って傷つくのが怖かっただけなのね。」',
          '「これからは辛い日も二人で乗り越えていくわ。旅の勇者様、ありがとう！」',
        ],
      },
      {
        id: 'baren_event_altar',
        x: 5,
        y: 9,
        name: '記憶の泉の石碑',
        role: '心の祭壇',
        sprite: '🔮',
        dialogueBefore: [
          '（石碑には街の人々が教会に捧げた『失恋の悲哀』が黒い澱みとなって渦巻いている……！）',
          '（【記憶の石版・青】をかざすと、封じられた想いが激しく共鳴を始めた！）',
          '「オオオオ……！ 忘レタイ……忘レタクナイ……！」',
          '（人々の悲哀が凝縮し【心の魔物：悲愛の魔獣】が実体化した！！）',
        ],
        dialogueAfter: [
          '（泉には清らかな水が戻り、底から【記憶の石版・赤】が輝き出た！）',
        ],
        questTrigger: 'baren_boss_fight',
      },
      {
        id: 'baren_jansen_npc',
        x: 2,
        y: 6,
        name: 'ヤンセン',
        role: '元王宮戦士',
        sprite: '🤺',
        dialogueBefore: [
          '「ようアンちゃん！ 人の記憶を消すなんざ、教会もろくなことしねえな。」',
          '「実は俺もよ……かつて背中を預け合った戦友がいたはずなんだが、顔も名前も思い出せねえんだ。」',
          '「もしその怪物を倒して記憶を戻せるなら、見物させてもらうぜ！」',
        ],
        dialogueAfter: [
          '「すげえじゃねえかアンちゃん！ 痛みを乗り越えた二人の笑顔、最高だぜ。」',
          '「俺の失われた戦友の記憶も、お前となら取り戻せるかもしれねえ。俺も旅に連れてってくれ！」',
          '（元王宮戦士ヤンセンが　仲間に加わった！）',
        ],
        questTrigger: 'jansen_join',
      },
    ],
    chests: [
      { id: 'chest_b1', x: 1, y: 1, item: 'jouyakusou', opened: false },
      { id: 'chest_b2', x: 12, y: 1, item: 'haganenoyoroi', opened: false },
    ],
    warps: [
      { x: 12, y: 6, targetMap: 'world_map', targetX: 2, targetY: 5 },
    ],
  },

  // 5. 偽りの英雄の城ガルガルド (Castle of False Hero Galgard)
  castle_galgard: {
    id: 'castle_galgard',
    name: '偽りの英雄の城ガルガルド',
    bgm: 'village',
    battleBackground: 'castle',
    width: 14,
    height: 12,
    tiles: [
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
      [4, 0, 4, 4, 4, 1, 1, 1, 4, 4, 4, 5, 0, 4],
      [4, 0, 4, 1, 1, 1, 1, 1, 1, 1, 4, 0, 0, 4],
      [4, 0, 4, 1, 0, 0, 0, 0, 0, 1, 4, 0, 0, 4],
      [4, 0, 1, 1, 0, 4, 4, 4, 0, 1, 1, 0, 0, 4],
      [4, 1, 1, 0, 0, 4, 6, 4, 0, 0, 1, 1, 0, 4],
      [4, 7, 1, 0, 0, 4, 0, 4, 0, 0, 0, 1, 0, 4],
      [4, 7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 4],
      [4, 0, 4, 4, 1, 0, 0, 0, 0, 4, 8, 4, 0, 4],
      [4, 0, 4, 4, 1, 1, 1, 1, 1, 4, 0, 4, 0, 4],
      [4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4],
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
    ],
    npcs: [
      {
        id: 'king_arthur',
        x: 6,
        y: 4,
        name: '国王アーサー',
        role: '偽りの英雄王',
        sprite: '👑',
        dialogueBefore: [
          '「ガハハハ！ 遠路はるばるよく参った！ 我がガルガルドは不敗の軍事大国であるぞ！」',
          '「魔物など指先一つで一掃よ！ 国境に迫る軍勢？ はて、そんな噂は聞いたこともないわい！」',
          '「さあ歌え！ 踊れ！ 栄光に包まれた我が国の永遠の平和を祝うのじゃ！」',
        ],
        dialogueAfter: [
          '「余は……大敗の屈辱と恐怖から逃げ、兵たちの尊い犠牲の記憶を消していた……」',
          '「許してくれ、我が民よ！ 今こそ過ちを認め、余自ら先頭に立って国を守り抜くぞ！」',
        ],
      },
      {
        id: 'galgard_general',
        x: 8,
        y: 4,
        name: '近衛隊長',
        role: '城の将軍',
        sprite: '🛡️',
        dialogueBefore: [
          '「……王は先日の大戦で大敗したショックから教会に頼み、敗北の記憶を消されたのだ。」',
          '「しかし現実の魔物軍はすぐそこまで迫っている……！ このままでは城が滅びてしまう！」',
        ],
        dialogueAfter: [
          '「王の瞳に真の覇気が戻られた！ 全軍、直ちに迎撃態勢を整えよ！」',
        ],
      },
      {
        id: 'galgard_event_altar',
        x: 6,
        y: 6,
        name: '王座の真実の鏡',
        role: '封印の鏡',
        sprite: '🪞',
        dialogueBefore: [
          '（王座の裏に、国王が捨て去った『敗北の屈辱と虚飾の記憶』が封じられている……！）',
          '（【記憶の石版・赤】を掲げると、鏡が真実を映し出し、強大な魔気が吹き荒れた！）',
          '「我が栄光を曇らせる者は許さん……！ 余こそが不敗の英雄王なのだァァ！！」',
          '（虚飾が実体化し【心の魔物：虚飾の魔神】が立ちはだかった！！）',
        ],
        dialogueAfter: [
          '（鏡は真実を映す穏やかな水晶となり、台座から【記憶の石版・黄】が現れた！）',
        ],
        questTrigger: 'galgard_boss_fight',
      },
      {
        id: 'sierra_npc',
        x: 4,
        y: 7,
        name: 'シエラ',
        role: '追放されし魔導士',
        sprite: '🧙‍♀️',
        dialogueBefore: [
          '「教会の教えは甘い毒ですわ。記憶を消せば一時の安らぎは得られますが、現実の危機は消えません。」',
          '「世界の歴史の裏に葬られた『13番目の真実』……あなた方となら辿り着ける気がします。」',
        ],
        dialogueAfter: [
          '「見事でしたわ！ 虚飾を打ち破ったあなたの強さ、まさに探していた光です。」',
          '「私も大聖堂の秘密を暴くため、共に参ります！ 魔法の力でお力添えいたしますわ。」',
          '（追放されし魔導士シエラが　仲間に加わった！）',
        ],
        questTrigger: 'sierra_join',
      },
    ],
    chests: [
      { id: 'chest_g1', x: 1, y: 1, item: 'seisui', gold: 200, opened: false },
      { id: 'chest_g2', x: 12, y: 3, item: 'sekaiju', opened: false },
    ],
    warps: [
      { x: 1, y: 6, targetMap: 'world_map', targetX: 13, targetY: 5 },
    ],
  },

  // 6. グランゼイル大聖堂 (Grandzeil Holy Cathedral)
  cathedral_grandzeil: {
    id: 'cathedral_grandzeil',
    name: 'グランゼイル大聖堂・王都',
    bgm: 'dungeon',
    battleBackground: 'dark_abyss',
    width: 14,
    height: 11,
    tiles: [
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
      [4, 0, 4, 0, 0, 4, 6, 6, 4, 0, 0, 4, 0, 4],
      [4, 0, 4, 0, 0, 4, 1, 1, 4, 0, 0, 4, 0, 4],
      [4, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 4],
      [4, 1, 1, 1, 1, 5, 1, 1, 5, 1, 1, 1, 1, 4],
      [4, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 4],
      [4, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 4],
      [4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4],
      [4, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 4],
      [4, 4, 4, 4, 4, 4, 7, 7, 4, 4, 4, 4, 4, 4],
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
    ],
    npcs: [
      {
        id: 'grandzeil_pope',
        x: 6,
        y: 3,
        name: '大教皇イノケンティウス',
        role: '世界の救済者',
        sprite: '🕊️',
        dialogueBefore: [
          '「……よくぞ辿り着かれました、13番目の勇者の末裔よ。」',
          '「歴史書にある『導かれし12人の聖職者』……あれは民を安心させるための偽りの神話。」',
          '「100年前、大魔王ネビュロスを我が身を挺して封印したのは、あなたのご先祖である【13番目の勇者】だったのです。」',
          '「しかし大魔王の呪縛は不滅。人々の絶望と悲しみを喰らって復活しようとする。」',
          '「ゆえに我らは大聖堂のコアを使い、人々の心から悲しみを消去し続けてきたのだ！」',
          '「……だが、100年分の消去された絶望は、もはやこのコアでも抑えきれぬ……！！」',
        ],
        dialogueAfter: [
          '「おお……世界の空が紫の闇に染まる……！ 大魔王ネビュロスが復活してしまった！」',
          '「頼む、13番目の勇者よ！ 人々の悲しみを受け入れ、それを乗り越える真の強さで大魔王を討ち滅ぼしてくれ！」',
        ],
        questTrigger: 'cathedral_core_break',
      },
      {
        id: 'cathedral_core_object',
        x: 6,
        y: 1,
        name: '記憶の祭壇コア',
        role: '世界の特異点',
        sprite: '🌌',
        dialogueBefore: [
          '（大聖堂の中央で、100年分の消去された記憶が漆黒の結晶となって激しく脈打っている！）',
          '（【記憶の石版・黄】が共鳴した瞬間、コアに亀裂が入り、圧倒的な絶望の波動が世界中へ放たれた！）',
          '「我が名はネビュロス……！ 100年の忘却を破り、今こそ絶望の楽園を創らん！！」',
          '（コアが砕け散り、北東の空に【魔界の城】が出現した！ 手元に【記憶の石版・闇】が残された！）',
        ],
        dialogueAfter: [
          '（砕けたコアから聖なる光が漏れ、魔界の城への転移陣が起動している！）',
        ],
      },
    ],
    chests: [
      { id: 'chest_c1', x: 1, y: 1, item: 'yushaSword', opened: false },
      { id: 'chest_c2', x: 12, y: 1, item: 'sekaiju', opened: false },
    ],
    warps: [
      { x: 6, y: 9, targetMap: 'world_map', targetX: 5, targetY: 1 },
      { x: 7, y: 9, targetMap: 'world_map', targetX: 6, targetY: 1 },
    ],
  },

  // 7. 魔界の城・暗黒の迷宮 1F (Demon Castle 1F)
  demon_castle_f1: {
    id: 'demon_castle_f1',
    name: '魔界の城・暗黒の迷宮',
    bgm: 'dungeon',
    battleBackground: 'dark_abyss',
    width: 20,
    height: 16,
    tiles: [
      [4, 4, 4, 4, 4, 4, 4, 4, 7, 7, 7, 7, 4, 4, 4, 4, 4, 4, 4, 4],
      [4, 0, 0, 0, 4, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 4, 0, 0, 0, 4],
      [4, 0, 4, 0, 4, 0, 4, 0, 1, 1, 1, 1, 0, 4, 0, 4, 0, 4, 0, 4],
      [4, 0, 4, 0, 0, 0, 4, 1, 1, 4, 4, 1, 1, 4, 0, 0, 0, 4, 0, 4],
      [4, 1, 1, 1, 1, 1, 1, 1, 0, 4, 4, 0, 1, 1, 1, 1, 1, 1, 1, 4],
      [4, 1, 4, 4, 4, 4, 4, 1, 0, 0, 0, 0, 1, 4, 4, 4, 4, 4, 1, 4],
      [4, 1, 4, 0, 0, 0, 4, 1, 1, 1, 1, 1, 1, 4, 0, 0, 0, 4, 1, 4],
      [4, 1, 4, 0, 4, 0, 4, 1, 4, 4, 4, 4, 1, 4, 0, 4, 0, 4, 1, 4],
      [4, 1, 1, 1, 4, 1, 1, 1, 4, 0, 0, 4, 1, 1, 1, 4, 1, 1, 1, 4],
      [4, 4, 4, 1, 4, 1, 4, 4, 4, 0, 0, 4, 4, 4, 1, 4, 1, 4, 4, 4],
      [4, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 4],
      [4, 0, 4, 1, 4, 1, 4, 0, 1, 1, 1, 1, 0, 4, 1, 4, 1, 4, 0, 4],
      [4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4],
      [4, 1, 4, 4, 4, 4, 4, 4, 1, 1, 1, 1, 4, 4, 4, 4, 4, 4, 1, 4],
      [4, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 4],
      [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
    ],
    npcs: [
      {
        id: 'corridor_spirit',
        x: 6,
        y: 6,
        name: '封印の英霊',
        role: '古の守護者',
        sprite: '👻',
        dialogueBefore: [
          '「この先は……絶望を支配せし大魔王ネビュロスの玉座……」',
          '「100年の長きにわたり封じられし怨念が渦巻いている……覚悟を決めて進まれよ……！」',
        ],
        dialogueAfter: [
          '「おお、大魔王の気配が消え去った……！ これで世界に本当の朝が訪れる……」',
        ],
      },
    ],
    symbolMonsters: [
      { type: 'shadowDemon', x: 4, y: 4 },
      { type: 'shadowDemon', x: 15, y: 4 },
      { type: 'skeleton', x: 9, y: 6 },
      { type: 'skeleton', x: 5, y: 11 },
      { type: 'magician', x: 14, y: 11 },
    ],
    chests: [
      { id: 'chest_df1_1', x: 2, y: 1, item: 'yushaSword', gold: 500, opened: false },
      { id: 'chest_df1_2', x: 17, y: 1, item: 'sekaiju', opened: false },
    ],
    warps: [
      { x: 8, y: 0, targetMap: 'demon_castle', targetX: 7, targetY: 10 },
      { x: 9, y: 0, targetMap: 'demon_castle', targetX: 8, targetY: 10 },
      { x: 10, y: 0, targetMap: 'demon_castle', targetX: 8, targetY: 10 },
      { x: 11, y: 0, targetMap: 'demon_castle', targetX: 9, targetY: 10 },
      { x: 8, y: 14, targetMap: 'world_map', targetX: 13, targetY: 1 },
      { x: 9, y: 14, targetMap: 'world_map', targetX: 13, targetY: 1 },
      { x: 10, y: 14, targetMap: 'world_map', targetX: 14, targetY: 1 },
      { x: 11, y: 14, targetMap: 'world_map', targetX: 14, targetY: 1 },
    ],
  },

  // 8. 魔界の城・玉座の間 (Demon Castle - Throne Room - Final Boss)
  demon_castle: {
    id: 'demon_castle',
    name: '魔界の城・玉座の間',
    bgm: 'dungeon',
    battleBackground: 'dark_abyss',
    width: 16,
    height: 12,
    tiles: [
      [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
      [3, 4, 4, 4, 4, 4, 6, 6, 6, 6, 4, 4, 4, 4, 4, 3],
      [3, 4, 0, 0, 0, 4, 1, 1, 1, 1, 4, 0, 0, 0, 4, 3],
      [3, 4, 0, 0, 0, 4, 1, 1, 1, 1, 4, 0, 0, 0, 4, 3],
      [3, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 3],
      [3, 4, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 4, 3],
      [3, 4, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 4, 3],
      [3, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 3],
      [3, 4, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 4, 3],
      [3, 4, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 4, 3],
      [3, 3, 3, 3, 3, 3, 7, 7, 7, 7, 3, 3, 3, 3, 3, 3],
      [3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3],
    ],
    symbolMonsters: [
      { type: 'shadowDemon', x: 4, y: 4 },
      { type: 'shadowDemon', x: 11, y: 4 },
      { type: 'skeleton', x: 7, y: 7 },
    ],
    npcs: [
      {
        id: 'final_boss_event',
        x: 7,
        y: 2,
        name: '大魔王ネビュロス',
        role: '絶望の支配者',
        sprite: '👿',
        dialogueBefore: [
          '「クハハハハ……！ 愚かな人間どもよ、よくぞ我が前まで来た。」',
          '「お前たちの先祖が我を封印したつもりでいたが、人間は痛みを恐れ、記憶を捨て去る道を選んだ。」',
          '「人は悲しみを消すたび魂を失い、我が黒い影となる……！ この世界こそが我が理想郷なのだ！」',
          '「さあ、お前たちも全ての記憶を消し去り、永遠の安寧に沈むがよい！！」',
        ],
        dialogueAfter: [
          '（大魔王は消滅し、世界に満ちていた絶望の闇が晴れ渡った……！）',
        ],
        questTrigger: 'final_boss_fight',
      },
    ],
    chests: [
      { id: 'chest_d1', x: 2, y: 2, item: 'sekaiju', opened: false },
      { id: 'chest_d2', x: 13, y: 2, item: 'seisui', opened: false },
    ],
    warps: [
      { x: 6, y: 10, targetMap: 'demon_castle_f1', targetX: 9, targetY: 1 },
      { x: 7, y: 10, targetMap: 'demon_castle_f1', targetX: 9, targetY: 1 },
      { x: 8, y: 10, targetMap: 'demon_castle_f1', targetX: 10, targetY: 1 },
      { x: 9, y: 10, targetMap: 'demon_castle_f1', targetX: 10, targetY: 1 },
    ],
  },
};
