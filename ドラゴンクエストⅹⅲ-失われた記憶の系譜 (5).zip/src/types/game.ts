// Game type definitions for Dragon Quest XIII: Genealogy of the Lost Memories

export interface CharacterAppearance {
  gender: 'male' | 'female';
  hairColor: string;
  outfitColor: string;
  vocation: 'hero' | 'warrior' | 'mage' | 'cleric' | 'martial_artist' | 'thief' | 'sage';
  personality: string;
}

export interface Character {
  id: string; // 'hero' | 'jansen' | 'sierra' | custom id
  name: string;
  title: string;
  role: string;
  level: number;
  hp: number;
  maxHp: number;
  mp: number;
  maxMp: number;
  attack: number;
  defense: number;
  agility: number;
  exp: number;
  nextExp: number;
  spells: Spell[];
  skills: Skill[];
  equipment: {
    weapon: string;
    armor: string;
    shield: string;
    accessory: string;
  };
  status: 'normal' | 'poison' | 'dead';
  appearance?: CharacterAppearance;
}

export interface Spell {
  id: string;
  name: string;
  mpCost: number;
  type: 'damage' | 'heal' | 'buff' | 'debuff';
  target: 'single_enemy' | 'all_enemies' | 'single_ally' | 'all_allies';
  power: number;
  description: string;
}

export interface Skill {
  id: string;
  name: string;
  mpCost: number;
  type: 'physical' | 'special';
  target: 'single_enemy' | 'all_enemies';
  powerMultiplier: number;
  description: string;
}

export interface Item {
  id: string;
  name: string;
  type: 'consumable' | 'weapon' | 'armor' | 'key_item' | 'tablet';
  description: string;
  price: number;
  effectValue?: number;
  statBonus?: {
    attack?: number;
    defense?: number;
    maxHp?: number;
  };
  usableInBattle: boolean;
  usableInField: boolean;
}

export interface Monster {
  id: string;
  name: string;
  hp: number;
  maxHp: number;
  mp: number;
  attack: number;
  defense: number;
  agility: number;
  exp: number;
  gold: number;
  isBoss?: boolean;
  isFinalBoss?: boolean;
  actions: MonsterAction[];
  spriteColor: string;
  scale?: number;
  customImage?: string;
  defeatText?: string;
}

export interface MonsterAction {
  type: 'attack' | 'spell' | 'skill' | 'idle';
  name: string;
  chance: number; // 0 to 1
  power?: number;
  target?: 'single' | 'all';
  message: string;
}

export interface TabletPiece {
  id: string;
  name: string;
  color: 'blue' | 'red' | 'yellow' | 'dark';
  areaName: string;
  found: boolean;
  placed: boolean;
  memoryStory: string;
  unlockedArea: string;
}

export interface NPC {
  id: string;
  x: number;
  y: number;
  name: string;
  role: string;
  sprite: string;
  dialogueBefore: string[];
  dialogueAfter: string[];
  solvedCondition?: 'baren_cleared' | 'galgard_cleared' | 'elina_disappeared' | 'grandzeil_cleared';
  questTrigger?: string;
}

export interface Chest {
  id: string;
  x: number;
  y: number;
  item: string;
  gold?: number;
  opened: boolean;
}

export interface SymbolMonster {
  id: string;
  monsterType: string;
  name: string;
  x: number;
  y: number; // corresponds to 2D grid y / 3D z
  dir: number; // rotation in radians
  state: 'wandering' | 'alert' | 'chasing' | 'cooldown';
  chaseTimer: number; // counts up to 5 seconds
  alertTimer: number; // exclamation mark alert display
  cooldownTimer: number;
  targetX: number;
  targetY: number;
  monsterData: Monster[];
}

export interface MapData {
  id: string;
  name: string;
  bgm: 'village' | 'field' | 'dungeon' | 'ending';
  battleBackground: 'plains' | 'town' | 'castle' | 'dark_abyss';
  width: number;
  height: number;
  tiles: number[][]; // 0: grass, 1: path, 2: water, 3: mountain, 4: wall/tree, 5: church_altar, 6: pedestal, 7: door/entrance, 8: inn, 9: tavern
  npcs: NPC[];
  chests: Chest[];
  symbolMonsters?: {
    type: string;
    x: number;
    y: number;
  }[];
  warps: {
    x: number;
    y: number;
    targetMap: string;
    targetX: number;
    targetY: number;
  }[];
}

export type StoryChapter =
  | 'CH1_KOKOYA_START'
  | 'CH1_PEDESTAL_DISCOVERY'
  | 'CH2_BAREN_ARRIVED'
  | 'CH2_BAREN_BOSS_DEFEATED'
  | 'CH3_GALGARD_ARRIVED'
  | 'CH3_GALGARD_BOSS_DEFEATED'
  | 'CH4_GRANDZEIL_ARRIVED'
  | 'CH4_CORE_SHATTERED'
  | 'CH5_DEMON_CASTLE'
  | 'CH5_ENDING';

export interface GameSaveData {
  heroName: string;
  heroAppearance: CharacterAppearance;
  party: Character[];
  tavernRoster: Character[];
  inventory: { itemId: string; count: number }[];
  gold: number;
  tablets: TabletPiece[];
  storyChapter: StoryChapter;
  currentMapId: string;
  playerPos: { x: number; y: number; dir: 'up' | 'down' | 'left' | 'right' };
  openedChestIds: string[];
  flags: Record<string, boolean>;
  playTimeMinutes: number;
  timestamp: number;
}
