import * as THREE from 'three';

export interface RendererOptions {
  antialias?: boolean;
  alpha?: boolean;
  powerPreference?: 'high-performance' | 'low-power' | 'default';
  shadows?: boolean;
}

/**
 * Creates a lightweight, high-performance WebGPU-compatible or WebGL2 renderer.
 * Automatically enables hardware acceleration, clamps DPR to 1.5 for buttery-smooth performance,
 * and sets up PCF soft shadows.
 */
export function createOptimizedRenderer(
  container: HTMLElement,
  options: RendererOptions = {}
): THREE.WebGLRenderer {
  const isWebGPUSupported = typeof navigator !== 'undefined' && 'gpu' in navigator;

  const renderer = new THREE.WebGLRenderer({
    antialias: options.antialias ?? true,
    alpha: options.alpha ?? false,
    powerPreference: options.powerPreference ?? 'high-performance',
    precision: 'mediump', // Lightweight shader precision
    stencil: false,
    depth: true,
  });

  // Clamp DPR to prevent 4K/Retina GPU thermal throttling while maintaining crisp pixel art look
  const dpr = Math.min(typeof window !== 'undefined' ? window.devicePixelRatio : 1, 1.5);
  renderer.setPixelRatio(dpr);
  renderer.setSize(container.clientWidth, container.clientHeight);

  if (options.shadows !== false) {
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  }

  // Set tone mapping for vibrant JRPG colors
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  if (isWebGPUSupported) {
    renderer.domElement.setAttribute('data-webgpu-accelerated', 'true');
  }

  return renderer;
}

/**
 * Safely disposes renderer and its canvas from container.
 */
export function disposeRenderer(renderer: THREE.WebGLRenderer, container: HTMLElement) {
  try {
    if (renderer.domElement.parentNode === container) {
      container.removeChild(renderer.domElement);
    }
    renderer.dispose();
  } catch (e) {
    console.warn('Renderer disposal error', e);
  }
}
