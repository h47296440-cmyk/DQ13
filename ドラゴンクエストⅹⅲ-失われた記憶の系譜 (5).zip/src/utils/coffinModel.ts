import * as THREE from 'three';

// 3D Dragon Quest Coffin Model Builder
// Recreates the iconic wooden casket with slate iron corner brackets,
// royal purple pall cloth, and holy golden cross on top.
export function createCoffinGroup(): THREE.Group {
  const coffin = new THREE.Group();

  // Materials
  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x78350f, // rich oak brown
    roughness: 0.75,
  });
  const ironMat = new THREE.MeshStandardMaterial({
    color: 0x334155, // dark slate iron
    metalness: 0.8,
    roughness: 0.3,
  });
  const purpleMat = new THREE.MeshStandardMaterial({
    color: 0x7e22ce, // iconic Dragon Quest royal purple pall
    roughness: 0.55,
  });
  const goldCrossMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b, // holy burnished gold
    metalness: 0.8,
    roughness: 0.25,
  });

  // 1. Base casket box (horizontal box lying on the ground)
  // Length: 1.8 (along z), Width: 0.85 (along x), Height: 0.5 (along y)
  const box = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.48, 1.8), woodMat);
  box.position.y = 0.24;
  box.castShadow = true;
  box.receiveShadow = true;
  coffin.add(box);

  // 2. Beveled Lid on top of casket
  const lid = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.12, 1.84), woodMat);
  lid.position.y = 0.52;
  lid.castShadow = true;
  coffin.add(lid);

  // 3. Slate Iron Corner Straps / Bands (Head, Center, and Foot of casket)
  const bandGeo = new THREE.BoxGeometry(0.93, 0.52, 0.14);
  const band1 = new THREE.Mesh(bandGeo, ironMat);
  band1.position.set(0, 0.26, -0.65);
  const band2 = new THREE.Mesh(bandGeo, ironMat);
  band2.position.set(0, 0.26, 0.65);
  coffin.add(band1, band2);

  // 4. Side Metal Handles (for carrying)
  const handleMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.85 });
  [-0.45, 0.45].forEach(xPos => {
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.5, 6), handleMat);
    handle.position.set(xPos, 0.28, 0);
    handle.rotation.x = Math.PI / 2;
    coffin.add(handle);
  });

  // 5. Royal Purple Pall / Cloth draped over the center of the lid
  const drape = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.04, 1.25), purpleMat);
  drape.position.set(0, 0.59, 0);
  coffin.add(drape);

  // 6. Holy Golden Cross mounted on the pall
  // Vertical bar (along z)
  const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.04, 0.85), goldCrossMat);
  crossV.position.set(0, 0.62, -0.05);
  // Horizontal bar (along x)
  const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.14), goldCrossMat);
  crossH.position.set(0, 0.62, -0.22);
  coffin.add(crossV, crossH);

  return coffin;
}

// Flood-fill helper to detect all contiguous/connected warp tiles of an entrance/exit
export function getConnectedWarpZone(
  startX: number,
  startY: number,
  map: { width: number; height: number; tiles: number[][]; warps: Array<{ x: number; y: number }> }
): Set<string> {
  const zone = new Set<string>();
  if (!map || !map.tiles) return zone;

  const isWarpTile = (x: number, y: number): boolean => {
    if (x < 0 || x >= map.width || y < 0 || y >= map.height) return false;
    const tile = map.tiles[y]?.[x];
    const hasWarp = map.warps?.some(w => w.x === x && w.y === y);
    return tile === 7 || !!hasWarp;
  };

  const queue: [number, number][] = [];

  if (isWarpTile(startX, startY)) {
    queue.push([startX, startY]);
    zone.add(`${startX},${startY}`);
  } else {
    // Check 4 adjacent tiles in case landing spot is directly adjacent to warp doorway
    const adjs = [
      [startX, startY - 1],
      [startX, startY + 1],
      [startX - 1, startY],
      [startX + 1, startY],
    ];
    for (const [ax, ay] of adjs) {
      if (isWarpTile(ax, ay) && !zone.has(`${ax},${ay}`)) {
        zone.add(`${ax},${ay}`);
        queue.push([ax, ay]);
      }
    }
  }

  // Flood fill all connected warp tiles in 8 directions (e.g. 2-wide doors, diagonal gates)
  while (queue.length > 0) {
    const [cx, cy] = queue.shift()!;
    const neighbors = [
      [cx + 1, cy],
      [cx - 1, cy],
      [cx, cy + 1],
      [cx, cy - 1],
      [cx + 1, cy + 1],
      [cx - 1, cy + 1],
      [cx + 1, cy - 1],
      [cx - 1, cy - 1],
    ];

    for (const [nx, ny] of neighbors) {
      const key = `${nx},${ny}`;
      if (!zone.has(key) && isWarpTile(nx, ny)) {
        zone.add(key);
        queue.push([nx, ny]);
      }
    }
  }

  return zone;
}
