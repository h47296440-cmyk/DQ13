import * as THREE from 'three';

// Create a high-performance, lightweight renderer
// Uses WebGPU if available in the browser/hardware, with seamless WebGL fallback.
// Clamps pixel ratio and disables unnecessary overhead to maximize framerate and smoothness.

export interface OptimizedRendererResult {
  renderer: THREE.WebGLRenderer | any;
  isWebGPU: boolean;
  dispose: () => void;
}

export function createOptimizedRenderer(
  container: HTMLElement,
  options?: { antialias?: boolean; alpha?: boolean; shadows?: boolean }
): OptimizedRendererResult {
  let renderer: any = null;
  let isWebGPU = false;

  // Check if WebGPU is supported and enabled in navigator
  const hasWebGPU = typeof navigator !== 'undefined' && 'gpu' in navigator && !!(navigator as any).gpu;

  if (hasWebGPU) {
    try {
      // Dynamic require or import of WebGPURenderer
      // In Three.js 0.186, WebGPURenderer is exported from 'three/webgpu'
      const { WebGPURenderer } = (THREE as any).WebGPURenderer
        ? { WebGPURenderer: (THREE as any).WebGPURenderer }
        : (window as any).__THREE_WEBGPU__ || {};

      if (WebGPURenderer) {
        renderer = new WebGPURenderer({
          antialias: options?.antialias ?? false,
          alpha: options?.alpha ?? false,
          powerPreference: 'high-performance',
        });
        if (renderer.init) {
          renderer.init().catch((err: any) => {
            console.warn('[WebGPU] init failed, falling back to WebGL:', err);
          });
        }
        isWebGPU = true;
      }
    } catch (e) {
      console.warn('[WebGPU] Could not initialize WebGPURenderer, falling back to WebGL:', e);
    }
  }

  // Fallback to high-performance WebGLRenderer
  if (!renderer) {
    renderer = new THREE.WebGLRenderer({
      antialias: options?.antialias ?? false,
      alpha: options?.alpha ?? false,
      powerPreference: 'high-performance',
      precision: 'mediump', // Optimized mobile/low-spec GPU performance
      stencil: false,
      depth: true,
    });
    isWebGPU = false;
  }

  // Set lightweight render configuration
  const width = Math.max(container.clientWidth, 320);
  const height = Math.max(container.clientHeight, 240);
  renderer.setSize(width, height);

  // Clamp pixel ratio to 1.25 max for ultra-high FPS without blurriness
  const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.25);
  renderer.setPixelRatio(pixelRatio);

  if (options?.shadows && renderer.shadowMap) {
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.BasicShadowMap; // Basic shadow map is much lighter than PCFSoft
  }

  container.appendChild(renderer.domElement);

  return {
    renderer,
    isWebGPU,
    dispose: () => {
      try {
        if (renderer.domElement && renderer.domElement.parentElement) {
          renderer.domElement.parentElement.removeChild(renderer.domElement);
        }
        renderer.dispose();
      } catch {
        // cleanup ignore
      }
    },
  };
}
