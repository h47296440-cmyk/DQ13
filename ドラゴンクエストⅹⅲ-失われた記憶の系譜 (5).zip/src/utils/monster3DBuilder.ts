import * as THREE from 'three';
import { Monster } from '../types/game';

// Shared materials and geometries for optimal WebGPU / WebGL performance
const sharedMaterials = {
  slimeBlue: new THREE.MeshPhysicalMaterial({
    color: 0x3b82f6,
    roughness: 0.15,
    metalness: 0.1,
    transmission: 0.35,
    thickness: 0.8,
    clearcoat: 0.9,
  }),
  batPurple: new THREE.MeshStandardMaterial({
    color: 0x6366f1,
    roughness: 0.5,
  }),
  batWing: new THREE.MeshStandardMaterial({
    color: 0x312e81,
    side: THREE.DoubleSide,
    roughness: 0.6,
  }),
  ghostWhite: new THREE.MeshStandardMaterial({
    color: 0xf1f5f9,
    roughness: 0.3,
    transparent: true,
    opacity: 0.92,
  }),
  mageRobe: new THREE.MeshStandardMaterial({
    color: 0x9333ea,
    roughness: 0.7,
  }),
  mageHat: new THREE.MeshStandardMaterial({
    color: 0x6b21a8,
    roughness: 0.6,
  }),
  boneWhite: new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.7,
  }),
  steelMetal: new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.8,
    roughness: 0.2,
  }),
  demonDark: new THREE.MeshStandardMaterial({
    color: 0x181824,
    emissive: 0x3b0764,
    emissiveIntensity: 0.4,
    roughness: 0.4,
  }),
  bossBarenPink: new THREE.MeshStandardMaterial({
    color: 0xec4899,
    emissive: 0xbe185d,
    emissiveIntensity: 0.35,
    roughness: 0.4,
  }),
  bossGalgardGold: new THREE.MeshStandardMaterial({
    color: 0xfbbf24,
    metalness: 0.85,
    roughness: 0.2,
  }),
  lastBossObsidian: new THREE.MeshStandardMaterial({
    color: 0x3b0764,
    emissive: 0x581c87,
    emissiveIntensity: 0.5,
    roughness: 0.3,
  }),
  whiteEye: new THREE.MeshBasicMaterial({ color: 0xffffff }),
  blackPupil: new THREE.MeshBasicMaterial({ color: 0x0f172a }),
  yellowEye: new THREE.MeshBasicMaterial({ color: 0xfacc15 }),
  redEye: new THREE.MeshBasicMaterial({ color: 0xef4444 }),
};

/**
 * Builds a unique, authentic 3D model for each Dragon Quest monster type.
 */
export function buildMonster3D(monsterType: string, scaleMultiplier: number = 1.0): THREE.Group {
  const root = new THREE.Group();
  const type = monsterType.toLowerCase();

  if (type.includes('nebulos') || type.includes('lastboss') || type.includes('boss_nebulos')) {
    // === 1. 大魔王ネビュロス (Colossal Demon King) ===
    const body = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.9, 3.4, 8), sharedMaterials.lastBossObsidian);
    body.position.y = 2.0;
    body.castShadow = true;

    // Dark Spiked Shoulder Pauldrons
    [-1.6, 1.6].forEach(x => {
      const pauldron = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.5, 6), sharedMaterials.lastBossObsidian);
      pauldron.position.set(x, 3.4, 0);
      pauldron.rotation.z = x > 0 ? -0.6 : 0.6;
      root.add(pauldron);
    });

    // Demon Head & Giant Horns
    const head = new THREE.Mesh(new THREE.SphereGeometry(1.0, 10, 10), sharedMaterials.lastBossObsidian);
    head.position.y = 4.2;

    [-0.9, 0.9].forEach(x => {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.8, 6), sharedMaterials.demonDark);
      horn.position.set(x, 5.2, 0);
      horn.rotation.z = x > 0 ? 0.5 : -0.5;
      root.add(horn);
    });

    // Glowing Crimson Eyes
    [-0.35, 0.35].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), sharedMaterials.redEye);
      eye.position.set(x, 4.3, 0.95);
      root.add(eye);
    });

    // Massive Wing Silhouettes
    [-2.8, 2.8].forEach(x => {
      const wing = new THREE.Mesh(new THREE.PlaneGeometry(3.5, 4.5), sharedMaterials.demonDark);
      wing.position.set(x, 3.6, -0.6);
      wing.rotation.y = x > 0 ? -0.4 : 0.4;
      root.add(wing);
    });

    // Glowing Chest Core of Despair
    const core = new THREE.Mesh(
      new THREE.SphereGeometry(0.4, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xc084fc })
    );
    core.position.set(0, 2.5, 1.5);
    root.add(body, head, core);

  } else if (type.includes('galgard') || type.includes('false_pride')) {
    // === 2. 心の魔物：虚飾の魔神 (Golden False Pride Djinn) ===
    const armorBody = new THREE.Mesh(new THREE.DodecahedronGeometry(1.7, 0), sharedMaterials.bossGalgardGold);
    armorBody.position.y = 2.2;
    armorBody.castShadow = true;

    const goldHead = new THREE.Mesh(new THREE.SphereGeometry(0.85, 8, 8), sharedMaterials.bossGalgardGold);
    goldHead.position.y = 3.9;

    // Ornate Golden Crown
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.7, 0.6, 5), sharedMaterials.bossGalgardGold);
    crown.position.y = 4.8;

    // Floating Golden Rings
    [-1.8, 1.8].forEach(x => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.15, 6, 12), sharedMaterials.bossGalgardGold);
      ring.position.set(x, 2.5, 0);
      root.add(ring);
    });

    root.add(armorBody, goldHead, crown);

  } else if (type.includes('baren') || type.includes('sorrow')) {
    // === 3. 心の魔物：悲愛の魔獣 (Beast of Sorrowful Love) ===
    const beastBody = new THREE.Mesh(new THREE.SphereGeometry(1.6, 10, 10), sharedMaterials.bossBarenPink);
    beastBody.position.y = 1.9;
    beastBody.scale.set(1.2, 0.95, 1.3);

    const beastHead = new THREE.Mesh(new THREE.ConeGeometry(0.9, 1.6, 8), sharedMaterials.bossBarenPink);
    beastHead.position.set(0, 2.6, 1.2);
    beastHead.rotation.x = Math.PI / 2;

    // Curled Horns
    [-1.2, 1.2].forEach(x => {
      const horn = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.2, 6, 10, Math.PI * 1.3), sharedMaterials.demonDark);
      horn.position.set(x, 3.2, 0.3);
      horn.rotation.y = x > 0 ? 0.3 : -0.3;
      root.add(horn);
    });

    // Crystal Heart
    const heart = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.5, 0),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
    );
    heart.position.set(0, 1.8, 1.4);
    root.add(beastBody, beastHead, heart);

  } else if (type.includes('dracky')) {
    // === 4. ドラキー (Dracky / Bat Monster) ===
    const batBody = new THREE.Mesh(new THREE.SphereGeometry(0.85, 12, 12), sharedMaterials.batPurple);
    batBody.position.y = 1.6;
    batBody.castShadow = true;

    // Pointed Bat Ears
    [-0.55, 0.55].forEach(x => {
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.7, 6), sharedMaterials.batPurple);
      ear.position.set(x, 2.4, 0);
      ear.rotation.z = x > 0 ? -0.35 : 0.35;
      root.add(ear);
    });

    // Big Yellow Glowing Eyes
    [-0.32, 0.32].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 8), sharedMaterials.yellowEye);
      eye.position.set(x, 1.8, 0.75);
      const slit = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.35, 0.1), sharedMaterials.blackPupil);
      slit.position.set(x, 1.8, 0.95);
      root.add(eye, slit);
    });

    // White Fangs
    [-0.2, 0.2].forEach(x => {
      const fang = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.25, 4), sharedMaterials.boneWhite);
      fang.position.set(x, 1.35, 0.85);
      fang.rotation.x = Math.PI;
      root.add(fang);
    });

    // Flapping Articulated Bat Wings
    [-1.3, 1.3].forEach(x => {
      const wingArm = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4), sharedMaterials.batPurple);
      wingArm.position.set(x, 1.8, 0);
      wingArm.rotation.z = x > 0 ? -1.1 : 1.1;

      const wingMembrane = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.1), sharedMaterials.batWing);
      wingMembrane.position.set(x > 0 ? x + 0.4 : x - 0.4, 1.7, 0);
      wingMembrane.rotation.y = x > 0 ? 0.3 : -0.3;
      root.add(wingArm, wingMembrane);
    });

    root.add(batBody);

  } else if (type.includes('ghost')) {
    // === 5. ゴースト (Ghost / Spectral Phantom) ===
    const ghostTorso = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.95, 1.6, 10), sharedMaterials.ghostWhite);
    ghostTorso.position.y = 1.3;

    // Head with nightcap
    const ghostHead = new THREE.Mesh(new THREE.SphereGeometry(0.7, 10, 10), sharedMaterials.ghostWhite);
    ghostHead.position.y = 2.1;

    // Drooping nightcap tip
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.4, 1.2, 8), sharedMaterials.ghostWhite);
    cap.position.set(0.4, 2.8, -0.2);
    cap.rotation.z = -0.7;

    const pompom = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), sharedMaterials.ghostWhite);
    pompom.position.set(0.9, 2.5, -0.2);

    // Mischievous Eyes & Smile
    [-0.24, 0.24].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 6), sharedMaterials.blackPupil);
      eye.position.set(x, 2.2, 0.65);
      root.add(eye);
    });

    // Ghost Hands
    [-0.9, 0.9].forEach(x => {
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.22, 6, 6), sharedMaterials.ghostWhite);
      hand.position.set(x, 1.5, 0.4);
      root.add(hand);
    });

    root.add(ghostTorso, ghostHead, cap, pompom);

  } else if (type.includes('magician') || type.includes('wizard')) {
    // === 6. まほうつかい (Magician / Robed Wizard) ===
    const robe = new THREE.Mesh(new THREE.ConeGeometry(1.0, 2.2, 10), sharedMaterials.mageRobe);
    robe.position.y = 1.1;

    const wizardHead = new THREE.Mesh(new THREE.SphereGeometry(0.5, 8, 8), sharedMaterials.boneWhite);
    wizardHead.position.y = 2.3;

    // Tall Wizard Hat with wide brim
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.1, 12), sharedMaterials.mageHat);
    brim.position.y = 2.65;
    const hatCone = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.5, 8), sharedMaterials.mageHat);
    hatCone.position.set(0.1, 3.4, -0.1);
    hatCone.rotation.z = -0.15;

    // Beard
    const beard = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.9, 6), sharedMaterials.ghostWhite);
    beard.position.set(0, 1.85, 0.45);
    beard.rotation.x = 0.3;

    // Staff with glowing magic orb
    const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 2.8), sharedMaterials.steelMetal);
    staff.position.set(1.1, 1.4, 0.4);
    const orb = new THREE.Mesh(new THREE.SphereGeometry(0.25, 8, 8), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
    orb.position.set(1.1, 2.85, 0.4);

    root.add(robe, wizardHead, brim, hatCone, beard, staff, orb);

  } else if (type.includes('skeleton')) {
    // === 7. がいこつ剣士 (Skeleton Knight) ===
    // Skull
    const skull = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.7, 0.7), sharedMaterials.boneWhite);
    skull.position.y = 2.5;

    // Ribcage & Spine
    const spine = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 1.5), sharedMaterials.boneWhite);
    spine.position.y = 1.6;

    for (let r = 0; r < 3; r++) {
      const rib = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.06, 4, 8, Math.PI), sharedMaterials.boneWhite);
      rib.position.set(0, 1.4 + r * 0.35, 0.1);
      root.add(rib);
    }

    // Glowing red eye sockets
    [-0.18, 0.18].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.09, 4, 4), sharedMaterials.redEye);
      eye.position.set(x, 2.55, 0.38);
      root.add(eye);
    });

    // Broadsword
    const swordBlade = new THREE.Mesh(new THREE.BoxGeometry(0.14, 2.0, 0.05), sharedMaterials.steelMetal);
    swordBlade.position.set(1.1, 1.8, 0.3);
    swordBlade.rotation.z = -0.3;

    // Shield
    const shield = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.65, 0.1, 8), sharedMaterials.steelMetal);
    shield.position.set(-1.0, 1.6, 0.3);
    shield.rotation.x = Math.PI / 2;

    root.add(skull, spine, swordBlade, shield);

  } else if (type.includes('shadow') || type.includes('demon')) {
    // === 8. 黒い影の魔獣 (Shadow Demon Beast) ===
    const shadowBody = new THREE.Mesh(new THREE.SphereGeometry(1.1, 8, 8), sharedMaterials.demonDark);
    shadowBody.position.y = 1.3;
    shadowBody.scale.set(1.2, 0.9, 1.3);

    // Dark Spikes along back
    for (let s = 0; s < 4; s++) {
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.8, 4), sharedMaterials.demonDark);
      spike.position.set(0, 1.7 + s * 0.25, -0.6 + s * 0.4);
      spike.rotation.x = -0.6;
      root.add(spike);
    }

    // Glowing Violet Eyes
    [-0.32, 0.32].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.15, 6, 6), sharedMaterials.redEye);
      eye.position.set(x, 1.5, 1.15);
      root.add(eye);
    });

    root.add(shadowBody);

  } else {
    // === 9. スライム (Slime - Classic DQ Mascot) ===
    const slimeBody = new THREE.Mesh(new THREE.SphereGeometry(1.1, 16, 16), sharedMaterials.slimeBlue);
    slimeBody.position.y = 1.1;
    slimeBody.scale.set(1.25, 0.98, 1.25);
    slimeBody.castShadow = true;

    // Slime Pointy Tip
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.85, 14), sharedMaterials.slimeBlue);
    tip.position.y = 2.18;

    // Big round eyes & black pupils
    [-0.35, 0.35].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.25, 8, 8), sharedMaterials.whiteEye);
      eye.position.set(x, 1.28, 0.98);

      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), sharedMaterials.blackPupil);
      pupil.position.set(x, 1.28, 1.18);
      root.add(eye, pupil);
    });

    // Friendly smile
    const smile = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.05, 6, 8, Math.PI), sharedMaterials.blackPupil);
    smile.position.set(0, 0.88, 1.18);
    smile.rotation.x = Math.PI;

    root.add(slimeBody, tip, smile);
  }

  root.scale.set(scaleMultiplier, scaleMultiplier, scaleMultiplier);
  return root;
}
