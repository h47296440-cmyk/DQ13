import * as THREE from 'three';

// 3D Model Generator for all Dragon Quest monsters
// Creates distinct, authentic 3D retro models for Slime, Dracky, Ghost, Magician, Skeleton, Shadow Demon, and Bosses.

export interface MonsterMeshResult {
  group: THREE.Group;
  basePosition?: THREE.Vector3;
  updateAnimation?: (time: number, isHit?: boolean, isTargeted?: boolean) => void;
  playAttackAnimation?: (
    targetPos: THREE.Vector3,
    actionType: 'attack' | 'spell' | 'skill',
    onHit: () => void,
    onComplete: () => void
  ) => void;
}

export function createMonsterModel(
  monsterType: string,
  options?: {
    isBoss?: boolean;
    isLastBoss?: boolean;
    scale?: number;
    color?: string;
  }
): MonsterMeshResult {
  const root = new THREE.Group();
  const type = monsterType.toLowerCase();
  const scale = options?.scale ?? 1.0;

  let animUpdate: ((time: number, isHit?: boolean, isTargeted?: boolean) => void) | undefined;

  if (options?.isLastBoss || type.includes('demonking') || type.includes('nebulos')) {
    // =========================================================================
    // 大魔王ネビュロス (Great Demon King Nebulos)
    // =========================================================================
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x3b0764,
      roughness: 0.35,
      emissive: 0x1e1035,
      emissiveIntensity: 0.7,
    });
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.2 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0xc084fc,
      emissiveIntensity: 1.2,
      roughness: 0.1,
    });

    // Massive Muscular Torso & Spiked Shoulders
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2.0, 3.4, 8), bodyMat);
    torso.position.y = 2.4;
    torso.castShadow = true;

    // Head
    const head = new THREE.Mesh(new THREE.DodecahedronGeometry(1.1, 1), bodyMat);
    head.position.y = 4.7;

    // Curved Demonic Horns
    const leftHorn = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.8, 6), hornMat);
    leftHorn.position.set(-0.9, 5.5, 0.1);
    leftHorn.rotation.z = -0.55;
    leftHorn.rotation.x = -0.2;

    const rightHorn = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.8, 6), hornMat);
    rightHorn.position.set(0.9, 5.5, 0.1);
    rightHorn.rotation.z = 0.55;
    rightHorn.rotation.x = -0.2;

    // Glowing Crimson Eyes
    const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), eyeMat);
    leftEye.position.set(-0.35, 4.75, 0.95);
    const rightEye = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), eyeMat);
    rightEye.position.set(0.35, 4.75, 0.95);

    // Memory Core in Chest (Pulsing glowing sphere of erased despair)
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.65, 12, 12), coreMat);
    core.position.set(0, 2.8, 1.25);

    // Spiked Demon Mantle Wings
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0x180d2b,
      side: THREE.DoubleSide,
      roughness: 0.4,
    });
    const leftWing = new THREE.Mesh(new THREE.ConeGeometry(1.4, 4.5, 4), wingMat);
    leftWing.position.set(-2.8, 3.6, -0.6);
    leftWing.rotation.z = 0.8;
    leftWing.rotation.y = 0.3;

    const rightWing = new THREE.Mesh(new THREE.ConeGeometry(1.4, 4.5, 4), wingMat);
    rightWing.position.set(2.8, 3.6, -0.6);
    rightWing.rotation.z = -0.8;
    rightWing.rotation.y = -0.3;

    root.add(torso, head, leftHorn, rightHorn, leftEye, rightEye, core, leftWing, rightWing);

    animUpdate = (time, isHit, isTargeted) => {
      core.scale.setScalar(1 + Math.sin(time * 4) * 0.12);
      leftWing.rotation.y = 0.3 + Math.sin(time * 2) * 0.15;
      rightWing.rotation.y = -0.3 - Math.sin(time * 2) * 0.15;
      if (isHit) {
        root.position.x = (Math.random() - 0.5) * 0.3;
      } else {
        root.position.x = 0;
        root.position.y = Math.sin(time * 1.5) * 0.15;
      }
    };
  } else if (options?.isBoss || type.includes('boss')) {
    if (type.includes('galgard')) {
      // =======================================================================
      // 偽りの黒騎士 (False Black Knight Galgard)
      // =======================================================================
      const armorMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.8,
        roughness: 0.25,
      });
      const goldTrim = new THREE.MeshStandardMaterial({
        color: 0xd97706,
        metalness: 0.9,
        roughness: 0.3,
      });
      const visorMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });

      // Torso & Heavy Armor
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.2, 1.4), armorMat);
      body.position.y = 2.2;
      body.castShadow = true;

      // Horned Great Helm
      const helm = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.2, 1.1), armorMat);
      helm.position.y = 3.8;
      const visor = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.16, 0.1), visorMat);
      visor.position.set(0, 3.8, 0.6);

      // Helm Horns
      const lHorn = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.8, 6), goldTrim);
      lHorn.position.set(-0.65, 4.4, 0);
      lHorn.rotation.z = -0.4;
      const rHorn = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.8, 6), goldTrim);
      rHorn.position.set(0.65, 4.4, 0);
      rHorn.rotation.z = 0.4;

      // Giant Dark Claymore Sword
      const swordGroup = new THREE.Group();
      swordGroup.position.set(1.5, 2.0, 0.4);
      const blade = new THREE.Mesh(
        new THREE.BoxGeometry(0.25, 3.2, 0.08),
        new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.2 })
      );
      blade.position.y = 1.2;
      const hilt = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.15, 0.15), goldTrim);
      hilt.position.y = -0.2;
      swordGroup.add(blade, hilt);

      // Heavy Tower Shield
      const shield = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.4, 0.15), armorMat);
      shield.position.set(-1.4, 2.2, 0.6);
      const shieldEmblem = new THREE.Mesh(new THREE.OctahedronGeometry(0.4, 0), goldTrim);
      shieldEmblem.position.set(-1.4, 2.2, 0.72);

      root.add(body, helm, visor, lHorn, rHorn, swordGroup, shield, shieldEmblem);

      animUpdate = (time, isHit) => {
        swordGroup.rotation.x = Math.sin(time * 2) * 0.15;
        if (isHit) {
          root.position.x = (Math.random() - 0.5) * 0.3;
        } else {
          root.position.x = 0;
          root.position.y = Math.abs(Math.sin(time * 2)) * 0.08;
        }
      };
    } else {
      // =======================================================================
      // 悲恋の魔獣 (Beast of Sorrow Baren)
      // =======================================================================
      const beastMat = new THREE.MeshStandardMaterial({
        color: 0xbe185d,
        roughness: 0.4,
        emissive: 0x831843,
        emissiveIntensity: 0.4,
      });
      const hornMat = new THREE.MeshStandardMaterial({ color: 0x312e81, roughness: 0.3 });

      const body = new THREE.Mesh(new THREE.DodecahedronGeometry(1.8, 0), beastMat);
      body.position.y = 2.0;
      body.castShadow = true;

      const head = new THREE.Mesh(new THREE.SphereGeometry(1.0, 8, 8), beastMat);
      head.position.y = 3.6;

      // Crystals of Sorrow
      for (let i = 0; i < 5; i++) {
        const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.4, 0), hornMat);
        const ang = (i / 5) * Math.PI * 2;
        crystal.position.set(Math.cos(ang) * 1.4, 2.2 + Math.sin(i) * 0.4, Math.sin(ang) * 1.4);
        root.add(crystal);
      }

      // Weeping Eyes of Blue Memory
      const tearEyeMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const le = new THREE.Mesh(new THREE.SphereGeometry(0.25, 6, 6), tearEyeMat);
      le.position.set(-0.4, 3.7, 0.85);
      const re = new THREE.Mesh(new THREE.SphereGeometry(0.25, 6, 6), tearEyeMat);
      re.position.set(0.4, 3.7, 0.85);

      root.add(body, head, le, re);

      animUpdate = (time, isHit) => {
        root.scale.setScalar(scale * (1 + Math.sin(time * 3) * 0.05));
        if (isHit) {
          root.position.x = (Math.random() - 0.5) * 0.3;
        } else {
          root.position.x = 0;
          root.position.y = Math.sin(time * 2) * 0.15;
        }
      };
    }
  } else if (type === 'dracky') {
    // =========================================================================
    // ドラキー (Dracky - Iconic Bat Monster)
    // =========================================================================
    const drackyBodyMat = new THREE.MeshStandardMaterial({
      color: 0x6366f1, // Indigo / Purple
      roughness: 0.5,
    });
    const wingMat = new THREE.MeshStandardMaterial({
      color: 0x4338ca,
      side: THREE.DoubleSide,
      roughness: 0.4,
    });
    const earMat = new THREE.MeshStandardMaterial({ color: 0x4f46e5 });
    const innerEarMat = new THREE.MeshBasicMaterial({ color: 0xf472b6 }); // Pink inner ear
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x09090b });
    const fangMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const mouthMat = new THREE.MeshBasicMaterial({ color: 0x991b1b });

    // Round body
    const body = new THREE.Mesh(new THREE.SphereGeometry(1.0, 14, 14), drackyBodyMat);
    body.position.y = 1.6;
    body.castShadow = true;

    // Big Pointed Bat Ears
    const lEar = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.0, 6), earMat);
    lEar.position.set(-0.6, 2.5, 0);
    lEar.rotation.z = -0.4;
    const lInner = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.7, 4), innerEarMat);
    lInner.position.set(-0.58, 2.45, 0.08);
    lInner.rotation.z = -0.4;

    const rEar = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.0, 6), earMat);
    rEar.position.set(0.6, 2.5, 0);
    rEar.rotation.z = 0.4;
    const rInner = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.7, 4), innerEarMat);
    rInner.position.set(0.58, 2.45, 0.08);
    rInner.rotation.z = 0.4;

    // Large Eyes & Goofy Pupils
    const le = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), eyeMat);
    le.position.set(-0.35, 1.75, 0.85);
    const lp = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), pupilMat);
    lp.position.set(-0.35, 1.75, 1.05);

    const re = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), eyeMat);
    re.position.set(0.35, 1.75, 0.85);
    const rp = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), pupilMat);
    rp.position.set(0.35, 1.75, 1.05);

    // Mouth with Vampire Fangs
    const mouth = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.1, 8), mouthMat);
    mouth.position.set(0, 1.25, 0.95);
    mouth.rotation.x = Math.PI / 2;

    const lFang = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.3, 4), fangMat);
    lFang.position.set(-0.2, 1.2, 1.05);
    lFang.rotation.x = Math.PI;

    const rFang = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.3, 4), fangMat);
    rFang.position.set(0.2, 1.2, 1.05);
    rFang.rotation.x = Math.PI;

    // Flapping Bat Wings
    const lWingGroup = new THREE.Group();
    lWingGroup.position.set(-0.8, 1.7, 0);
    const lWing = new THREE.Mesh(new THREE.ConeGeometry(1.2, 1.8, 3), wingMat);
    lWing.rotation.z = 1.3;
    lWing.rotation.y = 0.2;
    lWingGroup.add(lWing);

    const rWingGroup = new THREE.Group();
    rWingGroup.position.set(0.8, 1.7, 0);
    const rWing = new THREE.Mesh(new THREE.ConeGeometry(1.2, 1.8, 3), wingMat);
    rWing.rotation.z = -1.3;
    rWing.rotation.y = -0.2;
    rWingGroup.add(rWing);

    // Tiny feet
    const lFoot = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.15, 0.3), earMat);
    lFoot.position.set(-0.35, 0.65, 0.2);
    const rFoot = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.15, 0.3), earMat);
    rFoot.position.set(0.35, 0.65, 0.2);

    root.add(
      body,
      lEar,
      lInner,
      rEar,
      rInner,
      le,
      lp,
      re,
      rp,
      mouth,
      lFang,
      rFang,
      lWingGroup,
      rWingGroup,
      lFoot,
      rFoot
    );

    animUpdate = (time, isHit, isTargeted) => {
      // Dynamic wing flapping & hover
      const flap = Math.sin(time * 12) * 0.45;
      lWingGroup.rotation.y = flap;
      rWingGroup.rotation.y = -flap;

      if (isHit) {
        root.position.y = 0.2 + (Math.random() - 0.5) * 0.4;
      } else {
        root.position.y = 0.4 + Math.sin(time * 3) * 0.25;
      }
    };
  } else if (type === 'ghost') {
    // =========================================================================
    // ゴースト (Ghost - Classic Draped Ghost with Floppy Nightcap & Tongue)
    // =========================================================================
    const ghostMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.3,
      emissive: 0x94a3b8,
      emissiveIntensity: 0.2,
      transparent: true,
      opacity: 0.92,
    });
    const capMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.4 });
    const capPompom = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const tongueMat = new THREE.MeshBasicMaterial({ color: 0xf43f5e });

    // Floating wavy ghost body
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 1.2, 1.8, 12), ghostMat);
    body.position.y = 1.4;
    body.castShadow = true;

    // Tail ruffle
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.8, 0.9, 8), ghostMat);
    tail.position.y = 0.4;
    tail.rotation.x = 0.4;

    // Floppy Sleeping/Wizard Nightcap
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 8), capMat);
    cap.position.set(0, 2.5, -0.2);
    cap.rotation.x = -0.5;

    const pom = new THREE.Mesh(new THREE.SphereGeometry(0.2, 6, 6), capPompom);
    pom.position.set(0, 3.2, -0.7);

    // Sunken Dark Eyes with glowing white pinpricks
    const le = new THREE.Mesh(new THREE.SphereGeometry(0.26, 6, 6), eyeMat);
    le.position.set(-0.35, 1.7, 0.8);
    const lp = new THREE.Mesh(new THREE.SphereGeometry(0.08, 4, 4), pupilMat);
    lp.position.set(-0.35, 1.7, 1.0);

    const re = new THREE.Mesh(new THREE.SphereGeometry(0.26, 6, 6), eyeMat);
    re.position.set(0.35, 1.7, 0.8);
    const rp = new THREE.Mesh(new THREE.SphereGeometry(0.08, 4, 4), pupilMat);
    rp.position.set(0.35, 1.7, 1.0);

    // Cheeky Red Tongue sticking out!
    const tongue = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.45, 0.1), tongueMat);
    tongue.position.set(0, 1.15, 0.95);
    tongue.rotation.x = 0.5;

    // Spooky floating arms
    const lArm = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.25, 0.9, 6), ghostMat);
    lArm.position.set(-0.95, 1.4, 0.3);
    lArm.rotation.z = 0.8;
    lArm.rotation.x = 0.3;

    const rArm = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.25, 0.9, 6), ghostMat);
    rArm.position.set(0.95, 1.4, 0.3);
    rArm.rotation.z = -0.8;
    rArm.rotation.x = 0.3;

    root.add(body, tail, cap, pom, le, lp, re, rp, tongue, lArm, rArm);

    animUpdate = (time, isHit) => {
      // Ghost wavy bobbing in air
      body.rotation.y = Math.sin(time * 2) * 0.15;
      lArm.rotation.x = 0.3 + Math.sin(time * 3) * 0.2;
      rArm.rotation.x = 0.3 - Math.sin(time * 3) * 0.2;
      tongue.rotation.z = Math.sin(time * 6) * 0.15;

      if (isHit) {
        root.position.y = 0.3 + (Math.random() - 0.5) * 0.3;
      } else {
        root.position.y = 0.3 + Math.sin(time * 2.5) * 0.2;
      }
    };
  } else if (type === 'magician') {
    // =========================================================================
    // まほうつかい (Magician - Pointed Wizard Hat, Robes, and Magic Orb Staff)
    // =========================================================================
    const robeMat = new THREE.MeshStandardMaterial({ color: 0x7e22ce, roughness: 0.5 }); // Purple robe
    const hatMat = new THREE.MeshStandardMaterial({ color: 0x6b21a8, roughness: 0.4 });
    const bandMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 }); // Gold band
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 });
    const orbMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xdc2626,
      emissiveIntensity: 1.0,
      roughness: 0.1,
    });
    const shadowFaceMat = new THREE.MeshBasicMaterial({ color: 0x18181b });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xfde047 }); // Glowing yellow eyes

    // Robe
    const robe = new THREE.Mesh(new THREE.ConeGeometry(1.2, 2.2, 10), robeMat);
    robe.position.y = 1.1;
    robe.castShadow = true;

    // Dark Shadowy Face
    const face = new THREE.Mesh(new THREE.SphereGeometry(0.65, 8, 8), shadowFaceMat);
    face.position.y = 2.4;

    // Glowing Eerie Yellow Eyes
    const le = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), eyeMat);
    le.position.set(-0.25, 2.4, 0.55);
    const re = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), eyeMat);
    re.position.set(0.25, 2.4, 0.55);

    // Classic Tall Pointed Wizard Hat with Wide Brim
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.08, 12), hatMat);
    brim.position.y = 2.85;

    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.9, 0.22, 10), bandMat);
    band.position.y = 3.0;

    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.8, 1.8, 10), hatMat);
    cone.position.set(0, 3.9, -0.15);
    cone.rotation.x = -0.18;

    // Magic Staff with Glowing Red Orb
    const staffGroup = new THREE.Group();
    staffGroup.position.set(1.2, 1.5, 0.4);

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.09, 3.0, 6), woodMat);
    pole.position.y = 0.5;

    const orb = new THREE.Mesh(new THREE.SphereGeometry(0.35, 10, 10), orbMat);
    orb.position.y = 2.1;

    staffGroup.add(pole, orb);

    root.add(robe, face, le, re, brim, band, cone, staffGroup);

    animUpdate = (time, isHit) => {
      orb.scale.setScalar(1 + Math.sin(time * 5) * 0.15);
      staffGroup.rotation.z = Math.sin(time * 2) * 0.1;
      if (isHit) {
        root.position.x = (Math.random() - 0.5) * 0.25;
      } else {
        root.position.x = 0;
        root.position.y = Math.sin(time * 2) * 0.06;
      }
    };
  } else if (type === 'skeleton') {
    // =========================================================================
    // がいこつ剣士 (Skeleton Swordsman - Skull, Ribcage, Sword & Shield)
    // =========================================================================
    const boneMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.6 });
    const darkMat = new THREE.MeshBasicMaterial({ color: 0x09090b });
    const ironMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.8,
      roughness: 0.3,
    });
    const woodShieldMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
    const brassMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.7,
      roughness: 0.3,
    });

    // Skull & Jaw
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.65, 8, 8), boneMat);
    skull.position.y = 3.2;
    skull.castShadow = true;

    const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.4), boneMat);
    jaw.position.set(0, 2.7, 0.2);

    // Hollow eye sockets
    const lSocket = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), darkMat);
    lSocket.position.set(-0.24, 3.2, 0.55);
    const rSocket = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), darkMat);
    rSocket.position.set(0.24, 3.2, 0.55);

    // Spine & Ribcage
    const spine = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 1.4, 6), boneMat);
    spine.position.y = 2.0;

    for (let r = 0; r < 4; r++) {
      const rib = new THREE.Mesh(new THREE.TorusGeometry(0.48 - r * 0.05, 0.06, 4, 8, Math.PI * 1.5), boneMat);
      rib.position.set(0, 2.3 - r * 0.28, 0);
      rib.rotation.x = Math.PI / 2;
      rib.rotation.z = Math.PI * 0.25;
      root.add(rib);
    }

    // Pelvis
    const pelvis = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.3, 0.5), boneMat);
    pelvis.position.y = 1.2;

    // Legs
    const lLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.2, 6), boneMat);
    lLeg.position.set(-0.35, 0.6, 0);
    const rLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.2, 6), boneMat);
    rLeg.position.set(0.35, 0.6, 0);

    // Rusty Iron Sword in Right Hand
    const swordGroup = new THREE.Group();
    swordGroup.position.set(0.9, 2.1, 0.2);
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.18, 2.2, 0.05), ironMat);
    blade.position.y = 1.0;
    const crossguard = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 0.1), ironMat);
    crossguard.position.y = 0.0;
    swordGroup.add(blade, crossguard);

    // Round Buckler Shield in Left Hand
    const shieldGroup = new THREE.Group();
    shieldGroup.position.set(-0.9, 2.0, 0.4);
    const shield = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.12, 12), woodShieldMat);
    shield.rotation.x = Math.PI / 2;
    const boss = new THREE.Mesh(new THREE.SphereGeometry(0.2, 6, 6), brassMat);
    boss.position.set(0, 0, 0.08);
    shieldGroup.add(shield, boss);

    root.add(skull, jaw, lSocket, rSocket, spine, pelvis, lLeg, rLeg, swordGroup, shieldGroup);

    animUpdate = (time, isHit) => {
      swordGroup.rotation.x = Math.sin(time * 3) * 0.2;
      skull.rotation.y = Math.sin(time * 1.5) * 0.15;
      if (isHit) {
        root.position.x = (Math.random() - 0.5) * 0.3;
      } else {
        root.position.x = 0;
        root.position.y = Math.sin(time * 3) * 0.05;
      }
    };
  } else if (type === 'shadowdemon') {
    // =========================================================================
    // 黒い影の魔獣 (Dark Shadow Beast - Horns, Spiked Shoulders & Red Glowing Eyes)
    // =========================================================================
    const shadowMat = new THREE.MeshStandardMaterial({
      color: 0x110e1b,
      roughness: 0.3,
      emissive: 0x4c1d95,
      emissiveIntensity: 0.6,
    });
    const redEyeMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x030712, roughness: 0.2 });

    const torso = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 0.8, 2.2, 8), shadowMat);
    torso.position.y = 1.6;
    torso.castShadow = true;

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.85, 8, 8), shadowMat);
    head.position.y = 3.0;

    // Curved beast horns
    const lHorn = new THREE.Mesh(new THREE.ConeGeometry(0.25, 1.2, 6), hornMat);
    lHorn.position.set(-0.6, 3.8, 0);
    lHorn.rotation.z = -0.5;

    const rHorn = new THREE.Mesh(new THREE.ConeGeometry(0.25, 1.2, 6), hornMat);
    rHorn.position.set(0.6, 3.8, 0);
    rHorn.rotation.z = 0.5;

    // Glowing Eyes
    const le = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), redEyeMat);
    le.position.set(-0.3, 3.0, 0.75);
    const re = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), redEyeMat);
    re.position.set(0.3, 3.0, 0.75);

    // Claws
    const lClaw = new THREE.Mesh(new THREE.ConeGeometry(0.3, 1.2, 4), shadowMat);
    lClaw.position.set(-1.3, 1.6, 0.4);
    lClaw.rotation.z = 0.6;
    const rClaw = new THREE.Mesh(new THREE.ConeGeometry(0.3, 1.2, 4), shadowMat);
    rClaw.position.set(1.3, 1.6, 0.4);
    rClaw.rotation.z = -0.6;

    root.add(torso, head, lHorn, rHorn, le, re, lClaw, rClaw);

    animUpdate = (time, isHit) => {
      root.scale.setScalar(scale * (1 + Math.sin(time * 4) * 0.06));
      if (isHit) {
        root.position.x = (Math.random() - 0.5) * 0.3;
      } else {
        root.position.x = 0;
        root.position.y = Math.sin(time * 2) * 0.1;
      }
    };
  } else {
    // =========================================================================
    // スライム (Slime - Iconic Teardrop Dome, Big Eyes & Smile)
    // =========================================================================
    const color = options?.color || (type.includes('she_slime') ? '#f43f5e' : '#3b82f6');
    const slimeMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color),
      roughness: 0.15,
      transmission: 0.35,
      thickness: 0.8,
      clearcoat: 0.9,
    });

    // Teardrop body
    const baseSphere = new THREE.Mesh(new THREE.SphereGeometry(1.05, 16, 16), slimeMat);
    baseSphere.position.y = 1.0;
    baseSphere.scale.set(1.25, 0.95, 1.25);
    baseSphere.castShadow = true;

    // Pointed onion top
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.9, 12), slimeMat);
    tip.position.y = 2.1;

    // Eyes
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

    const le = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 8), eyeMat);
    le.position.set(-0.35, 1.15, 0.9);
    const lp = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), pupilMat);
    lp.position.set(-0.35, 1.15, 1.1);

    const re = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 8), eyeMat);
    re.position.set(0.35, 1.15, 0.9);
    const rp = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), pupilMat);
    rp.position.set(0.35, 1.15, 1.1);

    // Mouth / Smile
    const smileMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const smile = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.045, 6, 8, Math.PI), smileMat);
    smile.position.set(0, 0.8, 1.05);
    smile.rotation.x = Math.PI;

    root.add(baseSphere, tip, le, lp, re, rp, smile);

    animUpdate = (time, isHit, isTargeted) => {
      if (isHit) {
        root.scale.set(scale * 1.3, scale * 0.7, scale * 1.3);
      } else {
        const bounce = Math.abs(Math.sin(time * 3)) * 0.18;
        const squish = 1 + Math.sin(time * 3) * 0.08;
        root.position.y = bounce;
        root.scale.set(
          scale * (isTargeted ? 1.15 : 1.0) / squish,
          scale * (isTargeted ? 1.15 : 1.0) * squish,
          scale * (isTargeted ? 1.15 : 1.0) / squish
        );
      }
    };
  }

  root.scale.setScalar(scale);

  let attackAnimState: {
    targetPos: THREE.Vector3;
    actionType: 'attack' | 'spell' | 'skill';
    progress: number;
    onHit: () => void;
    onComplete: () => void;
    hasTriggeredHit: boolean;
  } | null = null;

  const basePos = new THREE.Vector3(0, 0, 0);

  const wrappedUpdateAnimation = (time: number, isHit?: boolean, isTargeted?: boolean) => {
    if (attackAnimState) {
      const state = attackAnimState;
      state.progress += 0.03;
      if (state.progress < 0.4) {
        // Surge forward towards party
        const t = state.progress / 0.4;
        const stopZ = state.targetPos.z - 2.0;
        root.position.x = THREE.MathUtils.lerp(basePos.x, state.targetPos.x, t);
        root.position.z = THREE.MathUtils.lerp(basePos.z, stopZ, t);
        root.position.y = Math.sin(t * Math.PI) * 0.4;
      } else if (state.progress < 0.7) {
        // Strike moment
        const t = (state.progress - 0.4) / 0.3;
        root.position.y = 0.2 + Math.sin(t * Math.PI) * 0.4;
        root.rotation.x = Math.sin(t * Math.PI) * 0.4;
        if (t >= 0.45 && !state.hasTriggeredHit) {
          state.hasTriggeredHit = true;
          state.onHit();
        }
      } else if (state.progress < 1.0) {
        // Return back to arena position
        const t = (state.progress - 0.7) / 0.3;
        const stopZ = state.targetPos.z - 2.0;
        root.position.x = THREE.MathUtils.lerp(state.targetPos.x, basePos.x, t);
        root.position.z = THREE.MathUtils.lerp(stopZ, basePos.z, t);
        root.position.y = Math.sin(t * Math.PI) * 0.2;
        root.rotation.x = THREE.MathUtils.lerp(root.rotation.x, 0, 0.2);
      } else {
        root.position.copy(basePos);
        root.rotation.set(0, Math.PI, 0);
        const onComplete = state.onComplete;
        attackAnimState = null;
        onComplete();
      }
    } else {
      if (animUpdate) animUpdate(time, isHit, isTargeted);
    }
  };

  const playAttackAnimation = (
    targetPos: THREE.Vector3,
    actionType: 'attack' | 'spell' | 'skill',
    onHit: () => void,
    onComplete: () => void
  ) => {
    basePos.copy(root.position);
    attackAnimState = {
      targetPos,
      actionType,
      progress: 0,
      onHit,
      onComplete,
      hasTriggeredHit: false,
    };
  };

  return {
    group: root,
    basePosition: basePos,
    updateAnimation: wrappedUpdateAnimation,
    playAttackAnimation,
  };
}
