import * as THREE from 'three';
import { Character } from '../types/game';
import { createCoffinGroup } from './coffinModel';

// 3D Party Character Model & Animation Engine for Dragon Quest IX Style Battles
// Features full 3D models with vocation armor/robes, hair styling, weapons, DQ9 run-up attacks,
// and automatic 3D Coffin (棺桶) transformation when a party member falls in battle!

export interface CharacterMeshResult {
  group: THREE.Group;
  charId: string;
  charName: string;
  basePosition: THREE.Vector3;
  rightArm: THREE.Group;
  leftArm: THREE.Group;
  weaponMesh: THREE.Object3D;
  updateAnimation: (time: number, isHit?: boolean, isDead?: boolean) => void;
  playAttackAnimation: (
    targetPos: THREE.Vector3,
    actionType: 'attack' | 'spell' | 'skill',
    onHit: () => void,
    onComplete: () => void
  ) => void;
}

export function createPartyMember3DModel(
  char: Character,
  index: number,
  totalParty: number
): CharacterMeshResult {
  const root = new THREE.Group();

  // Formation positioning: Party stands in the foreground facing north towards monsters
  // Camera is behind/above party looking forward (DQ9 perspective)
  const partySpacing = 2.0;
  const startX = (index - (totalParty - 1) / 2) * partySpacing;
  const startY = 0;
  const startZ = 4.2; // Foreground
  const basePos = new THREE.Vector3(startX, startY, startZ);
  root.position.copy(basePos);

  // Group containing the living human 3D model
  const humanGroup = new THREE.Group();
  root.add(humanGroup);

  // Group containing the wooden Dragon Quest Coffin (棺桶)
  const coffinGroup = createCoffinGroup();
  root.add(coffinGroup);

  const isInitiallyDead = (char.hp ?? 0) <= 0;
  humanGroup.visible = !isInitiallyDead;
  coffinGroup.visible = isInitiallyDead;

  const outfitColor = char.appearance?.outfitColor || (char.role === '戦士' ? 0xdc2626 : char.role === '魔法使い' ? 0x7c3aed : 0x2563eb);
  const hairColor = char.appearance?.hairColor || (char.role === '戦士' ? 0xfacc15 : char.role === '魔法使い' ? 0xa855f7 : 0x3b82f6);
  const gender = char.appearance?.gender || (char.id === 'sierra' ? 'female' : 'male');
  const vocation = char.appearance?.vocation || (char.role === '戦士' ? 'warrior' : char.role === '魔法使い' ? 'mage' : 'hero');

  // Materials
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xfed7aa, roughness: 0.6 });
  const bodyMat = new THREE.MeshStandardMaterial({ color: outfitColor, roughness: 0.5 });
  const hairMat = new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.7 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8, roughness: 0.2 });
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.85, roughness: 0.3 });
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

  // 1. Torso & Armor/Robe
  let body: THREE.Mesh;
  if (vocation === 'mage' || vocation === 'cleric' || vocation === 'sage') {
    // Flowing Robe
    body = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.4, 10), bodyMat);
    body.position.y = 0.8;
  } else {
    // Fitted Tunic / Plate Armor
    body = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.48, 1.3, 10), bodyMat);
    body.position.y = 0.85;
  }
  body.castShadow = true;
  humanGroup.add(body);

  // Belt / Armor Buckle
  const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.49, 0.49, 0.14, 10), goldMat);
  belt.position.y = 0.65;
  humanGroup.add(belt);

  // 2. Head
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 10), skinMat);
  head.position.y = 1.78;
  head.castShadow = true;
  humanGroup.add(head);

  // Eyes (Looking forward towards monsters)
  const le = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 6), eyeMat);
  le.position.set(-0.16, 1.82, -0.38);
  const re = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 6), eyeMat);
  re.position.set(0.16, 1.82, -0.38);
  humanGroup.add(le, re);

  // 3. Hair & Headwear
  const hairGroup = new THREE.Group();
  hairGroup.position.set(0, 1.8, 0);

  if (vocation === 'mage') {
    // Pointed Mage Hat
    const hatBrim = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.06, 12), bodyMat);
    hatBrim.position.y = 0.4;
    const hatCone = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.1, 10), bodyMat);
    hatCone.position.set(0, 0.9, -0.1);
    hatCone.rotation.x = 0.2;
    hairGroup.add(hatBrim, hatCone);
  } else {
    // Spiky Hero/Anime Hair
    const mainHair = new THREE.Mesh(new THREE.SphereGeometry(0.45, 8, 8), hairMat);
    mainHair.position.y = 0.12;
    hairGroup.add(mainHair);

    for (let s = 0; s < 5; s++) {
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.45, 4), hairMat);
      const ang = (s / 5) * Math.PI * 1.4 - Math.PI * 0.7;
      spike.position.set(Math.sin(ang) * 0.35, 0.35, Math.cos(ang) * 0.3);
      spike.rotation.z = -Math.sin(ang) * 0.5;
      spike.rotation.x = Math.cos(ang) * 0.4;
      hairGroup.add(spike);
    }
  }
  humanGroup.add(hairGroup);

  // 4. Arms & Weapons
  // Right Arm (Weapon Hand)
  const rightArm = new THREE.Group();
  rightArm.position.set(0.6, 1.4, 0);

  const rArmMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.7, 6), bodyMat);
  rArmMesh.position.y = -0.35;
  rightArm.add(rArmMesh);

  // Weapon Mesh attached to hand
  let weaponMesh: THREE.Object3D;

  if (vocation === 'mage' || vocation === 'cleric' || vocation === 'sage') {
    // Magic Staff with Glowing Gem
    const staffGroup = new THREE.Group();
    staffGroup.position.set(0, -0.65, -0.15);

    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.07, 1.8, 6),
      new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 })
    );
    pole.position.y = 0.3;

    const gem = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.2, 0),
      new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 0.9,
      })
    );
    gem.position.y = 1.25;

    staffGroup.add(pole, gem);
    weaponMesh = staffGroup;
  } else if (vocation === 'martial_artist') {
    // Spiked Combat Glove
    const glove = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.25, 0.25), metalMat);
    glove.position.set(0, -0.65, -0.1);
    weaponMesh = glove;
  } else {
    // Sword
    const swordGroup = new THREE.Group();
    swordGroup.position.set(0, -0.6, -0.15);

    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.5, 0.04), metalMat);
    blade.position.y = 0.65;

    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.08, 0.08), goldMat);
    guard.position.y = -0.1;

    const hilt = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, 0.05, 0.25, 6),
      new THREE.MeshStandardMaterial({ color: 0x78350f })
    );
    hilt.position.y = -0.25;

    swordGroup.add(blade, guard, hilt);
    swordGroup.rotation.x = -Math.PI / 4; // Held forward
    weaponMesh = swordGroup;
  }

  rightArm.add(weaponMesh);
  humanGroup.add(rightArm);

  // Left Arm (Shield or Balance Arm)
  const leftArm = new THREE.Group();
  leftArm.position.set(-0.6, 1.4, 0);

  const lArmMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.7, 6), bodyMat);
  lArmMesh.position.y = -0.35;
  leftArm.add(lArmMesh);

  if (vocation === 'hero' || vocation === 'warrior') {
    // Shield
    const shield = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.08, 10), metalMat);
    shield.position.set(0, -0.35, -0.2);
    shield.rotation.x = Math.PI / 2;
    const emblem = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.06, 3), goldMat);
    emblem.position.set(0, 0.05, 0);
    shield.add(emblem);
    leftArm.add(shield);
  }
  humanGroup.add(leftArm);

  // 5. Legs
  const lLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.12, 0.7, 6), bodyMat);
  lLeg.position.set(-0.25, 0.35, 0);
  const rLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.12, 0.7, 6), bodyMat);
  rLeg.position.set(0.25, 0.35, 0);
  humanGroup.add(lLeg, rLeg);

  // Animation State
  let currentAttackState: {
    targetPos: THREE.Vector3;
    actionType: 'attack' | 'spell' | 'skill';
    progress: number;
    onHit: () => void;
    onComplete: () => void;
    hasTriggeredHit: boolean;
  } | null = null;

  const updateAnimation = (time: number, isHit?: boolean, isDead?: boolean) => {
    // Check death / Coffin transformation!
    if (isDead) {
      humanGroup.visible = false;
      coffinGroup.visible = true;
      root.position.copy(basePos);
      root.rotation.set(0, 0, 0);
      if (isHit) {
        // Subtle impact shake on the casket
        coffinGroup.position.x = (Math.random() - 0.5) * 0.15;
      } else {
        coffinGroup.position.set(0, 0, 0);
      }
      return;
    }

    // Character is alive!
    humanGroup.visible = true;
    coffinGroup.visible = false;

    if (currentAttackState) {
      const state = currentAttackState;
      state.progress += 0.026; // Smooth 38-frame attack cycle

      if (state.progress < 0.38) {
        // Phase 1: Dash forward to target position (DQ9 style run-up!)
        const t = state.progress / 0.38;
        // Stop just in front of target
        const stopZ = state.targetPos.z + 2.0;
        root.position.x = THREE.MathUtils.lerp(basePos.x, state.targetPos.x, t);
        root.position.z = THREE.MathUtils.lerp(basePos.z, stopZ, t);
        root.position.y = Math.abs(Math.sin(t * Math.PI * 4)) * 0.22; // Running bob

        // Running arm & leg swing
        rightArm.rotation.x = Math.sin(t * Math.PI * 6) * 0.75 - 0.2;
        leftArm.rotation.x = -Math.sin(t * Math.PI * 6) * 0.75 + 0.1;
        lLeg.rotation.x = Math.sin(t * Math.PI * 6) * 0.6;
        rLeg.rotation.x = -Math.sin(t * Math.PI * 6) * 0.6;
      } else if (state.progress < 0.68) {
        // Phase 2: High Leap & Weapon Cleave / Spell Blast!
        const t = (state.progress - 0.38) / 0.3;

        // Leap into the air
        root.position.y = 0.2 + Math.sin(t * Math.PI) * 0.65;
        lLeg.rotation.x = 0.25;
        rLeg.rotation.x = -0.3;

        if (state.actionType === 'spell') {
          // Cast: Raise glowing staff high above head
          rightArm.rotation.x = -Math.PI * 0.85 + Math.sin(t * Math.PI * 2) * 0.25;
          leftArm.rotation.x = -Math.PI * 0.7;
          rightArm.rotation.z = -0.2;
        } else {
          // Melee slash: High vertical cleave downward
          rightArm.rotation.x = -Math.PI * 0.8 + t * Math.PI * 1.6;
          rightArm.rotation.z = Math.sin(t * Math.PI) * 0.4;
          leftArm.rotation.x = 0.4;
        }

        // Trigger damage & sound at impact moment
        if (t >= 0.45 && !state.hasTriggeredHit) {
          state.hasTriggeredHit = true;
          state.onHit();
        }
      } else if (state.progress < 1.0) {
        // Phase 3: Heroic backflip / retreat leap to battle formation!
        const t = (state.progress - 0.68) / 0.32;
        const stopZ = state.targetPos.z + 2.0;
        root.position.x = THREE.MathUtils.lerp(state.targetPos.x, basePos.x, t);
        root.position.z = THREE.MathUtils.lerp(stopZ, basePos.z, t);
        root.position.y = Math.sin(t * Math.PI) * 0.45; // Backwards arc
        root.rotation.x = -Math.sin(t * Math.PI) * 0.35; // Slight flip tilt

        rightArm.rotation.x = THREE.MathUtils.lerp(rightArm.rotation.x, -0.2, 0.2);
        leftArm.rotation.x = THREE.MathUtils.lerp(leftArm.rotation.x, 0.1, 0.2);
        lLeg.rotation.x = THREE.MathUtils.lerp(lLeg.rotation.x, 0, 0.2);
        rLeg.rotation.x = THREE.MathUtils.lerp(rLeg.rotation.x, 0, 0.2);
      } else {
        // Complete! Settle cleanly in formation
        root.position.copy(basePos);
        root.rotation.set(0, 0, 0);
        rightArm.rotation.set(0, 0, 0);
        leftArm.rotation.set(0, 0, 0);
        lLeg.rotation.set(0, 0, 0);
        rLeg.rotation.set(0, 0, 0);
        const onComplete = state.onComplete;
        currentAttackState = null;
        onComplete();
      }
    } else {
      // Idle Animation: DQ9 combat stance breathing
      const idleOffset = index * 0.7;
      const breathe = Math.sin(time * 3 + idleOffset) * 0.04;
      root.position.y = basePos.y + breathe;

      if (isHit) {
        // Flinch / hurt shake
        root.position.x = basePos.x + (Math.random() - 0.5) * 0.25;
        root.position.z = basePos.z + 0.3;
        rightArm.rotation.x = 0.5;
        leftArm.rotation.x = 0.5;
      } else {
        root.position.x = basePos.x;
        root.position.z = basePos.z;
        rightArm.rotation.x = Math.sin(time * 2 + idleOffset) * 0.08 - 0.2;
        leftArm.rotation.x = -Math.sin(time * 2 + idleOffset) * 0.08 + 0.1;
      }
    }
  };

  const playAttackAnimation = (
    targetPos: THREE.Vector3,
    actionType: 'attack' | 'spell' | 'skill',
    onHit: () => void,
    onComplete: () => void
  ) => {
    currentAttackState = {
      targetPos,
      actionType,
      progress: 0,
      onHit,
      onComplete,
      hasTriggeredHit: false,
    };
  };

  return {
    group: root,
    charId: char.id,
    charName: char.name,
    basePosition: basePos,
    rightArm,
    leftArm,
    weaponMesh,
    updateAnimation,
    playAttackAnimation,
  };
}

