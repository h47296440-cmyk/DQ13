// Dragon Quest Faithful Web Audio Synthesizer & Sound Effects
// Authentic Sugiyama Overture, Intermezzo (Adventure Log), Town Waltz, Field March, Battle Themes, and Classic Jingles

class DQAudioEngine {
  private ctx: AudioContext | null = null;
  private currentBgm: string | null = null;
  private bgmIntervalId: number | null = null;
  private activeOscillators: OscillatorNode[] = [];
  private activeNodes: AudioNode[] = [];
  private masterGain: GainNode | null = null;
  private bgmGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private isMuted: boolean = false;
  private bgmVolume: number = 0.45;
  private sfxVolume: number = 0.55;

  constructor() {}

  private initContext() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.bgmGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();

      this.bgmGain.gain.value = this.isMuted ? 0 : this.bgmVolume;
      this.sfxGain.gain.value = this.isMuted ? 0 : this.sfxVolume;

      this.bgmGain.connect(this.masterGain);
      this.sfxGain.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.bgmGain && this.sfxGain) {
      this.bgmGain.gain.value = this.isMuted ? 0 : this.bgmVolume;
      this.sfxGain.gain.value = this.isMuted ? 0 : this.sfxVolume;
    }
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // --- Classic Dragon Quest Sound Effects (SFX) ---

  // Cursor move beep (crisp 1100Hz bleep)
  public playCursor() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(1080, now);
    osc.frequency.setValueAtTime(1220, now + 0.02);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.045);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.05);
  }

  // Confirm decision chime
  public playConfirm() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.04);

      gain.gain.setValueAtTime(0.22, now + idx * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.04 + 0.12);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + idx * 0.04);
      osc.stop(now + idx * 0.04 + 0.14);
    });
  }

  // Cancel buzz
  public playCancel() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(420, now);
    osc.frequency.setValueAtTime(310, now + 0.06);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.16);
  }

  // Typewriter text blip
  public playTextBlip() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(390 + Math.random() * 35, now);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.005, now + 0.035);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.04);
  }

  // Attack slash
  public playAttack() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const bufferSize = this.ctx.sampleRate * 0.12;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.28));
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2600, now);
    filter.frequency.exponentialRampToValueAtTime(850, now + 0.12);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    noise.start(now);
  }

  // Critical hit (かいしんのいちげき!)
  public playCritical() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(650 + i * 200, now + i * 0.04);
      osc.frequency.exponentialRampToValueAtTime(1900 + i * 300, now + i * 0.04 + 0.15);

      gain.gain.setValueAtTime(0.3, now + i * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.04 + 0.2);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + i * 0.04);
      osc.stop(now + i * 0.04 + 0.25);
    }
  }

  // Magic cast sound
  public playMagic() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';

    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98, 2093.0];
    notes.forEach((freq, idx) => {
      osc.frequency.setValueAtTime(freq, now + idx * 0.04);
    });

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.45);
  }

  // Damage
  public playDamage() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.linearRampToValueAtTime(55, now + 0.15);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  // Defeat enemy
  public playEnemyDefeat() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(75, now + 0.25);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  // Treasure Chest
  public playChest() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880];
    notes.forEach((freq, idx) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);

      gain.gain.setValueAtTime(0.2, now + idx * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.08 + 0.2);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 0.22);
    });
  }

  // Stairs
  public playStairs() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [300, 360, 420, 480];
    notes.forEach((freq, i) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.05);

      gain.gain.setValueAtTime(0.18, now + i * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.05 + 0.08);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + i * 0.05);
      osc.stop(now + i * 0.05 + 0.09);
    });
  }

  // Encounter flash sound
  public playEncounter() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    for (let i = 0; i < 4; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180 + i * 160, now + i * 0.06);

      gain.gain.setValueAtTime(0.25, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.06 + 0.08);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now + i * 0.06);
      osc.stop(now + i * 0.06 + 0.09);
    }
  }

  // --- Authentic Dragon Quest Jingles ---

  // Level up fanfare!
  public playLevelUp() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [
      { f: 523.25, t: 0.0, d: 0.08 }, // C5
      { f: 587.33, t: 0.08, d: 0.08 }, // D5
      { f: 659.25, t: 0.16, d: 0.08 }, // E5
      { f: 698.46, t: 0.24, d: 0.08 }, // F5
      { f: 783.99, t: 0.32, d: 0.16 }, // G5
      { f: 659.25, t: 0.48, d: 0.08 }, // E5
      { f: 783.99, t: 0.56, d: 0.12 }, // G5
      { f: 1046.5, t: 0.68, d: 0.55 }, // C6
    ];

    notes.forEach(({ f, t, d }) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + t);

      gain.gain.setValueAtTime(0.25, now + t);
      gain.gain.exponentialRampToValueAtTime(0.01, now + t + d);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + t);
      osc.stop(now + t + d + 0.05);
    });
  }

  // Church / Save Cadence
  public playChurchJingle() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const chords = [
      { notes: [261.63, 329.63, 392.0], t: 0.0, d: 0.35 }, // C
      { notes: [293.66, 349.23, 440.0], t: 0.38, d: 0.35 }, // Dm
      { notes: [246.94, 293.66, 392.0], t: 0.76, d: 0.4 }, // G
      { notes: [261.63, 329.63, 523.25], t: 1.2, d: 0.8 }, // C
    ];

    chords.forEach(({ notes, t, d }) => {
      notes.forEach(f => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now + t);

        gain.gain.setValueAtTime(0.18, now + t);
        gain.gain.exponentialRampToValueAtTime(0.01, now + t + d);

        osc.connect(gain);
        gain.connect(this.sfxGain!);

        osc.start(now + t);
        osc.stop(now + t + d + 0.05);
      });
    });
  }

  // Inn / Sleep Jingle
  public playInnJingle() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [
      { f: 523.25, t: 0.0, d: 0.16 }, // C5
      { f: 659.25, t: 0.18, d: 0.16 }, // E5
      { f: 783.99, t: 0.36, d: 0.16 }, // G5
      { f: 1046.5, t: 0.54, d: 0.22 }, // C6
      { f: 987.77, t: 0.78, d: 0.16 }, // B5
      { f: 1046.5, t: 0.96, d: 0.65 }, // C6
    ];

    notes.forEach(({ f, t, d }) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + t);

      gain.gain.setValueAtTime(0.24, now + t);
      gain.gain.exponentialRampToValueAtTime(0.01, now + t + d);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + t);
      osc.stop(now + t + d + 0.05);
    });
  }

  // Victory fanfare!
  public playVictoryFanfare() {
    this.stopBgm();
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const melody = [
      { f: 523.25, t: 0.0, d: 0.09 }, // C5
      { f: 523.25, t: 0.09, d: 0.09 },
      { f: 523.25, t: 0.18, d: 0.09 },
      { f: 523.25, t: 0.27, d: 0.35 },
      { f: 415.3, t: 0.65, d: 0.22 }, // G#4
      { f: 466.16, t: 0.9, d: 0.22 }, // A#4
      { f: 523.25, t: 1.15, d: 0.8 }, // C5
    ];

    melody.forEach(({ f, t, d }) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(f, now + t);

      gain.gain.setValueAtTime(0.24, now + t);
      gain.gain.exponentialRampToValueAtTime(0.01, now + t + d);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + t);
      osc.stop(now + t + d + 0.05);
    });
  }

  // Tablet discovery chime
  public playTabletChime() {
    this.initContext();
    if (!this.ctx || !this.sfxGain || this.isMuted) return;

    const now = this.ctx.currentTime;
    const notes = [
      { f: 587.33, t: 0.0, d: 0.25 }, // D5
      { f: 739.99, t: 0.14, d: 0.25 }, // F#5
      { f: 880.0, t: 0.28, d: 0.3 }, // A5
      { f: 1174.66, t: 0.42, d: 0.5 }, // D6
      { f: 1479.98, t: 0.6, d: 0.7 }, // F#6
    ];

    notes.forEach(({ f, t, d }) => {
      const osc = this.ctx!.createOscillator();
      const gain = this.ctx!.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + t);

      gain.gain.setValueAtTime(0.22, now + t);
      gain.gain.exponentialRampToValueAtTime(0.005, now + t + d);

      osc.connect(gain);
      gain.connect(this.sfxGain!);

      osc.start(now + t);
      osc.stop(now + t + d + 0.05);
    });
  }

  // --- Dragon Quest Polyphonic Soundtracks ---

  public stopBgm() {
    if (this.bgmIntervalId) {
      clearInterval(this.bgmIntervalId);
      this.bgmIntervalId = null;
    }
    this.activeOscillators.forEach(osc => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {
        // already stopped
      }
    });
    this.activeNodes.forEach(node => {
      try {
        node.disconnect();
      } catch {
        // ignore
      }
    });
    this.activeOscillators = [];
    this.activeNodes = [];
    this.currentBgm = null;
  }

  public playBgm(
    trackName:
      | 'overture'
      | 'intermezzo'
      | 'village'
      | 'field'
      | 'dungeon'
      | 'battle'
      | 'boss'
      | 'lastboss'
      | 'ending'
  ) {
    if (this.currentBgm === trackName) return;
    this.stopBgm();
    this.initContext();
    if (!this.ctx || !this.bgmGain) return;

    this.currentBgm = trackName;
    if (this.isMuted) return;

    switch (trackName) {
      case 'overture':
        this.playOvertureLoop();
        break;
      case 'intermezzo':
        this.playIntermezzoLoop();
        break;
      case 'village':
        this.playVillageLoop();
        break;
      case 'field':
        this.playFieldLoop();
        break;
      case 'dungeon':
        this.playDungeonLoop();
        break;
      case 'battle':
        this.playBattleLoop();
        break;
      case 'boss':
        this.playBossLoop();
        break;
      case 'lastboss':
        this.playLastBossLoop();
        break;
      case 'ending':
        this.playEndingLoop();
        break;
    }
  }

  // High quality musical scheduler with orchestral timbre, vibrato, and percussion
  private scheduleTrack(
    tempoBpm: number,
    totalBeats: number,
    notes: Array<{
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    }>
  ) {
    if (!this.ctx || !this.bgmGain) return;

    const beatDuration = 60 / tempoBpm;
    const loopDuration = totalBeats * beatDuration;

    const playLoop = () => {
      if (!this.ctx || !this.bgmGain) return;
      const startTime = this.ctx.currentTime + 0.04;

      notes.forEach(({ voice, freq, beat, duration }) => {
        if (freq <= 0 && voice !== 'snare' && voice !== 'kick') return;
        const noteStart = startTime + beat * beatDuration;
        const noteDuration = duration * beatDuration * 0.94;

        if (voice === 'snare') {
          // Snappy March Snare Drum
          const bufferSize = Math.floor(this.ctx!.sampleRate * 0.08);
          const buffer = this.ctx!.createBuffer(1, bufferSize, this.ctx!.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.3));
          }
          const noise = this.ctx!.createBufferSource();
          noise.buffer = buffer;
          const filter = this.ctx!.createBiquadFilter();
          filter.type = 'bandpass';
          filter.frequency.setValueAtTime(1900, noteStart);

          const gain = this.ctx!.createGain();
          gain.gain.setValueAtTime(0.12, noteStart);
          gain.gain.exponentialRampToValueAtTime(0.005, noteStart + 0.07);

          noise.connect(filter);
          filter.connect(gain);
          gain.connect(this.bgmGain!);

          noise.start(noteStart);
          this.activeNodes.push(noise, filter, gain);
          return;
        }

        if (voice === 'kick') {
          // Timpani / March Kick
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(95, noteStart);
          osc.frequency.exponentialRampToValueAtTime(38, noteStart + 0.12);

          gain.gain.setValueAtTime(0.24, noteStart);
          gain.gain.exponentialRampToValueAtTime(0.005, noteStart + 0.12);

          osc.connect(gain);
          gain.connect(this.bgmGain!);

          osc.start(noteStart);
          osc.stop(noteStart + 0.13);
          this.activeOscillators.push(osc);
          return;
        }

        // Tonal instruments
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();

        if (voice === 'lead') {
          // Warm Brass / Singing Woodwind Lead with expressive vibrato
          osc.type = 'triangle';
          const filter = this.ctx!.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(2600, noteStart);

          // Subtle natural trumpet attack
          gain.gain.setValueAtTime(0.01, noteStart);
          gain.gain.linearRampToValueAtTime(0.22, noteStart + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.005, noteStart + noteDuration);

          // Expressive vibrato for sustained notes (> 0.8 beats)
          if (duration >= 0.8) {
            const vib = this.ctx!.createOscillator();
            const vibGain = this.ctx!.createGain();
            vib.frequency.setValueAtTime(5.5, noteStart); // 5.5Hz vibrato
            vibGain.gain.setValueAtTime(3.5, noteStart); // 3.5Hz pitch variation
            vib.connect(vibGain);
            vibGain.connect(osc.frequency);
            vib.start(noteStart + 0.15);
            vib.stop(noteStart + noteDuration);
            this.activeOscillators.push(vib);
          }

          osc.frequency.setValueAtTime(freq, noteStart);
          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.bgmGain!);
          this.activeNodes.push(filter);
        } else if (voice === 'harmony') {
          // Soft brass harmony
          osc.type = 'sine';
          gain.gain.setValueAtTime(0.01, noteStart);
          gain.gain.linearRampToValueAtTime(0.14, noteStart + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.005, noteStart + noteDuration);

          osc.frequency.setValueAtTime(freq, noteStart);
          osc.connect(gain);
          gain.connect(this.bgmGain!);
        } else if (voice === 'bass') {
          // Warm walking orchestral bass
          osc.type = 'sawtooth';
          const filter = this.ctx!.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(450, noteStart);

          gain.gain.setValueAtTime(0.2, noteStart);
          gain.gain.exponentialRampToValueAtTime(0.008, noteStart + noteDuration);

          osc.frequency.setValueAtTime(freq, noteStart);
          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.bgmGain!);
          this.activeNodes.push(filter);
        } else {
          // 'chord' - Delicate harp pluck / pizzicato
          osc.type = 'sine';
          gain.gain.setValueAtTime(0.16, noteStart);
          gain.gain.exponentialRampToValueAtTime(0.002, noteStart + noteDuration);

          osc.frequency.setValueAtTime(freq, noteStart);
          osc.connect(gain);
          gain.connect(this.bgmGain!);
        }

        osc.start(noteStart);
        osc.stop(noteStart + noteDuration);
        this.activeOscillators.push(osc);
      });

      setTimeout(() => {
        this.activeOscillators = this.activeOscillators.slice(-30);
        this.activeNodes = this.activeNodes.slice(-30);
      }, loopDuration * 1000);
    };

    playLoop();
    this.bgmIntervalId = window.setInterval(playLoop, loopDuration * 1000);
  }

  // =========================================================================
  // 1. 序曲 (Overture / ロトのテーマ - Authentic Sugiyama Fanfare & March)
  // =========================================================================
  private playOvertureLoop() {
    const G4 = 392.0,
      C5 = 523.25,
      D5 = 587.33,
      E5 = 659.25,
      F5 = 698.46,
      G5 = 783.99,
      A5 = 880.0,
      B5 = 987.77,
      C6 = 1046.5;
    const E4 = 329.63,
      F4 = 349.23,
      B4 = 493.88;
    const C3 = 130.81,
      G2 = 98.0,
      G3 = 196.0,
      F3 = 174.61,
      A2 = 110.0,
      D3 = 146.83;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      // --- Fanfare Phrase 1 (Bars 1-2) ---
      { voice: 'lead', freq: G4, beat: 0.0, duration: 0.25 },
      { voice: 'lead', freq: G4, beat: 0.25, duration: 0.25 },
      { voice: 'lead', freq: G4, beat: 0.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 1.0, duration: 1.5 },
      { voice: 'lead', freq: G4, beat: 2.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 3.0, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 3.5, duration: 0.5 },

      { voice: 'lead', freq: E5, beat: 4.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 4.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 5.0, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 5.5, duration: 0.5 },
      { voice: 'lead', freq: G5, beat: 6.0, duration: 3.2 },

      // Fanfare Harmony 1
      { voice: 'harmony', freq: E4, beat: 1.0, duration: 1.5 },
      { voice: 'harmony', freq: E4, beat: 2.5, duration: 0.5 },
      { voice: 'harmony', freq: G4, beat: 3.0, duration: 0.5 },
      { voice: 'harmony', freq: B4, beat: 3.5, duration: 0.5 },
      { voice: 'harmony', freq: C5, beat: 4.0, duration: 0.5 },
      { voice: 'harmony', freq: D5, beat: 4.5, duration: 0.5 },
      { voice: 'harmony', freq: C5, beat: 5.0, duration: 0.5 },
      { voice: 'harmony', freq: B4, beat: 5.5, duration: 0.5 },
      { voice: 'harmony', freq: D5, beat: 6.0, duration: 3.2 },

      // --- Fanfare Phrase 2 (Bars 3-4) ---
      { voice: 'lead', freq: G5, beat: 10.0, duration: 0.25 },
      { voice: 'lead', freq: G5, beat: 10.25, duration: 0.25 },
      { voice: 'lead', freq: G5, beat: 10.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 11.0, duration: 1.5 },
      { voice: 'lead', freq: C5, beat: 12.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 13.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 13.5, duration: 0.5 },

      { voice: 'lead', freq: G5, beat: 14.0, duration: 0.5 },
      { voice: 'lead', freq: A5, beat: 14.5, duration: 0.5 },
      { voice: 'lead', freq: G5, beat: 15.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 15.5, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 16.0, duration: 3.2 },

      // Fanfare Bass notes
      { voice: 'bass', freq: C3, beat: 1.0, duration: 1.5 },
      { voice: 'bass', freq: G2, beat: 6.0, duration: 3.0 },
      { voice: 'bass', freq: C3, beat: 11.0, duration: 1.5 },
      { voice: 'bass', freq: G2, beat: 16.0, duration: 3.0 },

      // Timpani roll transition into the march
      { voice: 'kick', freq: 0, beat: 20.0, duration: 0.5 },
      { voice: 'kick', freq: 0, beat: 21.0, duration: 0.5 },
      { voice: 'kick', freq: 0, beat: 22.0, duration: 0.3 },
      { voice: 'kick', freq: 0, beat: 22.5, duration: 0.3 },
      { voice: 'kick', freq: 0, beat: 23.0, duration: 0.5 },

      // March Pickup
      { voice: 'lead', freq: G4, beat: 23.5, duration: 0.5 },
      { voice: 'harmony', freq: E4, beat: 23.5, duration: 0.5 },

      // --- Royal March Phrase 1 (Bars 7-10) ---
      { voice: 'lead', freq: E5, beat: 24.0, duration: 1.5 },
      { voice: 'lead', freq: D5, beat: 25.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 26.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 27.0, duration: 1.5 },
      { voice: 'lead', freq: G4, beat: 28.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 29.0, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 29.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 30.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 30.5, duration: 0.5 },
      { voice: 'lead', freq: G5, beat: 31.0, duration: 2.0 },

      { voice: 'lead', freq: A5, beat: 33.0, duration: 1.0 },
      { voice: 'lead', freq: G5, beat: 34.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 34.5, duration: 0.5 },
      { voice: 'lead', freq: G5, beat: 35.0, duration: 2.0 },
      { voice: 'lead', freq: E5, beat: 37.0, duration: 1.0 },
      { voice: 'lead', freq: F5, beat: 38.0, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 38.5, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 39.0, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 39.5, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 40.0, duration: 2.0 },
      { voice: 'lead', freq: G4, beat: 42.0, duration: 1.5 },
      { voice: 'lead', freq: G4, beat: 43.5, duration: 0.5 },

      // --- Royal March Phrase 2 (Resolution to High C6) ---
      { voice: 'lead', freq: E5, beat: 44.0, duration: 1.5 },
      { voice: 'lead', freq: D5, beat: 45.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 46.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 47.0, duration: 1.5 },
      { voice: 'lead', freq: G4, beat: 48.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 49.0, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 49.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 50.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 50.5, duration: 0.5 },
      { voice: 'lead', freq: G5, beat: 51.0, duration: 2.0 },

      { voice: 'lead', freq: A5, beat: 53.0, duration: 0.5 },
      { voice: 'lead', freq: B5, beat: 53.5, duration: 0.5 },
      { voice: 'lead', freq: C6, beat: 54.0, duration: 1.0 },
      { voice: 'lead', freq: A5, beat: 55.0, duration: 1.0 },
      { voice: 'lead', freq: G5, beat: 56.0, duration: 2.0 },
      { voice: 'lead', freq: E5, beat: 58.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 59.0, duration: 2.0 },
      { voice: 'lead', freq: C5, beat: 61.0, duration: 3.0 },

      // March Harmony
      { voice: 'harmony', freq: C5, beat: 24.0, duration: 1.5 },
      { voice: 'harmony', freq: B4, beat: 25.5, duration: 0.5 },
      { voice: 'harmony', freq: G4, beat: 26.0, duration: 1.0 },
      { voice: 'harmony', freq: B4, beat: 27.0, duration: 1.5 },
      { voice: 'harmony', freq: E4, beat: 28.5, duration: 0.5 },
      { voice: 'harmony', freq: G4, beat: 29.0, duration: 2.0 },
      { voice: 'harmony', freq: C5, beat: 31.0, duration: 2.0 },

      // Walking March Bass (C - G - C - G)
      { voice: 'bass', freq: C3, beat: 24.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 25.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 26.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 27.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 28.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 29.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 30.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 31.0, duration: 0.9 },

      { voice: 'bass', freq: F3, beat: 33.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 34.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 35.0, duration: 0.9 },
      { voice: 'bass', freq: A2, beat: 37.0, duration: 0.9 },
      { voice: 'bass', freq: D3, beat: 38.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 40.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 42.0, duration: 0.9 },

      { voice: 'bass', freq: C3, beat: 44.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 45.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 46.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 47.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 48.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 49.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 50.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 51.0, duration: 0.9 },

      { voice: 'bass', freq: F3, beat: 53.0, duration: 0.9 },
      { voice: 'bass', freq: F3, beat: 54.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 56.0, duration: 0.9 },
      { voice: 'bass', freq: A2, beat: 58.0, duration: 0.9 },
      { voice: 'bass', freq: G2, beat: 59.0, duration: 0.9 },
      { voice: 'bass', freq: C3, beat: 61.0, duration: 3.0 },
    ];

    // Add Snare drums on beats 2 & 4 of march
    for (let b = 24; b < 62; b += 2) {
      notes.push({ voice: 'snare', freq: 0, beat: b + 1, duration: 0.1 });
    }
    // Add Kick drums on beat 1 & 3 of march
    for (let b = 24; b < 62; b += 2) {
      notes.push({ voice: 'kick', freq: 0, beat: b, duration: 0.1 });
    }

    this.scheduleTrack(116, 64, notes);
  }

  // =========================================================================
  // 2. インテルメッツォ (Intermezzo - 冒険の書 / ファイルセレクト画面BGM)
  // The iconic 4/4 chamber masterpiece in C major with gentle harp arpeggios
  // =========================================================================
  private playIntermezzoLoop() {
    const C4 = 261.63,
      D4 = 293.66,
      E4 = 329.63,
      F4 = 349.23,
      G4 = 392.0,
      A4 = 440.0,
      B4 = 493.88;
    const C5 = 523.25,
      D5 = 587.33,
      E5 = 659.25,
      F5 = 698.46,
      G5 = 783.99,
      A5 = 880.0;
    const C3 = 130.81,
      G2 = 98.0,
      A2 = 110.0,
      E3 = 164.81,
      F2 = 87.31,
      D3 = 146.83,
      B2 = 123.47;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      // --- Intro Harp Arpeggio (Beats 0-3) ---
      { voice: 'chord', freq: C4, beat: 0.0, duration: 0.8 },
      { voice: 'chord', freq: E4, beat: 0.5, duration: 0.8 },
      { voice: 'chord', freq: G4, beat: 1.0, duration: 0.8 },
      { voice: 'chord', freq: C5, beat: 1.5, duration: 0.8 },
      { voice: 'chord', freq: E5, beat: 2.0, duration: 1.5 },

      // --- A Melody: The Iconic 4/4 DQ Intermezzo ---
      // Measure 2 (Phrase 1): C5 -> D5 E5 F5 -> G5
      { voice: 'lead', freq: C5, beat: 4.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 5.0, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 5.5, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 6.0, duration: 1.0 },
      { voice: 'lead', freq: G5, beat: 7.0, duration: 2.0 },

      // Measure 3: E5 -> C5 -> D5 E5 F5 -> G5 (whole note)
      { voice: 'lead', freq: E5, beat: 9.0, duration: 2.0 },
      { voice: 'lead', freq: C5, beat: 11.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 12.0, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 12.5, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 13.0, duration: 1.0 },
      { voice: 'lead', freq: G5, beat: 14.0, duration: 3.5 },

      // Measure 4: A5 -> G5 F5 E5 -> D5
      { voice: 'lead', freq: A5, beat: 18.0, duration: 1.0 },
      { voice: 'lead', freq: G5, beat: 19.0, duration: 0.5 },
      { voice: 'lead', freq: F5, beat: 19.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 20.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 21.0, duration: 2.0 },
      { voice: 'lead', freq: B4, beat: 23.0, duration: 1.0 },
      { voice: 'lead', freq: C5, beat: 24.0, duration: 3.5 },

      // --- B Melody: Secondary Phrase ---
      // Measure 5: A4 -> B4 C5 D5 -> E5
      { voice: 'lead', freq: A4, beat: 28.0, duration: 1.0 },
      { voice: 'lead', freq: B4, beat: 29.0, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 29.5, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 30.0, duration: 1.0 },
      { voice: 'lead', freq: E5, beat: 31.0, duration: 2.0 },

      // Measure 6: C5 -> A4 -> B4 C5 D5 -> E5 (whole note)
      { voice: 'lead', freq: C5, beat: 33.0, duration: 2.0 },
      { voice: 'lead', freq: A4, beat: 35.0, duration: 1.0 },
      { voice: 'lead', freq: B4, beat: 36.0, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 36.5, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 37.0, duration: 1.0 },
      { voice: 'lead', freq: E5, beat: 38.0, duration: 3.5 },

      // Measure 7: F5 -> E5 D5 C5 -> D5 -> B4 -> C5
      { voice: 'lead', freq: F5, beat: 42.0, duration: 1.0 },
      { voice: 'lead', freq: E5, beat: 43.0, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 43.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 44.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 45.0, duration: 2.0 },
      { voice: 'lead', freq: B4, beat: 47.0, duration: 1.0 },
      { voice: 'lead', freq: C5, beat: 48.0, duration: 3.5 },

      // --- Gentle Chamber Strings / Harp Accompaniment ---
      // M2 (C major)
      { voice: 'bass', freq: C3, beat: 4.0, duration: 1.5 },
      { voice: 'chord', freq: E4, beat: 5.0, duration: 0.8 },
      { voice: 'chord', freq: G4, beat: 6.0, duration: 0.8 },
      { voice: 'bass', freq: G2, beat: 7.0, duration: 1.5 },
      { voice: 'chord', freq: E4, beat: 8.0, duration: 0.8 },

      // M3 (Em / Am)
      { voice: 'bass', freq: E3, beat: 9.0, duration: 1.5 },
      { voice: 'chord', freq: G4, beat: 10.0, duration: 0.8 },
      { voice: 'chord', freq: B4, beat: 11.0, duration: 0.8 },
      { voice: 'bass', freq: A2, beat: 12.0, duration: 1.5 },
      { voice: 'chord', freq: C4, beat: 13.0, duration: 0.8 },
      { voice: 'chord', freq: E4, beat: 14.0, duration: 0.8 },
      { voice: 'chord', freq: G4, beat: 15.0, duration: 0.8 },

      // M4 (F / Dm / G7)
      { voice: 'bass', freq: F2, beat: 18.0, duration: 1.5 },
      { voice: 'chord', freq: A4, beat: 19.0, duration: 0.8 },
      { voice: 'chord', freq: C5, beat: 20.0, duration: 0.8 },
      { voice: 'bass', freq: G2, beat: 21.0, duration: 1.5 },
      { voice: 'chord', freq: B4, beat: 22.0, duration: 0.8 },
      { voice: 'chord', freq: D5, beat: 23.0, duration: 0.8 },

      // M5 (C)
      { voice: 'bass', freq: C3, beat: 24.0, duration: 1.5 },
      { voice: 'chord', freq: E4, beat: 25.0, duration: 0.8 },
      { voice: 'chord', freq: G4, beat: 26.0, duration: 0.8 },

      // M6 (Am / Em)
      { voice: 'bass', freq: A2, beat: 28.0, duration: 1.5 },
      { voice: 'chord', freq: C4, beat: 29.0, duration: 0.8 },
      { voice: 'chord', freq: E4, beat: 30.0, duration: 0.8 },
      { voice: 'bass', freq: E3, beat: 31.0, duration: 1.5 },
      { voice: 'chord', freq: G4, beat: 32.0, duration: 0.8 },

      // M7 (Am)
      { voice: 'bass', freq: A2, beat: 33.0, duration: 1.5 },
      { voice: 'chord', freq: C4, beat: 34.0, duration: 0.8 },
      { voice: 'chord', freq: E4, beat: 35.0, duration: 0.8 },
      { voice: 'bass', freq: E3, beat: 36.0, duration: 1.5 },
      { voice: 'chord', freq: G4, beat: 37.0, duration: 0.8 },

      // M8 (Dm / G7 / C)
      { voice: 'bass', freq: D3, beat: 42.0, duration: 1.5 },
      { voice: 'chord', freq: F4, beat: 43.0, duration: 0.8 },
      { voice: 'chord', freq: A4, beat: 44.0, duration: 0.8 },
      { voice: 'bass', freq: G2, beat: 45.0, duration: 1.5 },
      { voice: 'chord', freq: B4, beat: 46.0, duration: 0.8 },
      { voice: 'chord', freq: D5, beat: 47.0, duration: 0.8 },

      { voice: 'bass', freq: C3, beat: 48.0, duration: 2.5 },
      { voice: 'chord', freq: E4, beat: 49.0, duration: 1.0 },
      { voice: 'chord', freq: G4, beat: 50.0, duration: 1.0 },
      { voice: 'chord', freq: C5, beat: 51.0, duration: 1.0 },
    ];

    this.scheduleTrack(136, 52, notes);
  }

  // =========================================================================
  // 3. 街のBGM (Town Theme - 街の人々 3/4拍子ワルツ)
  // =========================================================================
  private playVillageLoop() {
    const C4 = 261.63,
      D4 = 293.66,
      E4 = 329.63,
      F4 = 349.23,
      G4 = 392.0,
      A4 = 440.0,
      B4 = 493.88;
    const C5 = 523.25,
      D5 = 587.33,
      E5 = 659.25;
    const C3 = 130.81,
      G3 = 196.0,
      A3 = 220.0,
      F3 = 174.61;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      { voice: 'lead', freq: C5, beat: 0.0, duration: 1.0 },
      { voice: 'lead', freq: B4, beat: 1.0, duration: 1.0 },
      { voice: 'lead', freq: A4, beat: 2.0, duration: 1.0 },
      { voice: 'lead', freq: G4, beat: 3.0, duration: 3.0 },

      { voice: 'lead', freq: F4, beat: 6.0, duration: 1.0 },
      { voice: 'lead', freq: E4, beat: 7.0, duration: 1.0 },
      { voice: 'lead', freq: D4, beat: 8.0, duration: 1.0 },
      { voice: 'lead', freq: E4, beat: 9.0, duration: 3.0 },

      { voice: 'lead', freq: F4, beat: 12.0, duration: 1.0 },
      { voice: 'lead', freq: G4, beat: 13.0, duration: 1.0 },
      { voice: 'lead', freq: A4, beat: 14.0, duration: 1.0 },
      { voice: 'lead', freq: G4, beat: 15.0, duration: 2.0 },
      { voice: 'lead', freq: C5, beat: 17.0, duration: 1.0 },

      { voice: 'lead', freq: D5, beat: 18.0, duration: 1.0 },
      { voice: 'lead', freq: C5, beat: 19.0, duration: 1.0 },
      { voice: 'lead', freq: B4, beat: 20.0, duration: 1.0 },
      { voice: 'lead', freq: C5, beat: 21.0, duration: 3.0 },

      // Waltz bass (root, chord, chord)
      { voice: 'bass', freq: C3, beat: 0, duration: 1 },
      { voice: 'chord', freq: E4, beat: 1, duration: 0.8 },
      { voice: 'chord', freq: G4, beat: 2, duration: 0.8 },

      { voice: 'bass', freq: A3, beat: 3, duration: 1 },
      { voice: 'chord', freq: C4, beat: 4, duration: 0.8 },
      { voice: 'chord', freq: E4, beat: 5, duration: 0.8 },

      { voice: 'bass', freq: F3, beat: 6, duration: 1 },
      { voice: 'chord', freq: A3, beat: 7, duration: 0.8 },
      { voice: 'chord', freq: C4, beat: 8, duration: 0.8 },

      { voice: 'bass', freq: G3, beat: 9, duration: 1 },
      { voice: 'chord', freq: B4, beat: 10, duration: 0.8 },
      { voice: 'chord', freq: D4, beat: 11, duration: 0.8 },

      { voice: 'bass', freq: F3, beat: 12, duration: 1 },
      { voice: 'chord', freq: A3, beat: 13, duration: 0.8 },
      { voice: 'chord', freq: C4, beat: 14, duration: 0.8 },

      { voice: 'bass', freq: C3, beat: 15, duration: 1 },
      { voice: 'chord', freq: E4, beat: 16, duration: 0.8 },
      { voice: 'chord', freq: G4, beat: 17, duration: 0.8 },

      { voice: 'bass', freq: G3, beat: 18, duration: 1 },
      { voice: 'chord', freq: B4, beat: 19, duration: 0.8 },
      { voice: 'chord', freq: D4, beat: 20, duration: 0.8 },

      { voice: 'bass', freq: C3, beat: 21, duration: 2 },
    ];

    this.scheduleTrack(100, 24, notes);
  }

  // =========================================================================
  // 4. フィールドBGM (広野を行く / 果てしなき世界 4/4拍子マーチ)
  // =========================================================================
  private playFieldLoop() {
    const C4 = 261.63,
      D4 = 293.66,
      E4 = 329.63,
      F4 = 349.23,
      G4 = 392.0,
      A4 = 440.0,
      Bb4 = 466.16;
    const C5 = 523.25,
      D5 = 587.33,
      E5 = 659.25;
    const C3 = 130.81,
      G3 = 196.0,
      Bb3 = 233.08,
      F3 = 174.61;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      { voice: 'lead', freq: C5, beat: 0, duration: 1.5 },
      { voice: 'lead', freq: G4, beat: 1.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 2.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 3.0, duration: 1.0 },

      { voice: 'lead', freq: E5, beat: 4.0, duration: 1.5 },
      { voice: 'lead', freq: D5, beat: 5.5, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 6.0, duration: 1.0 },
      { voice: 'lead', freq: Bb4, beat: 7.0, duration: 1.0 },

      { voice: 'lead', freq: A4, beat: 8.0, duration: 1.5 },
      { voice: 'lead', freq: C5, beat: 9.5, duration: 0.5 },
      { voice: 'lead', freq: G4, beat: 10.0, duration: 2.0 },

      { voice: 'lead', freq: F4, beat: 12.0, duration: 1.0 },
      { voice: 'lead', freq: G4, beat: 13.0, duration: 1.0 },
      { voice: 'lead', freq: C5, beat: 14.0, duration: 2.0 },

      // Galloping bassline
      { voice: 'bass', freq: C3, beat: 0, duration: 0.5 },
      { voice: 'bass', freq: C3, beat: 0.75, duration: 0.25 },
      { voice: 'bass', freq: G3, beat: 1.0, duration: 0.5 },
      { voice: 'bass', freq: C3, beat: 2.0, duration: 0.5 },
      { voice: 'bass', freq: G3, beat: 3.0, duration: 0.5 },

      { voice: 'bass', freq: C3, beat: 4, duration: 0.5 },
      { voice: 'bass', freq: Bb3, beat: 5, duration: 0.5 },
      { voice: 'bass', freq: Bb3, beat: 6, duration: 0.5 },
      { voice: 'bass', freq: Bb3, beat: 7, duration: 0.5 },

      { voice: 'bass', freq: F3, beat: 8, duration: 0.5 },
      { voice: 'bass', freq: F3, beat: 9, duration: 0.5 },
      { voice: 'bass', freq: G3, beat: 10, duration: 0.5 },
      { voice: 'bass', freq: G3, beat: 11, duration: 0.5 },

      { voice: 'bass', freq: C3, beat: 12, duration: 1.0 },
      { voice: 'bass', freq: G3, beat: 13, duration: 1.0 },
      { voice: 'bass', freq: C3, beat: 14, duration: 2.0 },
    ];

    this.scheduleTrack(118, 16, notes);
  }

  // =========================================================================
  // 5. 通常戦闘BGM (勇気ある戦い - Fast driving D minor battle)
  // =========================================================================
  private playBattleLoop() {
    const D4 = 293.66,
      F4 = 349.23,
      G4 = 392.0,
      A4 = 440.0,
      C5 = 523.25,
      D5 = 587.33,
      E5 = 659.25,
      F5 = 698.46;
    const D3 = 146.83,
      F3 = 174.61,
      G3 = 196.0,
      A3 = 220.0,
      C4 = 261.63;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      // Melodic phrase
      { voice: 'lead', freq: D5, beat: 0.0, duration: 0.4 },
      { voice: 'lead', freq: D5, beat: 0.5, duration: 0.4 },
      { voice: 'lead', freq: F5, beat: 1.0, duration: 0.75 },
      { voice: 'lead', freq: E5, beat: 1.75, duration: 0.25 },
      { voice: 'lead', freq: D5, beat: 2.0, duration: 0.5 },
      { voice: 'lead', freq: C5, beat: 2.5, duration: 0.5 },
      { voice: 'lead', freq: A4, beat: 3.0, duration: 1.0 },

      { voice: 'lead', freq: D5, beat: 4.0, duration: 0.4 },
      { voice: 'lead', freq: D5, beat: 4.5, duration: 0.4 },
      { voice: 'lead', freq: F5, beat: 5.0, duration: 0.5 },
      { voice: 'lead', freq: G4, beat: 5.5, duration: 0.5 },
      { voice: 'lead', freq: A4, beat: 6.0, duration: 0.5 },
      { voice: 'lead', freq: D5, beat: 6.5, duration: 1.5 },

      // Staccato 16th bass
      { voice: 'bass', freq: D3, beat: 0.0, duration: 0.2 },
      { voice: 'bass', freq: D3, beat: 0.5, duration: 0.2 },
      { voice: 'bass', freq: D3, beat: 1.0, duration: 0.2 },
      { voice: 'bass', freq: D3, beat: 1.5, duration: 0.2 },
      { voice: 'bass', freq: D3, beat: 2.0, duration: 0.2 },
      { voice: 'bass', freq: D3, beat: 2.5, duration: 0.2 },
      { voice: 'bass', freq: A3, beat: 3.0, duration: 0.2 },
      { voice: 'bass', freq: C4, beat: 3.5, duration: 0.2 },

      { voice: 'bass', freq: D3, beat: 4.0, duration: 0.2 },
      { voice: 'bass', freq: D3, beat: 4.5, duration: 0.2 },
      { voice: 'bass', freq: F3, beat: 5.0, duration: 0.2 },
      { voice: 'bass', freq: G3, beat: 5.5, duration: 0.2 },
      { voice: 'bass', freq: A3, beat: 6.0, duration: 0.4 },
      { voice: 'bass', freq: D3, beat: 7.0, duration: 0.4 },
    ];

    // Driving percussion
    for (let b = 0; b < 8; b++) {
      notes.push({ voice: 'kick', freq: 0, beat: b, duration: 0.1 });
      notes.push({ voice: 'snare', freq: 0, beat: b + 0.5, duration: 0.1 });
    }

    this.scheduleTrack(144, 8, notes);
  }

  // =========================================================================
  // 6. 洞窟・ダンジョンBGM
  // =========================================================================
  private playDungeonLoop() {
    const C4 = 261.63,
      Eb4 = 311.13,
      F4 = 349.23,
      Fs4 = 369.99,
      G4 = 392.0,
      Ab4 = 415.3,
      B4 = 493.88;
    const C3 = 130.81,
      G2 = 98.0,
      Ab2 = 103.83;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      { voice: 'lead', freq: C4, beat: 0, duration: 0.8 },
      { voice: 'lead', freq: Eb4, beat: 1, duration: 0.8 },
      { voice: 'lead', freq: Fs4, beat: 2, duration: 0.8 },
      { voice: 'lead', freq: G4, beat: 3, duration: 1.5 },

      { voice: 'lead', freq: Ab4, beat: 5, duration: 0.8 },
      { voice: 'lead', freq: G4, beat: 6, duration: 0.8 },
      { voice: 'lead', freq: F4, beat: 7, duration: 0.8 },
      { voice: 'lead', freq: Eb4, beat: 8, duration: 1.5 },

      { voice: 'lead', freq: Fs4, beat: 10, duration: 0.8 },
      { voice: 'lead', freq: F4, beat: 11, duration: 0.8 },
      { voice: 'lead', freq: Eb4, beat: 12, duration: 0.8 },
      { voice: 'lead', freq: C4, beat: 13, duration: 2.5 },

      { voice: 'bass', freq: C3, beat: 0, duration: 2.0 },
      { voice: 'bass', freq: G2, beat: 4, duration: 2.0 },
      { voice: 'bass', freq: Ab2, beat: 8, duration: 2.0 },
      { voice: 'bass', freq: G2, beat: 12, duration: 3.0 },
    ];

    this.scheduleTrack(84, 16, notes);
  }

  // =========================================================================
  // 7. ボス戦BGM
  // =========================================================================
  private playBossLoop() {
    const C4 = 261.63,
      Eb4 = 311.13,
      F4 = 349.23,
      Fs4 = 369.99,
      G4 = 392.0,
      Bb4 = 466.16,
      C5 = 523.25;
    const C3 = 130.81,
      Eb3 = 155.56,
      G3 = 196.0;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      { voice: 'lead', freq: C5, beat: 0, duration: 0.5 },
      { voice: 'lead', freq: Bb4, beat: 0.5, duration: 0.5 },
      { voice: 'lead', freq: G4, beat: 1.0, duration: 0.5 },
      { voice: 'lead', freq: Fs4, beat: 1.5, duration: 0.5 },
      { voice: 'lead', freq: F4, beat: 2.0, duration: 0.5 },
      { voice: 'lead', freq: Eb4, beat: 2.5, duration: 0.5 },
      { voice: 'lead', freq: C4, beat: 3.0, duration: 1.0 },

      { voice: 'lead', freq: C5, beat: 4, duration: 0.5 },
      { voice: 'lead', freq: Eb4, beat: 5, duration: 0.5 },
      { voice: 'lead', freq: Fs4, beat: 6, duration: 0.5 },
      { voice: 'lead', freq: G4, beat: 7, duration: 1.0 },

      { voice: 'bass', freq: C3, beat: 0, duration: 0.4 },
      { voice: 'bass', freq: C3, beat: 0.5, duration: 0.4 },
      { voice: 'bass', freq: Eb3, beat: 1, duration: 0.4 },
      { voice: 'bass', freq: G3, beat: 1.5, duration: 0.4 },
      { voice: 'bass', freq: C3, beat: 2, duration: 0.4 },
      { voice: 'bass', freq: C3, beat: 2.5, duration: 0.4 },
      { voice: 'bass', freq: Eb3, beat: 3, duration: 0.8 },
    ];

    for (let b = 0; b < 8; b++) {
      notes.push({ voice: 'kick', freq: 0, beat: b, duration: 0.1 });
      notes.push({ voice: 'snare', freq: 0, beat: b + 0.5, duration: 0.1 });
    }

    this.scheduleTrack(150, 8, notes);
  }

  // =========================================================================
  // 8. ラストボスBGM (大魔王ネビュロス)
  // =========================================================================
  private playLastBossLoop() {
    const D4 = 293.66,
      Eb4 = 311.13,
      Fs4 = 369.99,
      G4 = 392.0,
      A4 = 440.0,
      Bb4 = 466.16,
      Cs5 = 554.37,
      D5 = 587.33;
    const D3 = 146.83,
      Bb2 = 116.54,
      A2 = 110.0,
      G2 = 98.0;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      { voice: 'lead', freq: D5, beat: 0, duration: 1.0 },
      { voice: 'lead', freq: Cs5, beat: 1, duration: 1.0 },
      { voice: 'lead', freq: Bb4, beat: 2, duration: 1.0 },
      { voice: 'lead', freq: A4, beat: 3, duration: 1.0 },

      { voice: 'lead', freq: G4, beat: 4, duration: 1.0 },
      { voice: 'lead', freq: Fs4, beat: 5, duration: 1.0 },
      { voice: 'lead', freq: Eb4, beat: 6, duration: 1.0 },
      { voice: 'lead', freq: D4, beat: 7, duration: 1.0 },

      { voice: 'bass', freq: D3, beat: 0, duration: 2.0 },
      { voice: 'bass', freq: Bb2, beat: 2, duration: 2.0 },
      { voice: 'bass', freq: G2, beat: 4, duration: 2.0 },
      { voice: 'bass', freq: A2, beat: 6, duration: 2.0 },
    ];

    this.scheduleTrack(128, 8, notes);
  }

  // =========================================================================
  // 9. エンディングBGM (そして伝説へ)
  // =========================================================================
  private playEndingLoop() {
    const C4 = 261.63,
      D4 = 293.66,
      E4 = 329.63,
      F4 = 349.23,
      G4 = 392.0,
      A4 = 440.0,
      B4 = 493.88;
    const C5 = 523.25,
      D5 = 587.33,
      E5 = 659.25,
      F5 = 698.46,
      G5 = 783.99;
    const C3 = 130.81,
      E3 = 164.81,
      G3 = 196.0,
      A3 = 220.0,
      F3 = 174.61;

    type TrackNote = {
      voice: 'lead' | 'harmony' | 'bass' | 'chord' | 'snare' | 'kick';
      freq: number;
      beat: number;
      duration: number;
    };

    const notes: TrackNote[] = [
      { voice: 'lead', freq: E5, beat: 0, duration: 1.5 },
      { voice: 'lead', freq: F5, beat: 1.5, duration: 0.5 },
      { voice: 'lead', freq: G5, beat: 2.0, duration: 2.0 },

      { voice: 'lead', freq: C5, beat: 4.0, duration: 1.5 },
      { voice: 'lead', freq: D5, beat: 5.5, duration: 0.5 },
      { voice: 'lead', freq: E5, beat: 6.0, duration: 2.0 },

      { voice: 'lead', freq: F5, beat: 8.0, duration: 1.0 },
      { voice: 'lead', freq: E5, beat: 9.0, duration: 1.0 },
      { voice: 'lead', freq: D5, beat: 10.0, duration: 1.0 },
      { voice: 'lead', freq: C5, beat: 11.0, duration: 2.0 },

      { voice: 'bass', freq: C3, beat: 0, duration: 2.0 },
      { voice: 'bass', freq: G3, beat: 2, duration: 2.0 },
      { voice: 'bass', freq: A3, beat: 4, duration: 2.0 },
      { voice: 'bass', freq: E3, beat: 6, duration: 2.0 },
      { voice: 'bass', freq: F3, beat: 8, duration: 2.0 },
      { voice: 'bass', freq: C3, beat: 10, duration: 3.0 },
    ];

    this.scheduleTrack(96, 14, notes);
  }
}

export const dqAudio = new DQAudioEngine();
