import React, { useState, useEffect, useCallback } from 'react';
import {
  Character,
  MapData,
  Monster,
  StoryChapter,
  TabletPiece,
  GameSaveData,
} from './types/game';
import { MAPS } from './data/mapsData';
import {
  createInitialHero,
  createJansen,
  createSierra,
  INITIAL_TABLETS,
  ITEMS,
  MONSTERS_POOL,
  BOSS_BAREN,
  BOSS_GALGARD,
  BOSS_NEBULOS_PHASE1,
  BOSS_NEBULOS_PHASE2,
} from './data/gameData';
import { dqAudio } from './audio/dqAudio';
import { Map3DView } from './components/Map3DView';
import { MapCanvas } from './components/MapCanvas';
import { BattleScreen } from './components/BattleScreen';
import { DialogueBox } from './components/DialogueBox';
import { GameMenuModal } from './components/GameMenuModal';
import { TitleScreen } from './components/TitleScreen';
import { EndingScreen } from './components/EndingScreen';
import { TavernModal } from './components/TavernModal';

const SAVE_KEY = 'dq13_save_data_slot_1';

export default function App() {
  const [gameState, setGameState] = useState<'TITLE' | 'EXPLORING' | 'BATTLE' | 'ENDING'>('TITLE');
  const [viewMode3D, setViewMode3D] = useState<boolean>(true); // Default to 3D!
  const [hasSaveData, setHasSaveData] = useState<boolean>(false);

  // Story & World State
  const [heroName, setHeroName] = useState<string>('アレク');
  const [party, setParty] = useState<Character[]>([createInitialHero('アレク')]);
  const [tavernRoster, setTavernRoster] = useState<Character[]>([]);
  const [inventory, setInventory] = useState<{ itemId: string; count: number }[]>([
    { itemId: 'yakusou', count: 4 },
    { itemId: 'seisui', count: 2 },
  ]);
  const [gold, setGold] = useState<number>(50);
  const [tablets, setTablets] = useState<TabletPiece[]>(INITIAL_TABLETS);
  const [storyChapter, setStoryChapter] = useState<StoryChapter>('CH1_KOKOYA_START');

  // Map & Navigation
  const [currentMapId, setCurrentMapId] = useState<string>('kokoya_village');
  const [playerPos, setPlayerPos] = useState<{ x: number; y: number; dir: 'up' | 'down' | 'left' | 'right' }>({
    x: 5,
    y: 6,
    dir: 'down',
  });
  const [openedChestIds, setOpenedChestIds] = useState<string[]>([]);
  const [flags, setFlags] = useState<Record<string, boolean>>({});

  // Active Overlays
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isTavernOpen, setIsTavernOpen] = useState<boolean>(false);
  const [activeDialogue, setActiveDialogue] = useState<{
    speaker?: string;
    messages: string[];
    options?: { label: string; value: string }[];
    onFinish: () => void;
    onSelectOption?: (val: string) => void;
  } | null>(null);

  // Battle State
  const [battleParams, setBattleParams] = useState<{
    monsters: Monster[];
    isBoss: boolean;
    isLastBoss: boolean;
    backgroundTheme: 'plains' | 'town' | 'castle' | 'dark_abyss';
    bossType?: 'baren' | 'galgard' | 'nebulos_1' | 'nebulos_2';
  } | null>(null);

  // Check save data
  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        setHasSaveData(true);
      }
    } catch {
      // Ignore storage errors
    }
  }, []);

  // Update BGM when map changes or returning to exploration
  useEffect(() => {
    if (gameState === 'EXPLORING') {
      const map = MAPS[currentMapId];
      if (map) {
        dqAudio.playBgm(map.bgm);
      }
    }
  }, [currentMapId, gameState]);

  // Save Game
  const saveGame = useCallback(() => {
    const heroChar = party.find(p => p.id === 'hero') || party[0];
    const data: GameSaveData = {
      heroName,
      heroAppearance: heroChar.appearance || {
        gender: 'male',
        hairColor: '#3b82f6',
        outfitColor: '#2563eb',
        vocation: 'hero',
        personality: '熱血漢',
      },
      party,
      tavernRoster,
      inventory,
      gold,
      tablets,
      storyChapter,
      currentMapId,
      playerPos,
      openedChestIds,
      flags,
      playTimeMinutes: 0,
      timestamp: Date.now(),
    };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      setHasSaveData(true);
    } catch (e) {
      console.error('Save failed', e);
    }
  }, [heroName, party, tavernRoster, inventory, gold, tablets, storyChapter, currentMapId, playerPos, openedChestIds, flags]);

  // Load Game
  const loadGame = useCallback(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const data: GameSaveData = JSON.parse(raw);

      setHeroName(data.heroName);
      setParty(data.party);
      setTavernRoster(data.tavernRoster || []);
      setInventory(data.inventory);
      setGold(data.gold);
      setTablets(data.tablets);
      setStoryChapter(data.storyChapter);
      setCurrentMapId(data.currentMapId);
      setPlayerPos(data.playerPos);
      setOpenedChestIds(data.openedChestIds);
      setFlags(data.flags || {});

      dqAudio.playConfirm();
      setGameState('EXPLORING');
    } catch (e) {
      console.error('Load failed', e);
    }
  }, []);

  // Start New Game with Created Hero
  const startNewGameWithHero = (createdHero: Character) => {
    setHeroName(createdHero.name);
    setParty([createdHero]);
    setTavernRoster([]);
    setInventory([
      { itemId: 'yakusou', count: 4 },
      { itemId: 'seisui', count: 2 },
    ]);
    setGold(50);
    setTablets(INITIAL_TABLETS.map(t => ({ ...t })));
    setStoryChapter('CH1_KOKOYA_START');
    setCurrentMapId('kokoya_village');
    setPlayerPos({ x: 5, y: 6, dir: 'down' });
    setOpenedChestIds([]);
    setFlags({});
    setGameState('EXPLORING');
  };

  // Keyboard shortcut for menu (X key)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'EXPLORING' || activeDialogue || isTavernOpen) return;
      if (e.key === 'x' || e.key === 'X' || e.key === 'Escape') {
        e.preventDefault();
        dqAudio.playConfirm();
        setIsMenuOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, activeDialogue, isTavernOpen]);

  // Interaction handlers
  const handleInteract = (target: { type: 'npc' | 'chest' | 'altar' | 'pedestal' | 'bed' | 'tavern'; data: any }) => {
    if (target.type === 'npc') {
      handleNpcInteract(target.data);
    } else if (target.type === 'chest') {
      handleChestOpen(target.data);
    } else if (target.type === 'altar') {
      handleAltarPray();
    } else if (target.type === 'pedestal') {
      handlePedestalInspect();
    } else if (target.type === 'bed') {
      handleInnRest();
    } else if (target.type === 'tavern') {
      dqAudio.playConfirm();
      setIsTavernOpen(true);
    }
  };

  // NPC dialogue and quest trigger handling
  const handleNpcInteract = (npc: any) => {
    // Luida's Tavern NPC
    if (npc.id === 'luida') {
      dqAudio.playConfirm();
      setIsTavernOpen(true);
      return;
    }

    // 1. Elina Disappear Event (Kokoya Village)
    if (npc.id === 'elina') {
      if (flags['elina_disappeared']) {
        setActiveDialogue({
          speaker: '（調べた）',
          messages: npc.dialogueAfter,
          onFinish: () => setActiveDialogue(null),
        });
      } else {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueBefore,
          onFinish: () => {
            setFlags(prev => ({ ...prev, elina_disappeared: true }));
            setActiveDialogue(null);
            dqAudio.playMagic();
          },
        });
      }
      return;
    }

    // 2. Pedestal Spirit (Ancient Altar)
    if (npc.id === 'pedestal_spirit') {
      const hasBlue = tablets.find(t => t.id === 'blue')?.found;
      if (hasBlue) {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueAfter,
          onFinish: () => setActiveDialogue(null),
        });
      } else {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueBefore,
          onFinish: () => {
            dqAudio.playTabletChime();
            setTablets(prev => prev.map(t => t.id === 'blue' ? { ...t, found: true, placed: true } : t));
            setStoryChapter('CH1_PEDESTAL_DISCOVERY');
            setActiveDialogue({
              speaker: 'システム',
              messages: [
                '【記憶の石版・青】を手に入れた！',
                '古びた台座に石版をはめ込むと、青い光が天を突き抜け、悲恋の街バーレンへの道が開かれた！',
              ],
              onFinish: () => setActiveDialogue(null),
            });
          },
        });
      }
      return;
    }

    // 3. Baren Memory Altar Event (Boss 1)
    if (npc.id === 'baren_event_altar') {
      if (flags['baren_cleared']) {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueAfter,
          onFinish: () => setActiveDialogue(null),
        });
      } else {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueBefore,
          onFinish: () => {
            setActiveDialogue(null);
            startBattle([BOSS_BAREN], true, false, 'town', 'baren');
          },
        });
      }
      return;
    }

    // 4. Jansen NPC Join (Baren)
    if (npc.id === 'baren_jansen_npc') {
      if (party.some(p => p.id === 'jansen') || tavernRoster.some(p => p.id === 'jansen')) {
        setActiveDialogue({
          speaker: npc.name,
          messages: ['「俺の豪快な剣技、いつでも頼りにしてくれよな！」'],
          onFinish: () => setActiveDialogue(null),
        });
      } else if (flags['baren_cleared']) {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueAfter,
          onFinish: () => {
            dqAudio.playLevelUp();
            const jansen = createJansen();
            if (party.length < 4) {
              setParty(prev => [...prev, jansen]);
            } else {
              setTavernRoster(prev => [...prev, jansen]);
            }
            setActiveDialogue(null);
          },
        });
      } else {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueBefore,
          onFinish: () => setActiveDialogue(null),
        });
      }
      return;
    }

    // 5. Galgard King Arthur Event / Mirror Altar (Boss 2)
    if (npc.id === 'galgard_event_altar') {
      if (flags['galgard_cleared']) {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueAfter,
          onFinish: () => setActiveDialogue(null),
        });
      } else {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueBefore,
          onFinish: () => {
            setActiveDialogue(null);
            startBattle([BOSS_GALGARD], true, false, 'castle', 'galgard');
          },
        });
      }
      return;
    }

    // 6. Sierra NPC Join (Galgard)
    if (npc.id === 'sierra_npc') {
      if (party.some(p => p.id === 'sierra') || tavernRoster.some(p => p.id === 'sierra')) {
        setActiveDialogue({
          speaker: npc.name,
          messages: ['「大聖堂の真実を暴き、この歪んだ世界を救いましょう。」'],
          onFinish: () => setActiveDialogue(null),
        });
      } else if (flags['galgard_cleared']) {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueAfter,
          onFinish: () => {
            dqAudio.playLevelUp();
            const sierra = createSierra();
            if (party.length < 4) {
              setParty(prev => [...prev, sierra]);
            } else {
              setTavernRoster(prev => [...prev, sierra]);
            }
            setActiveDialogue(null);
          },
        });
      } else {
        setActiveDialogue({
          speaker: npc.name,
          messages: npc.dialogueBefore,
          onFinish: () => setActiveDialogue(null),
        });
      }
      return;
    }

    // 7. Grandzeil Pope & Cathedral Core Break
    if (npc.id === 'grandzeil_pope' || npc.id === 'cathedral_core_object') {
      if (flags['core_shattered']) {
        setActiveDialogue({
          speaker: '大教皇イノケンティウス',
          messages: [
            '「魔界の城へ急ぐのだ、13番目の勇者よ！」',
            '「人々の心を救えるのは、お前たちの勇気だけだ！」',
          ],
          onFinish: () => setActiveDialogue(null),
        });
      } else {
        setActiveDialogue({
          speaker: '大教皇イノケンティウス',
          messages: [
            '「よくぞ参られました、13番目の勇者の末裔よ。」',
            '「100年前、大魔王を道連れに封印したのは、12人の聖職者ではなく、お前さんの先祖『13番目の勇者』だったのです。」',
            '「だが大魔王は人々の絶望を吸って蘇ろうとする。ゆえに我らは民の記憶から悲しみを消去してきた……！」',
            '「しかし……見ての通り、100年分の絶望を溜め込んだコアは、もう限界だ……！！」',
            '（ドオオオォォォンッ！！ 祭壇のコアに亀裂が入り、黒い衝撃波が世界を覆い尽くした！！）',
            '「クハハハ……！ 100年の忘却を破り、大魔王ネビュロスが復活したぞ！！」',
            '（北東の地に【魔界の城】が出現した！ 【記憶の石版・闇】を手に入れた！）',
          ],
          onFinish: () => {
            dqAudio.playCritical();
            setFlags(prev => ({ ...prev, core_shattered: true }));
            setTablets(prev => prev.map(t => t.id === 'dark' ? { ...t, found: true, placed: true } : t));
            setStoryChapter('CH4_CORE_SHATTERED');
            setActiveDialogue(null);
          },
        });
      }
      return;
    }

    // 8. Final Boss Nebulos in Demon Castle
    if (npc.id === 'final_boss_event') {
      setActiveDialogue({
        speaker: '大魔王ネビュロス',
        messages: npc.dialogueBefore,
        onFinish: () => {
          setActiveDialogue(null);
          startBattle([BOSS_NEBULOS_PHASE1], true, true, 'dark_abyss', 'nebulos_1');
        },
      });
      return;
    }

    // Standard NPC dialogue
    const isSolved = (currentMapId === 'town_baren' && flags['baren_cleared']) ||
                     (currentMapId === 'castle_galgard' && flags['galgard_cleared']) ||
                     (flags['core_shattered']);

    const messages = isSolved && npc.dialogueAfter.length > 0 ? npc.dialogueAfter : npc.dialogueBefore;

    setActiveDialogue({
      speaker: npc.name,
      messages: messages,
      onFinish: () => setActiveDialogue(null),
    });
  };

  // Open Chest
  const handleChestOpen = (chest: any) => {
    if (openedChestIds.includes(chest.id)) {
      setActiveDialogue({
        speaker: '（宝箱）',
        messages: ['宝箱は からっぽだ。'],
        onFinish: () => setActiveDialogue(null),
      });
      return;
    }

    setOpenedChestIds(prev => [...prev, chest.id]);
    const it = ITEMS[chest.item];
    const msgs: string[] = [];

    if (it) {
      msgs.push(`${heroName}は 宝箱をあけた！\n${it.name}を てにいれた！`);
      setInventory(prev => {
        const found = prev.find(i => i.itemId === it.id);
        if (found) {
          return prev.map(i => i.itemId === it.id ? { ...i, count: i.count + 1 } : i);
        }
        return [...prev, { itemId: it.id, count: 1 }];
      });
    }

    if (chest.gold) {
      msgs.push(`${chest.gold}ゴールドを てにいれた！`);
      setGold(prev => prev + chest.gold);
    }

    setActiveDialogue({
      speaker: '（宝箱）',
      messages: msgs,
      onFinish: () => setActiveDialogue(null),
    });
  };

  // Church Altar Save
  const handleAltarPray = () => {
    setActiveDialogue({
      speaker: '教会のお告げ',
      messages: [
        '「おお 神よ！ 旅立つ勇者たちに光の祝福を……」',
        'これまでの冒険の記録を 冒険の書にセーブしますか？',
      ],
      options: [
        { label: 'はい', value: 'yes' },
        { label: 'いいえ', value: 'no' },
      ],
      onFinish: () => setActiveDialogue(null),
      onSelectOption: (val) => {
        if (val === 'yes') {
          saveGame();
          dqAudio.playChurchJingle();
          setActiveDialogue({
            speaker: '神父',
            messages: ['「冒険の書に 記録いたしました。神の加護があらんことを！」'],
            onFinish: () => setActiveDialogue(null),
          });
        } else {
          setActiveDialogue(null);
        }
      },
    });
  };

  // Pedestal Inspect
  const handlePedestalInspect = () => {
    const placedCount = tablets.filter(t => t.placed).length;
    setActiveDialogue({
      speaker: '古代の台座',
      messages: [
        `（神秘的な光を放つ古代の台座だ。現在【${placedCount} / 4】の記憶の石版がはめ込まれている。）`,
        '記憶を取り戻すたび、世界に失われた真実の光が灯っていく……',
      ],
      onFinish: () => setActiveDialogue(null),
    });
  };

  // Inn Rest
  const handleInnRest = () => {
    if (gold < 10) {
      setActiveDialogue({
        speaker: '宿屋',
        messages: ['「おや、ゴールドが足りないようだね。10ゴールド貯まったらまたおいで！」'],
        onFinish: () => setActiveDialogue(null),
      });
      return;
    }

    setActiveDialogue({
      speaker: '宿屋',
      messages: ['「一晩10ゴールドだよ。ゆっくり休んで疲れを癒やすかい？」'],
      options: [
        { label: 'はい', value: 'yes' },
        { label: 'いいえ', value: 'no' },
      ],
      onFinish: () => setActiveDialogue(null),
      onSelectOption: (val) => {
        if (val === 'yes') {
          setGold(prev => prev - 10);
          setParty(prev => prev.map(c => ({
            ...c,
            hp: c.maxHp,
            mp: c.maxMp,
            status: 'normal',
          })));
          dqAudio.playInnJingle();
          setActiveDialogue({
            speaker: '宿屋',
            messages: ['「おはよう！ 体力がすっかり回復したようだね。いってらっしゃい！」'],
            onFinish: () => setActiveDialogue(null),
          });
        } else {
          setActiveDialogue(null);
        }
      },
    });
  };

  // Map Warp
  const handleWarp = (warp: { targetMap: string; targetX: number; targetY: number }) => {
    if ((warp.targetMap === 'demon_castle' || warp.targetMap === 'demon_castle_f1') && !flags['core_shattered']) {
      setActiveDialogue({
        speaker: '（結界）',
        messages: ['（禍々しい漆黒の結界に阻まれている！ 大聖堂の真実を明かさねば通れそうにない……）'],
        onFinish: () => setActiveDialogue(null),
      });
      return;
    }

    setCurrentMapId(warp.targetMap);
    setPlayerPos({ x: warp.targetX, y: warp.targetY, dir: 'down' });
  };

  // Start Battle (with dynamic location background!)
  const startBattle = (
    monsters: Monster[],
    isBoss: boolean,
    isLastBoss: boolean,
    backgroundTheme: 'plains' | 'town' | 'castle' | 'dark_abyss',
    bossType?: 'baren' | 'galgard' | 'nebulos_1' | 'nebulos_2'
  ) => {
    setIsMenuOpen(false);
    setActiveDialogue(null);
    setBattleParams({
      monsters,
      isBoss,
      isLastBoss,
      backgroundTheme,
      bossType,
    });
    setGameState('BATTLE');
  };

  // Symbol Encounter trigger from 3D View!
  const handleSymbolEncounter = (monsters: Monster[], symbolId: string) => {
    const map = MAPS[currentMapId];
    const theme = map?.battleBackground || 'plains';
    startBattle(monsters, false, false, theme);
  };

  // Random encounter generator for 2D fallback
  const triggerRandomEncounter = () => {
    const pool = [
      MONSTERS_POOL.slime,
      MONSTERS_POOL.dracky,
      MONSTERS_POOL.ghost,
      MONSTERS_POOL.magician,
    ];

    if (party.length >= 2) pool.push(MONSTERS_POOL.skeleton);
    if (party.length >= 3) pool.push(MONSTERS_POOL.shadowDemon);

    const count = Math.random() < 0.35 ? 2 : 1;
    const selected: Monster[] = [];
    for (let i = 0; i < count; i++) {
      const m = pool[Math.floor(Math.random() * pool.length)];
      selected.push({ ...m });
    }

    const map = MAPS[currentMapId];
    const theme = map?.battleBackground || 'plains';
    startBattle(selected, false, false, theme);
  };

  // Battle Finished Callback
  const handleBattleEnd = (result: {
    victory: boolean;
    expGained: number;
    goldGained: number;
    defeatedMonsters: Monster[];
    updatedParty: Character[];
  }) => {
    // ALWAYS preserve the leveled-up party stats and experience!
    if (result.updatedParty && result.updatedParty.length > 0) {
      setParty(result.updatedParty);
    }

    if (!result.victory) {
      setCurrentMapId('kokoya_village');
      setPlayerPos({ x: 9, y: 4, dir: 'down' });
      setGold(prev => Math.floor(prev / 2));
      const revivedParty = (result.updatedParty || party).map(c => ({
        ...c,
        hp: Math.max(1, Math.floor(c.maxHp / 2)),
        status: 'normal' as const,
      }));
      setParty(revivedParty);
      setGameState('EXPLORING');
      setActiveDialogue({
        speaker: '教会の神父',
        messages: ['「おお……神よ！ 力尽きた者たちに奇跡の息吹を……！ 気を確かに持つのです！」'],
        onFinish: () => setActiveDialogue(null),
      });
      return;
    }

    const currentGold = gold + result.goldGained;
    setGold(currentGold);

    // Auto-save progression so gained levels and exp are never lost!
    try {
      const heroChar = (result.updatedParty || party).find(p => p.id === 'hero') || party[0];
      const data: GameSaveData = {
        heroName,
        heroAppearance: heroChar.appearance || {
          gender: 'male',
          hairColor: '#3b82f6',
          outfitColor: '#2563eb',
          vocation: 'hero',
          personality: '熱血漢',
        },
        party: result.updatedParty || party,
        tavernRoster,
        inventory,
        gold: currentGold,
        tablets,
        storyChapter,
        currentMapId,
        playerPos,
        openedChestIds,
        flags,
        playTimeMinutes: 0,
        timestamp: Date.now(),
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      setHasSaveData(true);
    } catch {
      // Ignore local storage error
    }

    if (battleParams?.bossType === 'baren') {
      setFlags(prev => ({ ...prev, baren_cleared: true }));
      setTablets(prev => prev.map(t => t.id === 'red' ? { ...t, found: true, placed: true } : t));
      setStoryChapter('CH2_BAREN_BOSS_DEFEATED');
      setGameState('EXPLORING');
      setActiveDialogue({
        speaker: 'システム',
        messages: [
          '心の魔物「悲愛の魔獣」を打ち倒した！',
          '街の人々の心に、失われた愛の記憶がよみがえった！',
          '【記憶の石版・赤】を手に入れた！ ガルガルド城への道が開かれた！',
        ],
        onFinish: () => setActiveDialogue(null),
      });
      return;
    }

    if (battleParams?.bossType === 'galgard') {
      setFlags(prev => ({ ...prev, galgard_cleared: true }));
      setTablets(prev => prev.map(t => t.id === 'yellow' ? { ...t, found: true, placed: true } : t));
      setStoryChapter('CH3_GALGARD_BOSS_DEFEATED');
      setGameState('EXPLORING');
      setActiveDialogue({
        speaker: 'システム',
        messages: [
          '心の魔物「虚飾の魔神」を打ち倒した！',
          '国王アーサーは敗北の悔しさを力に変え、真の勇気を取り戻した！',
          '【記憶の石版・黄】を手に入れた！ 王都グランゼイルへの大門が開かれた！',
        ],
        onFinish: () => setActiveDialogue(null),
      });
      return;
    }

    if (battleParams?.isLastBoss || battleParams?.bossType === 'nebulos_1' || battleParams?.bossType === 'nebulos_2') {
      setGameState('ENDING');
      return;
    }

    setGameState('EXPLORING');
  };

  // Menu Use Item
  const handleUseItem = (itemId: string, targetCharIdx: number) => {
    const it = ITEMS[itemId];
    const targetChar = party[targetCharIdx];
    if (!it || !targetChar) return;

    if (itemId === 'yakusou' || itemId === 'jouyakusou') {
      targetChar.hp = Math.min(targetChar.maxHp, targetChar.hp + (it.effectValue || 35));
      dqAudio.playConfirm();
    } else if (itemId === 'seisui') {
      targetChar.mp = Math.min(targetChar.maxMp, targetChar.mp + 30);
      dqAudio.playConfirm();
    } else if (itemId === 'sekaiju') {
      targetChar.hp = targetChar.maxHp;
      targetChar.status = 'normal';
      dqAudio.playLevelUp();
    } else if (itemId === 'tsubasa') {
      setCurrentMapId('kokoya_village');
      setPlayerPos({ x: 5, y: 6, dir: 'down' });
      setIsMenuOpen(false);
      dqAudio.playMagic();
    }

    setInventory(prev => {
      return prev
        .map(i => i.itemId === itemId ? { ...i, count: i.count - 1 } : i)
        .filter(i => i.count > 0);
    });
  };

  // Menu Use Spell
  const handleUseSpell = (spellId: string, casterIdx: number, targetCharIdx: number) => {
    const caster = party[casterIdx];
    const targetChar = party[targetCharIdx];
    const spell = caster?.spells.find(s => s.id === spellId);
    if (!caster || !targetChar || !spell) return;

    if (caster.mp < spell.mpCost) {
      dqAudio.playCancel();
      return;
    }

    caster.mp -= spell.mpCost;
    if (spell.type === 'heal') {
      if (spell.target === 'all_allies') {
        party.forEach(p => {
          if (p.hp > 0) p.hp = Math.min(p.maxHp, p.hp + spell.power);
        });
      } else {
        targetChar.hp = Math.min(targetChar.maxHp, targetChar.hp + spell.power);
      }
      dqAudio.playLevelUp();
    }
    setParty([...party]);
  };

  return (
    <div className="relative w-screen h-screen bg-black flex flex-col items-center justify-center overflow-hidden font-sans select-none">
      {/* 1. Title Screen */}
      {gameState === 'TITLE' && (
        <TitleScreen
          hasSaveData={hasSaveData}
          onStartNewGame={startNewGameWithHero}
          onLoadGame={loadGame}
        />
      )}

      {/* 2. Active Exploration (3D / 2D) */}
      {gameState === 'EXPLORING' && (
        <div className="relative w-full h-full flex flex-col justify-between">
          {/* Top Bar HUD */}
          <div className="absolute top-2 left-0 right-0 z-30 flex items-center justify-between px-4 pointer-events-none">
            {/* Current Area & Gold */}
            <div className="dq-window px-4 py-1.5 pointer-events-auto flex items-center gap-3">
              <span className="text-amber-400 font-bold text-sm">
                📍 {MAPS[currentMapId]?.name || '未知の地'}
              </span>
              <span className="text-xs text-white/70">
                {gold} G
              </span>
              <span className="text-xs text-amber-300 font-mono">
                仲: {party.length}人
              </span>
            </div>

            {/* Quick Actions (3D Toggle, Sound, Menu) */}
            <div className="flex items-center gap-2 pointer-events-auto">
              <button
                onClick={() => setViewMode3D(prev => !prev)}
                className="dq-window px-3 py-1.5 text-xs font-bold text-cyan-300 hover:text-white"
                title="3D視点と2D視点の切り替え"
              >
                {viewMode3D ? '🎮 3D表示中' : '🗺️ 2D表示中'}
              </button>
              <button
                onClick={() => dqAudio.toggleMute()}
                className="dq-window px-3 py-1.5 text-xs font-bold text-white hover:text-amber-300"
                title="BGM/効果音切替"
              >
                🔊 音声
              </button>
              <button
                onClick={() => {
                  dqAudio.playConfirm();
                  setIsMenuOpen(true);
                }}
                className="dq-window px-4 py-1.5 text-xs font-bold text-amber-300 hover:text-white flex items-center gap-1 shadow-lg"
              >
                <span>📜 メニュー</span>
                <span className="text-white/60">(X)</span>
              </button>
            </div>
          </div>

          {/* Viewport: 3D View with Symbol Encounters vs 2D Fallback */}
          <div className="flex-1 w-full h-full">
            {viewMode3D ? (
              <Map3DView
                currentMap={MAPS[currentMapId]}
                playerPos={playerPos}
                party={party}
                openedChests={openedChestIds}
                solvedFlags={flags}
                onMove={setPlayerPos}
                onInteract={handleInteract}
                onWarp={handleWarp}
                onSymbolEncounter={handleSymbolEncounter}
              />
            ) : (
              <MapCanvas
                currentMap={MAPS[currentMapId]}
                playerPos={playerPos}
                party={party}
                openedChests={openedChestIds}
                solvedFlags={flags}
                onMove={setPlayerPos}
                onInteract={handleInteract}
                onWarp={handleWarp}
                onEncounter={triggerRandomEncounter}
              />
            )}
          </div>

          {/* Game Menu Modal */}
          {isMenuOpen && (
            <GameMenuModal
              party={party}
              inventory={inventory}
              gold={gold}
              tablets={tablets}
              onClose={() => setIsMenuOpen(false)}
              onUseItem={handleUseItem}
              onUseSpell={handleUseSpell}
              onSaveGame={saveGame}
            />
          )}

          {/* Patty's Pub / Luida's Tavern Modal */}
          {isTavernOpen && (
            <TavernModal
              party={party}
              tavernRoster={tavernRoster}
              onUpdateParty={(newParty, newRoster) => {
                setParty(newParty);
                setTavernRoster(newRoster);
              }}
              onClose={() => setIsTavernOpen(false)}
            />
          )}
        </div>
      )}

      {/* 3. Battle Screen */}
      {gameState === 'BATTLE' && battleParams && (
        <BattleScreen
          party={party}
          monsters={battleParams.monsters}
          isBoss={battleParams.isBoss}
          isLastBoss={battleParams.isLastBoss}
          backgroundTheme={battleParams.backgroundTheme}
          onBattleEnd={handleBattleEnd}
          onEscapeSuccess={() => setGameState('EXPLORING')}
        />
      )}

      {/* 4. Ending Screen */}
      {gameState === 'ENDING' && (
        <EndingScreen
          heroName={heroName}
          onRestart={() => setGameState('TITLE')}
        />
      )}

      {/* Dialogue Box (Top-Level Overlay across all game states) */}
      {activeDialogue && (
        <DialogueBox
          speakerName={activeDialogue.speaker}
          messages={activeDialogue.messages}
          options={activeDialogue.options}
          onFinish={activeDialogue.onFinish}
          onSelectOption={activeDialogue.onSelectOption}
        />
      )}

      {/* Retro Scanline Overlay */}
      <div className="scanlines absolute inset-0 z-50 pointer-events-none" />
    </div>
  );
}
