import React, { useState } from 'react';
import { Character } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { CharMakeModal } from './CharMakeModal';

interface TavernModalProps {
  party: Character[];
  tavernRoster: Character[];
  onUpdateParty: (newParty: Character[], newRoster: Character[]) => void;
  onClose: () => void;
}

export const TavernModal: React.FC<TavernModalProps> = ({
  party,
  tavernRoster,
  onUpdateParty,
  onClose,
}) => {
  const [tab, setTab] = useState<'recruit' | 'leave' | 'register'>('recruit');
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [msg, setMsg] = useState<string>('「ここは ルイーダの酒場。仲間と出会い、別れる場所よ。」');

  // Add companion to party
  const handleRecruit = (char: Character) => {
    if (party.length >= 4) {
      setMsg('「パーティは最大4人までよ！ 誰かをあずけてから来てね。」');
      dqAudio.playCancel();
      return;
    }

    dqAudio.playLevelUp();
    const newParty = [...party, char];
    const newRoster = tavernRoster.filter(c => c.id !== char.id);
    onUpdateParty(newParty, newRoster);
    setMsg(`「${char.name}が パーティに加わったわ！ 頼もしい仲間ね。」`);
  };

  // Leave companion in tavern
  const handleLeave = (char: Character) => {
    if (char.id === 'hero') {
      setMsg('「旅のリーダーである主人公をあずけることはできないわ！」');
      dqAudio.playCancel();
      return;
    }

    dqAudio.playConfirm();
    const newParty = party.filter(c => c.id !== char.id);
    const newRoster = [...tavernRoster, char];
    onUpdateParty(newParty, newRoster);
    setMsg(`「${char.name}を 酒場であずかったわ。いつでも呼び出してね。」`);
  };

  // Register new companion
  const handleConfirmRegister = (newChar: Character) => {
    dqAudio.playLevelUp();
    setIsRegistering(false);
    onUpdateParty(party, [...tavernRoster, newChar]);
    setMsg(`「新しい冒険者【${newChar.name}】が 酒場の名簿に登録されたわ！」`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 select-none">
      <div className="dq-window max-w-4xl w-full p-6 flex flex-col gap-4 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/20 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🍷</span>
            <span className="text-xl font-bold text-amber-300">ルイーダの酒場</span>
          </div>
          <span className="text-xs text-white/70">パーティ人数: {party.length} / 4人</span>
        </div>

        {/* Luida's dialogue message */}
        <div className="p-3 bg-black/60 border border-white/20 rounded text-sm text-amber-200">
          {msg}
        </div>

        {/* Tab Buttons */}
        <div className="flex gap-2 border-b border-white/20 pb-2">
          {[
            { id: 'recruit', label: 'なかまを よぶ' },
            { id: 'leave', label: 'なかまを あずける' },
            { id: 'register', label: 'ぼうけんしゃの とうろく' },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => {
                dqAudio.playCursor();
                if (t.id === 'register') {
                  setIsRegistering(true);
                } else {
                  setTab(t.id as any);
                }
              }}
              className={`px-4 py-2 text-sm rounded font-bold transition-colors ${
                tab === t.id && !isRegistering
                  ? 'bg-amber-500 text-black shadow'
                  : 'border border-white/30 text-white hover:bg-white/10'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 min-h-[220px]">
          {/* Active Party Members */}
          <div className="bg-black/50 border border-white/20 p-3 rounded-lg flex flex-col gap-2">
            <div className="text-xs font-bold text-amber-300 border-b border-white/20 pb-1 flex justify-between">
              <span>【現在のパーティ ({party.length}/4)】</span>
              <span className="text-white/60">戦闘参加メンバー</span>
            </div>

            <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
              {party.map(char => (
                <div
                  key={char.id}
                  className="p-2 border border-white/20 rounded flex items-center justify-between bg-white/5"
                >
                  <div className="flex flex-col">
                    <span className="font-bold text-sm text-white flex items-center gap-1">
                      <span>{char.name}</span>
                      <span className="text-xs text-amber-300">Lv.{char.level}</span>
                      <span className="text-xs text-white/60">({char.role})</span>
                    </span>
                    <span className="text-[11px] text-white/70">
                      HP: {char.hp}/{char.maxHp} · MP: {char.mp}/{char.maxMp} · 攻:{char.attack}
                    </span>
                  </div>

                  {tab === 'leave' && char.id !== 'hero' && (
                    <button
                      onClick={() => handleLeave(char)}
                      className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded shadow"
                    >
                      あずける
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Tavern Roster */}
          <div className="bg-black/50 border border-white/20 p-3 rounded-lg flex flex-col gap-2">
            <div className="text-xs font-bold text-amber-300 border-b border-white/20 pb-1 flex justify-between">
              <span>【酒場の待機メンバー ({tavernRoster.length}人)】</span>
              <span className="text-white/60">登録済みの冒険者</span>
            </div>

            <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
              {tavernRoster.length === 0 ? (
                <div className="text-xs text-white/60 p-4 text-center">
                  待機している仲間はいません。「ぼうけんしゃの とうろく」から新しい仲間を酒場に迎えることができます。
                </div>
              ) : (
                tavernRoster.map(char => (
                  <div
                    key={char.id}
                    className="p-2 border border-white/20 rounded flex items-center justify-between hover:bg-white/5"
                  >
                    <div className="flex flex-col">
                      <span className="font-bold text-sm text-white flex items-center gap-1">
                        <span>{char.name}</span>
                        <span className="text-xs text-amber-300">Lv.{char.level}</span>
                        <span className="text-xs text-white/60">({char.role})</span>
                      </span>
                      <span className="text-[11px] text-white/70">
                        HP: {char.hp}/{char.maxHp} · MP: {char.mp}/{char.maxMp} · 攻:{char.attack}
                      </span>
                    </div>

                    {tab === 'recruit' && (
                      <button
                        onClick={() => handleRecruit(char)}
                        disabled={party.length >= 4}
                        className={`px-3 py-1 text-xs font-bold rounded shadow ${
                          party.length >= 4
                            ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                            : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        }`}
                      >
                        くわえる
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-white/20 pt-3 flex justify-between items-center">
          <button
            onClick={() => setIsRegistering(true)}
            className="px-4 py-2 border border-amber-400 text-amber-300 hover:bg-amber-400/10 font-bold text-xs rounded"
          >
            ＋ 新しい冒険者を登録
          </button>
          <button
            onClick={() => {
              dqAudio.playCancel();
              onClose();
            }}
            className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm rounded shadow active:scale-95"
          >
            酒場をでる
          </button>
        </div>
      </div>

      {/* Register Modal Overlay */}
      {isRegistering && (
        <CharMakeModal
          isRecruiting={true}
          initialName=""
          onConfirm={handleConfirmRegister}
          onCancel={() => setIsRegistering(false)}
        />
      )}
    </div>
  );
};
