import React, { useState, useEffect } from 'react';
import { Character, CharacterAppearance } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { CharMakeModal } from './CharMakeModal';

interface TitleScreenProps {
  hasSaveData: boolean;
  onStartNewGame: (createdHero: Character) => void;
  onLoadGame: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  hasSaveData,
  onStartNewGame,
  onLoadGame,
}) => {
  const [step, setStep] = useState<'title' | 'menu' | 'charmake' | 'intro_prologue'>('title');
  const [menuCursor, setMenuCursor] = useState<number>(0);
  const [heroCharacter, setHeroCharacter] = useState<Character | null>(null);
  const [prologueIdx, setPrologueIdx] = useState<number>(0);

  const heroName = heroCharacter?.name || 'アレク';

  // Play Overture on Title Screen mount
  useEffect(() => {
    dqAudio.playBgm('overture');
  }, []);

  const prologueTexts = [
    `「……${heroName}よ。
お前が　その胸に抱く　小さな違和感こそが
この世界を　偽りの平和から　救う光となるであろう……」`,
    `かつて世界を滅ぼそうとした大魔王を倒し
平和をもたらしたとされる「導かれし12人の聖職者」。
すべての街に教会が立ち並び、人々は平穏に暮らしていた。`,
    `しかし、悲しいことや辛いことがあると、
人々は教会の「神の奇跡」によってその記憶を消し去る。
記憶を消された者は、やがて生気を失い
謎の「黒い影」となって消えていく……`,
    `辺境の「ココヤしの村」で暮らす若者${heroName}。
ある日、幼馴染のエリーナが黒い影となって消滅した。
だが……なぜか${heroName}だけが彼女を覚えていた。`,
    `自らの血に眠る「13番目の真実」を求め、
失われた記憶を取り戻す壮大なる旅が、今始まる――！`,
  ];

  const handleStartTitle = () => {
    dqAudio.playConfirm();
    // Switch to Intermezzo (冒険の書 BGM) when entering file select / adventure log
    dqAudio.playBgm('intermezzo');
    setStep('menu');
  };

  const handleMenuSelect = (idx: number) => {
    dqAudio.playConfirm();
    if (idx === 0) {
      setStep('charmake');
    } else if (idx === 1 && hasSaveData) {
      onLoadGame();
    }
  };

  const handleCharMakeConfirm = (char: Character) => {
    setHeroCharacter(char);
    setStep('intro_prologue');
    setPrologueIdx(0);
  };

  const handleAdvancePrologue = () => {
    if (prologueIdx < prologueTexts.length - 1) {
      dqAudio.playConfirm();
      setPrologueIdx(prev => prev + 1);
    } else {
      dqAudio.playConfirm();
      if (heroCharacter) {
        onStartNewGame(heroCharacter);
      }
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-black text-white select-none overflow-hidden">
      {/* Background Graphic */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-45"
        style={{ backgroundImage: `url('/src/assets/images/dq13_title_art_1790826606946.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/80" />

      {/* Title Step */}
      {step === 'title' && (
        <div
          onClick={handleStartTitle}
          className="relative z-10 flex flex-col items-center justify-center p-6 text-center cursor-pointer animate-fade-in"
        >
          <div className="text-xs tracking-widest text-amber-300 font-bold mb-2">
            DRAGON QUEST XIII
          </div>
          <h1 className="text-3xl md:text-5xl font-black tracking-wider text-white filter drop-shadow-[0_4px_12px_rgba(245,158,11,0.6)] mb-2">
            ドラゴンクエストⅩⅢ
          </h1>
          <h2 className="text-xl md:text-2xl font-bold tracking-widest text-amber-400 mb-8">
            失われた記憶の系譜
          </h2>

          <div className="dq-window px-8 py-4 animate-bounce">
            <span className="text-base md:text-lg font-bold text-white tracking-widest">
              ▶ 画面をクリックして スタート ◀
            </span>
          </div>

          <div className="text-xs text-white/60 mt-8">
            ※クリックでインテルメッツォ（冒険の書）へ進みます
          </div>
        </div>
      )}

      {/* Menu Step: Adventure Log */}
      {step === 'menu' && (
        <div className="relative z-10 flex flex-col items-center gap-6 max-w-md w-full px-4">
          <div className="text-xl font-bold text-amber-300 mb-2">
            ドラゴンクエストⅩⅢ
          </div>

          <div className="dq-window w-full p-6 flex flex-col gap-4">
            <div className="text-sm font-bold border-b border-white/20 pb-2 text-amber-300 flex justify-between items-center">
              <span>【ぼうけんのしょを えらんでください】</span>
              <span className="text-xs text-amber-200">♪ インテルメッツォ</span>
            </div>

            <button
              onClick={() => handleMenuSelect(0)}
              className="text-left py-2 px-3 flex items-center hover:bg-white/10 rounded transition-colors"
            >
              <span className="w-5 text-amber-400 font-bold">
                {menuCursor === 0 ? '▶' : ' '}
              </span>
              <span className="text-base font-bold">ぼうけんのしょを つくる (キャラメイク)</span>
            </button>

            <button
              onClick={() => handleMenuSelect(1)}
              disabled={!hasSaveData}
              className={`text-left py-2 px-3 flex items-center rounded transition-colors ${
                hasSaveData ? 'hover:bg-white/10 text-white' : 'opacity-40 text-gray-500 cursor-not-allowed'
              }`}
            >
              <span className="w-5 text-amber-400 font-bold">
                {menuCursor === 1 ? '▶' : ' '}
              </span>
              <span className="text-base font-bold">
                ぼうけんのしょ 1 (つづきから) {!hasSaveData && '【記録なし】'}
              </span>
            </button>

            <button
              onClick={() => {
                dqAudio.playCancel();
                dqAudio.playBgm('overture');
                setStep('title');
              }}
              className="text-left py-2 px-3 flex items-center hover:bg-white/10 rounded transition-colors border-t border-white/10 text-gray-400 hover:text-white"
            >
              <span className="w-5"></span>
              <span className="text-sm font-bold">◀ タイトルがめんへ もどる (序曲)</span>
            </button>
          </div>
        </div>
      )}

      {/* Character Creation Modal */}
      {step === 'charmake' && (
        <CharMakeModal
          initialName="アレク"
          isRecruiting={false}
          onConfirm={handleCharMakeConfirm}
          onCancel={() => setStep('menu')}
        />
      )}

      {/* Intro Prologue Step */}
      {step === 'intro_prologue' && (
        <div
          onClick={handleAdvancePrologue}
          className="relative z-10 max-w-2xl w-[92%] p-6 cursor-pointer"
        >
          <div className="dq-window p-8 min-h-[220px] flex flex-col justify-between shadow-2xl">
            <div className="text-lg md:text-xl leading-relaxed tracking-widest whitespace-pre-line text-white/95">
              {prologueTexts[prologueIdx]}
            </div>

            <div className="self-end text-amber-400 text-sm font-bold dq-cursor mt-6">
              ▼ 次へ (画面クリック / Enter)
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
