import React, { useState, useEffect } from 'react';
import { dqAudio } from '../audio/dqAudio';

interface DialogueBoxProps {
  speakerName?: string;
  messages: string[];
  options?: { label: string; value: string }[];
  onFinish: () => void;
  onSelectOption?: (optionValue: string) => void;
}

export const DialogueBox: React.FC<DialogueBoxProps> = ({
  speakerName,
  messages,
  options,
  onFinish,
  onSelectOption,
}) => {
  const [currentMsgIdx, setCurrentMsgIdx] = useState<number>(0);
  const [displayedText, setDisplayedText] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(true);
  const [selectedOptionIdx, setSelectedOptionIdx] = useState<number>(0);

  const fullText = messages[currentMsgIdx] || '';

  // Typewriter effect with typewriter blip audio
  useEffect(() => {
    let charIdx = 0;
    setDisplayedText('');
    setIsTyping(true);

    const timer = setInterval(() => {
      if (charIdx < fullText.length) {
        setDisplayedText(fullText.slice(0, charIdx + 1));
        if (charIdx % 2 === 0) {
          dqAudio.playTextBlip();
        }
        charIdx++;
      } else {
        setIsTyping(false);
        clearInterval(timer);
      }
    }, 28);

    return () => clearInterval(timer);
  }, [currentMsgIdx, fullText]);

  // Handle Advance
  const handleAdvance = () => {
    if (isTyping) {
      // Instant reveal
      setDisplayedText(fullText);
      setIsTyping(false);
      return;
    }

    // If options are showing on the last message
    if (currentMsgIdx >= messages.length - 1 && options && options.length > 0) {
      if (onSelectOption) {
        dqAudio.playConfirm();
        onSelectOption(options[selectedOptionIdx].value);
      }
      return;
    }

    if (currentMsgIdx < messages.length - 1) {
      dqAudio.playConfirm();
      setCurrentMsgIdx(prev => prev + 1);
    } else {
      dqAudio.playConfirm();
      onFinish();
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        handleAdvance();
      } else if (options && !isTyping) {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
          dqAudio.playCursor();
          setSelectedOptionIdx(prev => (prev > 0 ? prev - 1 : options.length - 1));
        } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
          dqAudio.playCursor();
          setSelectedOptionIdx(prev => (prev < options.length - 1 ? prev + 1 : 0));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isTyping, currentMsgIdx, messages, selectedOptionIdx, options]);

  return (
    <div
      onClick={handleAdvance}
      className="absolute bottom-6 left-1/2 -translate-x-1/2 w-[92%] max-w-3xl z-40 cursor-pointer select-none"
    >
      <div className="dq-window p-5 min-h-[140px] flex flex-col justify-between shadow-2xl">
        {speakerName && (
          <div className="absolute -top-4 left-6 bg-black border-2 border-white px-3 py-0.5 text-xs text-amber-300 font-bold rounded">
            {speakerName}
          </div>
        )}

        <div className="text-base md:text-lg leading-relaxed tracking-wider whitespace-pre-line text-white">
          {displayedText}
        </div>

        {/* Options Prompt (e.g. はい / いいえ) */}
        {!isTyping && currentMsgIdx >= messages.length - 1 && options && options.length > 0 && (
          <div className="mt-3 flex gap-4 justify-end border-t border-white/20 pt-2">
            {options.map((opt, idx) => (
              <button
                key={opt.value}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedOptionIdx(idx);
                  if (onSelectOption) onSelectOption(opt.value);
                }}
                className={`px-4 py-1 flex items-center border border-white/40 rounded hover:border-amber-400 ${
                  selectedOptionIdx === idx ? 'bg-white/10 text-amber-300 border-amber-400' : 'text-white'
                }`}
              >
                <span className="w-4 font-bold text-amber-400">
                  {selectedOptionIdx === idx ? '▶' : ' '}
                </span>
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        )}

        {/* Blinking Cursor Indicator */}
        {!isTyping && (!options || currentMsgIdx < messages.length - 1) && (
          <div className="self-end text-amber-400 text-sm font-bold dq-cursor mt-2">
            ▼
          </div>
        )}
      </div>
    </div>
  );
};
