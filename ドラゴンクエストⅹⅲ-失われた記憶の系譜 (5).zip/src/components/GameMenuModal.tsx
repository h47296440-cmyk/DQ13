import React, { useState } from 'react';
import { Character, TabletPiece, Item } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { ITEMS } from '../data/gameData';

interface GameMenuModalProps {
  party: Character[];
  inventory: { itemId: string; count: number }[];
  gold: number;
  tablets: TabletPiece[];
  onClose: () => void;
  onUseItem: (itemId: string, targetCharIdx: number) => void;
  onUseSpell: (spellId: string, casterIdx: number, targetCharIdx: number) => void;
  onSaveGame: () => void;
}

export const GameMenuModal: React.FC<GameMenuModalProps> = ({
  party,
  inventory,
  gold,
  tablets,
  onClose,
  onUseItem,
  onUseSpell,
  onSaveGame,
}) => {
  const [activeTab, setActiveTab] = useState<'main' | 'spell' | 'status' | 'item' | 'tablet' | 'tactics'>('main');
  const [selectedCharIdx, setSelectedCharIdx] = useState<number>(0);
  const [selectedItemIdx, setSelectedItemIdx] = useState<number>(0);
  const [selectedSpellIdx, setSelectedSpellIdx] = useState<number>(0);
  const [targetCharIdx, setTargetCharIdx] = useState<number>(0);
  const [selectingTargetFor, setSelectingTargetFor] = useState<'item' | 'spell' | null>(null);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  const isMuted = dqAudio.getMuted();

  const handleSelectTab = (tab: typeof activeTab) => {
    dqAudio.playCursor();
    setActiveTab(tab);
    setSelectingTargetFor(null);
  };

  const currentChar = party[selectedCharIdx];

  const handleExecuteTarget = () => {
    if (selectingTargetFor === 'item') {
      const itemEntry = inventory[selectedItemIdx];
      if (itemEntry) {
        onUseItem(itemEntry.itemId, targetCharIdx);
        setSelectingTargetFor(null);
      }
    } else if (selectingTargetFor === 'spell') {
      const spell = currentChar?.spells?.[selectedSpellIdx];
      if (spell) {
        onUseSpell(spell.id, selectedCharIdx, targetCharIdx);
        setSelectingTargetFor(null);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 select-none">
      <div className="relative w-full max-w-4xl dq-window p-6 flex flex-col md:flex-row gap-6 max-h-[90vh] overflow-y-auto">
        {/* Left Side: Command List */}
        <div className="flex flex-col gap-2 min-w-[200px] border-b md:border-b-0 md:border-r border-white/20 pb-4 md:pb-0 md:pr-4">
          <div className="text-amber-400 font-bold text-base pb-2 border-b border-white/20 flex items-center justify-between">
            <span>【コマンド】</span>
            <span className="text-xs text-white/70">{gold} G</span>
          </div>

          {[
            { id: 'main', label: 'もどる' },
            { id: 'spell', label: 'じゅもん' },
            { id: 'status', label: 'つよさ' },
            { id: 'item', label: 'どうぐ' },
            { id: 'tablet', label: 'せきばん' },
            { id: 'tactics', label: 'さくせん/BGM' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => {
                if (item.id === 'main') {
                  dqAudio.playCancel();
                  onClose();
                } else {
                  handleSelectTab(item.id as typeof activeTab);
                }
              }}
              className={`text-left px-3 py-2 flex items-center rounded transition-colors ${
                activeTab === item.id ? 'bg-white/20 text-amber-300 font-bold' : 'hover:bg-white/10 text-white'
              }`}
            >
              <span className="w-5 text-amber-400 font-bold">
                {activeTab === item.id ? '▶' : ' '}
              </span>
              <span>{item.label}</span>
            </button>
          ))}

          <button
            onClick={() => {
              dqAudio.playCancel();
              onClose();
            }}
            className="mt-4 px-3 py-1.5 border border-white/40 rounded text-xs text-white/70 hover:text-white hover:border-white text-center"
          >
            とじる (Esc)
          </button>
        </div>

        {/* Right Side: Tab Contents */}
        <div className="flex-1 min-h-[360px] flex flex-col justify-between">
          {/* 1. Status View (つよさ) */}
          {activeTab === 'status' && (
            <div className="flex flex-col gap-4">
              {/* Character Selector */}
              <div className="flex gap-2 border-b border-white/20 pb-3">
                {party.map((char, idx) => (
                  <button
                    key={char.id}
                    onClick={() => {
                      dqAudio.playCursor();
                      setSelectedCharIdx(idx);
                    }}
                    className={`px-3 py-1.5 rounded text-sm flex items-center gap-1 ${
                      selectedCharIdx === idx ? 'bg-amber-500 text-black font-bold' : 'border border-white/40 text-white'
                    }`}
                  >
                    <span>{char.name}</span>
                    <span className="text-xs">Lv.{char.level}</span>
                  </button>
                ))}
              </div>

              {currentChar && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="bg-black/40 border border-white/20 p-3 rounded flex flex-col gap-1.5">
                    <div className="text-amber-300 font-bold text-base">{currentChar.name} ({currentChar.role})</div>
                    <div className="text-xs text-white/70">{currentChar.title}</div>
                    <div className="border-t border-white/20 my-1" />
                    <div className="flex justify-between"><span>最大HP:</span><span className="font-mono text-emerald-400">{currentChar.hp}/{currentChar.maxHp}</span></div>
                    <div className="flex justify-between"><span>最大MP:</span><span className="font-mono text-cyan-400">{currentChar.mp}/{currentChar.maxMp}</span></div>
                    <div className="flex justify-between"><span>こうげき力:</span><span className="font-mono text-red-400">{currentChar.attack}</span></div>
                    <div className="flex justify-between"><span>しゅび力:</span><span className="font-mono text-blue-400">{currentChar.defense}</span></div>
                    <div className="flex justify-between"><span>すばやさ:</span><span className="font-mono text-amber-400">{currentChar.agility}</span></div>
                    <div className="flex justify-between"><span>現在EXP:</span><span className="font-mono">{currentChar.exp}</span></div>
                    <div className="flex justify-between"><span>次のレベルまで:</span><span className="font-mono text-amber-300">{currentChar.nextExp - currentChar.exp}</span></div>
                  </div>

                  <div className="bg-black/40 border border-white/20 p-3 rounded flex flex-col gap-1.5">
                    <div className="text-amber-300 font-bold">【そうびひん】</div>
                    <div className="text-xs flex justify-between"><span>ぶき:</span><span className="text-amber-200">{currentChar.equipment.weapon}</span></div>
                    <div className="text-xs flex justify-between"><span>よろい:</span><span className="text-amber-200">{currentChar.equipment.armor}</span></div>
                    <div className="text-xs flex justify-between"><span>たて:</span><span className="text-amber-200">{currentChar.equipment.shield}</span></div>
                    <div className="text-xs flex justify-between"><span>そうしょく:</span><span className="text-amber-200">{currentChar.equipment.accessory}</span></div>

                    <div className="border-t border-white/20 my-1" />
                    <div className="text-amber-300 font-bold">【とくぎ・じゅもん】</div>
                    <div className="flex flex-wrap gap-1 text-xs text-white/80">
                      {currentChar.spells.map(s => s.name).concat(currentChar.skills.map(sk => sk.name)).join('、 ')}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 2. Spells View (じゅもん) */}
          {activeTab === 'spell' && (
            <div className="flex flex-col gap-4">
              <div className="flex gap-2 border-b border-white/20 pb-3">
                {party.map((char, idx) => (
                  <button
                    key={char.id}
                    onClick={() => {
                      dqAudio.playCursor();
                      setSelectedCharIdx(idx);
                      setSelectedSpellIdx(0);
                    }}
                    className={`px-3 py-1.5 rounded text-sm ${
                      selectedCharIdx === idx ? 'bg-amber-500 text-black font-bold' : 'border border-white/40 text-white'
                    }`}
                  >
                    {char.name}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                {currentChar?.spells?.length === 0 ? (
                  <div className="text-sm text-white/60 p-4">唱えられる呪文がありません。</div>
                ) : (
                  currentChar?.spells?.map((spell, idx) => (
                    <button
                      key={spell.id}
                      onClick={() => {
                        dqAudio.playCursor();
                        setSelectedSpellIdx(idx);
                        if (spell.type === 'heal') {
                          setSelectingTargetFor('spell');
                        }
                      }}
                      className={`p-2.5 text-left border rounded flex flex-col justify-between ${
                        selectedSpellIdx === idx ? 'border-amber-400 bg-white/10' : 'border-white/20 hover:border-white/50'
                      }`}
                    >
                      <div className="flex justify-between items-center text-sm font-bold">
                        <span className="text-amber-300">{spell.name}</span>
                        <span className="text-xs text-cyan-300 font-mono">消費MP {spell.mpCost}</span>
                      </div>
                      <div className="text-xs text-white/70 mt-1">{spell.description}</div>
                    </button>
                  ))
                )}
              </div>

              {/* Target Character Prompt */}
              {selectingTargetFor === 'spell' && (
                <div className="p-3 bg-black/60 border border-amber-400 rounded flex items-center justify-between">
                  <span className="text-sm text-amber-300">だれに つかいますか？</span>
                  <div className="flex gap-2">
                    {party.map((p, idx) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          setTargetCharIdx(idx);
                          handleExecuteTarget();
                        }}
                        className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs rounded"
                      >
                        {p.name} (HP:{p.hp}/{p.maxHp})
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 3. Items View (どうぐ) */}
          {activeTab === 'item' && (
            <div className="flex flex-col gap-4">
              <div className="text-sm text-amber-300 font-bold border-b border-white/20 pb-2">
                所持品リスト
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                {inventory.length === 0 ? (
                  <div className="text-sm text-white/60 p-4">道具を何も持っていません。</div>
                ) : (
                  inventory.map((inv, idx) => {
                    const it = ITEMS[inv.itemId];
                    if (!it) return null;
                    return (
                      <button
                        key={inv.itemId}
                        onClick={() => {
                          dqAudio.playCursor();
                          setSelectedItemIdx(idx);
                          if (it.usableInField) {
                            setSelectingTargetFor('item');
                          }
                        }}
                        className={`p-2.5 text-left border rounded flex flex-col justify-between ${
                          selectedItemIdx === idx ? 'border-amber-400 bg-white/10' : 'border-white/20 hover:border-white/50'
                        }`}
                      >
                        <div className="flex justify-between items-center text-sm font-bold">
                          <span className="text-amber-300">{it.name}</span>
                          <span className="text-xs text-white/80 font-mono">x{inv.count}</span>
                        </div>
                        <div className="text-xs text-white/70 mt-1">{it.description}</div>
                      </button>
                    );
                  })
                )}
              </div>

              {/* Target Character Prompt */}
              {selectingTargetFor === 'item' && (
                <div className="p-3 bg-black/60 border border-amber-400 rounded flex items-center justify-between">
                  <span className="text-sm text-amber-300">だれに つかいますか？</span>
                  <div className="flex gap-2">
                    {party.map((p, idx) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          setTargetCharIdx(idx);
                          handleExecuteTarget();
                        }}
                        className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs rounded"
                      >
                        {p.name} (HP:{p.hp}/{p.maxHp})
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 4. Memory Tablets View (記憶の石版) */}
          {activeTab === 'tablet' && (
            <div className="flex flex-col gap-4">
              <div className="text-sm text-amber-300 font-bold border-b border-white/20 pb-2 flex justify-between">
                <span>記憶の石版・古代の台座</span>
                <span className="text-xs text-white/70">
                  発見: {tablets.filter(t => t.found).length} / 4
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {tablets.map((tab) => {
                  const colorBorder = tab.color === 'blue'
                    ? 'border-blue-500'
                    : tab.color === 'red'
                    ? 'border-red-500'
                    : tab.color === 'yellow'
                    ? 'border-amber-400'
                    : 'border-purple-600';

                  return (
                    <div
                      key={tab.id}
                      className={`p-3 border-2 rounded ${colorBorder} ${
                        tab.found ? 'bg-black/60' : 'opacity-40 bg-black/30'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-white">{tab.name}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-white/10">
                          {tab.found ? 'はめ込み済み' : '未発見'}
                        </span>
                      </div>
                      <div className="text-xs text-amber-200 mt-1">発見場所: {tab.areaName}</div>
                      <div className="text-xs text-white/80 mt-2 italic leading-relaxed">
                        {tab.found ? tab.memoryStory : '（まだ石版の破片は見つかっていない……）'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 5. Tactics & Jukebox View (さくせん / BGM) */}
          {activeTab === 'tactics' && (
            <div className="flex flex-col gap-4 text-sm">
              <div className="text-amber-300 font-bold border-b border-white/20 pb-2">
                さくせん・BGMジュークボックス
              </div>

              <div className="flex items-center justify-between bg-black/40 p-3 rounded border border-white/20">
                <span>サウンド再生 (BGM/効果音)</span>
                <button
                  onClick={() => {
                    dqAudio.toggleMute();
                    // trigger rerender
                    setActiveTab('tactics');
                  }}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs rounded"
                >
                  {isMuted ? 'ミュート中 (ONにする)' : '再生中 (消音にする)'}
                </button>
              </div>

              {/* Jukebox BGM Selector */}
              <div className="bg-black/40 p-3 rounded border border-white/20 flex flex-col gap-2">
                <div className="text-xs text-amber-300 font-bold">ドラクエ風オリジナルBGM試聴</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {[
                    { id: 'overture', label: '序曲 (王都行進)' },
                    { id: 'village', label: '街・村のワルツ' },
                    { id: 'field', label: '広大なフィールド' },
                    { id: 'dungeon', label: '失われた神殿' },
                    { id: 'battle', label: '通常戦闘BGM' },
                    { id: 'boss', label: '心の魔物(中ボス)' },
                    { id: 'lastboss', label: '大魔王ネビュロス' },
                    { id: 'ending', label: 'エンディング' },
                  ].map(track => (
                    <button
                      key={track.id}
                      onClick={() => {
                        dqAudio.playBgm(track.id as any);
                      }}
                      className="px-2 py-1.5 bg-slate-900 border border-white/40 hover:border-amber-400 text-xs rounded text-white"
                    >
                      ♪ {track.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Adventure Log Save */}
              <div className="bg-black/40 p-3 rounded border border-white/20 flex items-center justify-between">
                <div>
                  <div className="font-bold text-amber-300">冒険の書に記録する</div>
                  <div className="text-xs text-white/70">ブラウザに現在の進行状況をセーブします</div>
                </div>
                <button
                  onClick={() => {
                    onSaveGame();
                    dqAudio.playChurchJingle();
                    setSaveSuccessMsg('冒険の書に記録しました！');
                    setTimeout(() => setSaveSuccessMsg(null), 2500);
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded shadow"
                >
                  お祈りしてセーブ
                </button>
              </div>

              {saveSuccessMsg && (
                <div className="p-2 bg-emerald-950 border border-emerald-400 text-emerald-200 text-center text-xs rounded font-bold">
                  {saveSuccessMsg}
                </div>
              )}
            </div>
          )}

          {/* Footer Close Button */}
          <div className="mt-4 pt-3 border-t border-white/20 flex justify-end">
            <button
              onClick={() => {
                dqAudio.playCancel();
                onClose();
              }}
              className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm rounded shadow active:scale-95"
            >
              もどる
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
