import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { MapData, Character, NPC, Chest, SymbolMonster, Monster } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { MONSTERS_POOL } from '../data/gameData';
import { createOptimizedRenderer } from '../utils/rendererHelper';
import { createMonsterModel, MonsterMeshResult } from '../utils/monsterModels';
import { createCoffinGroup, getConnectedWarpZone } from '../utils/coffinModel';

interface Map3DViewProps {
  currentMap: MapData;
  playerPos: { x: number; y: number; dir: 'up' | 'down' | 'left' | 'right' };
  party: Character[];
  openedChests: string[];
  solvedFlags: Record<string, boolean>;
  onMove: (newPos: { x: number; y: number; dir: 'up' | 'down' | 'left' | 'right' }) => void;
  onInteract: (target: { type: 'npc' | 'chest' | 'altar' | 'pedestal' | 'bed' | 'tavern'; data: any }) => void;
  onWarp: (warp: { targetMap: string; targetX: number; targetY: number }) => void;
  onSymbolEncounter: (monsters: Monster[], symbolId: string) => void;
}

const TILE_SCALE = 3.0; // 3D units per grid cell

export const Map3DView: React.FC<Map3DViewProps> = ({
  currentMap,
  playerPos,
  party,
  openedChests,
  solvedFlags,
  onMove,
  onInteract,
  onWarp,
  onSymbolEncounter,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // Symbol Monsters runtime state
  const [symbolMonsters, setSymbolMonsters] = useState<SymbolMonster[]>([]);
  const defeatedSymbolsRef = useRef<Set<string>>(new Set());

  // Player position in 3D smooth coordinate
  const player3DPos = useRef<{ x: number; z: number; targetX: number; targetZ: number; angle: number }>({
    x: playerPos.x * TILE_SCALE,
    z: playerPos.y * TILE_SCALE,
    targetX: playerPos.x * TILE_SCALE,
    targetZ: playerPos.y * TILE_SCALE,
    angle: 0,
  });

  // History path for party follow train
  const pathHistory = useRef<Array<{ x: number; z: number; angle: number }>>([]);

  // Initialize symbol monsters when entering map
  useEffect(() => {
    if (!currentMap.symbolMonsters) {
      setSymbolMonsters([]);
      return;
    }

    const initialSymbols: SymbolMonster[] = [];
    currentMap.symbolMonsters.forEach((sm, idx) => {
      const id = `${currentMap.id}_sm_${idx}`;
      if (defeatedSymbolsRef.current.has(id)) return;

      const monsterTemplate = MONSTERS_POOL[sm.type] || MONSTERS_POOL.slime;
      initialSymbols.push({
        id,
        monsterType: sm.type,
        name: monsterTemplate.name,
        x: sm.x * TILE_SCALE,
        y: sm.y * TILE_SCALE,
        dir: Math.random() * Math.PI * 2,
        state: 'wandering',
        chaseTimer: 0,
        alertTimer: 0,
        cooldownTimer: 0,
        targetX: sm.x * TILE_SCALE,
        targetY: sm.y * TILE_SCALE,
        monsterData: [monsterTemplate],
      });
    });

    setSymbolMonsters(initialSymbols);
  }, [currentMap]);

  // Sync player target when playerPos changes
  useEffect(() => {
    player3DPos.current.targetX = playerPos.x * TILE_SCALE;
    player3DPos.current.targetZ = playerPos.y * TILE_SCALE;

    let targetAngle = 0;
    if (playerPos.dir === 'down') targetAngle = 0;
    if (playerPos.dir === 'up') targetAngle = Math.PI;
    if (playerPos.dir === 'left') targetAngle = Math.PI / 2;
    if (playerPos.dir === 'right') targetAngle = -Math.PI / 2;
    player3DPos.current.angle = targetAngle;
  }, [playerPos]);

  // Warp exclusion zone (prevents warping back until player exits the connected entrance/exit area)
  const warpExclusionZoneRef = useRef<Set<string>>(
    getConnectedWarpZone(playerPos.x, playerPos.y, currentMap)
  );
  const lastMapIdRef = useRef<string>(currentMap.id);
  const lastPlayerPosRef = useRef<{ x: number; y: number }>({ x: playerPos.x, y: playerPos.y });

  // Update warp exclusion zone on map transition or warp teleport
  useEffect(() => {
    const isNewMap = currentMap.id !== lastMapIdRef.current;
    const isTeleport = Math.hypot(playerPos.x - lastPlayerPosRef.current.x, playerPos.y - lastPlayerPosRef.current.y) > 1.5;

    if (isNewMap || isTeleport) {
      // Find all connected warp tiles at entry position
      warpExclusionZoneRef.current = getConnectedWarpZone(playerPos.x, playerPos.y, currentMap);
      lastMapIdRef.current = currentMap.id;
    }
    lastPlayerPosRef.current = { x: playerPos.x, y: playerPos.y };
  }, [currentMap, playerPos.x, playerPos.y]);

  // Attempt move
  const attemptMove = (dx: number, dy: number, newDir: 'up' | 'down' | 'left' | 'right') => {
    const targetX = playerPos.x + dx;
    const targetY = playerPos.y + dy;

    if (targetX < 0 || targetX >= currentMap.width || targetY < 0 || targetY >= currentMap.height) {
      onMove({ ...playerPos, dir: newDir });
      return;
    }

    const tile = currentMap.tiles[targetY]?.[targetX];
    const isSolid = tile === 2 || tile === 3 || tile === 4;
    const isNpcSolid = currentMap.npcs.some(npc => npc.x === targetX && npc.y === targetY);

    if (isSolid || isNpcSolid) {
      onMove({ ...playerPos, dir: newDir });
      return;
    }

    const targetKey = `${targetX},${targetY}`;
    const isTargetWarp = currentMap.tiles[targetY]?.[targetX] === 7 ||
      currentMap.warps.some(w => w.x === targetX && w.y === targetY);

    if (!isTargetWarp) {
      // Stepped onto a safe non-warp tile! Player has completely left the warp doorway
      warpExclusionZoneRef.current.clear();
    }

    onMove({ x: targetX, y: targetY, dir: newDir });

    const warp = currentMap.warps.find(w => w.x === targetX && w.y === targetY);
    if (warp) {
      if (!warpExclusionZoneRef.current.has(targetKey)) {
        // Player entered warp from outside!
        dqAudio.playStairs();
        onWarp(warp);
      }
    }
  };

  // Check interaction in front
  const checkInteraction = () => {
    let checkX = playerPos.x;
    let checkY = playerPos.y;

    if (playerPos.dir === 'up') checkY -= 1;
    if (playerPos.dir === 'down') checkY += 1;
    if (playerPos.dir === 'left') checkX -= 1;
    if (playerPos.dir === 'right') checkX += 1;

    // 1. NPC
    const npc = currentMap.npcs.find(n => n.x === checkX && n.y === checkY);
    if (npc) {
      dqAudio.playConfirm();
      onInteract({ type: 'npc', data: npc });
      return;
    }

    // 2. Chest
    const chest = currentMap.chests.find(c => c.x === checkX && c.y === checkY);
    if (chest) {
      dqAudio.playChest();
      onInteract({ type: 'chest', data: chest });
      return;
    }

    // 3. Tile under / in front
    const targetTile = currentMap.tiles[checkY]?.[checkX];
    const standingTile = currentMap.tiles[playerPos.y]?.[playerPos.x];

    if (targetTile === 5 || standingTile === 5) {
      dqAudio.playChurchJingle();
      onInteract({ type: 'altar', data: null });
      return;
    }
    if (targetTile === 6 || standingTile === 6) {
      dqAudio.playTabletChime();
      onInteract({ type: 'pedestal', data: null });
      return;
    }
    if (targetTile === 8 || standingTile === 8) {
      dqAudio.playInnJingle();
      onInteract({ type: 'bed', data: null });
      return;
    }
    if (targetTile === 9 || standingTile === 9) {
      // Tavern counter
      dqAudio.playConfirm();
      onInteract({ type: 'tavern', data: null });
      return;
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      let dx = 0;
      let dy = 0;
      let newDir = playerPos.dir;

      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        dy = -1;
        newDir = 'up';
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        dy = 1;
        newDir = 'down';
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        dx = -1;
        newDir = 'left';
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        dx = 1;
        newDir = 'right';
      } else if (e.key === 'Enter' || e.key === ' ' || e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        checkInteraction();
        return;
      } else {
        return;
      }

      e.preventDefault();
      attemptMove(dx, dy, newDir);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playerPos, currentMap]);

  // Main Three.js Scene Setup & Game Loop
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();

    const isDemon = currentMap.id === 'demon_castle';
    const isCathedral = currentMap.id === 'cathedral_grandzeil';
    const bgColor = isDemon ? 0x110b1a : isCathedral ? 0x181828 : 0x7dd3fc;
    scene.background = new THREE.Color(bgColor);
    scene.fog = new THREE.FogExp2(bgColor, isDemon ? 0.025 : 0.015);

    const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.5, 200);

    const { renderer, dispose } = createOptimizedRenderer(container, {
      antialias: false,
      alpha: false,
      shadows: true,
    });

    // 2. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, isDemon ? 0.45 : 0.75);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xfffbeb, isDemon ? 0.6 : 1.1);
    dirLight.position.set(20, 40, 25);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    scene.add(dirLight);

    // 3. Build 3D Map Environment
    const terrainGroup = new THREE.Group();
    scene.add(terrainGroup);

    // Tile geometries & materials
    const grassGeo = new THREE.BoxGeometry(TILE_SCALE, 0.4, TILE_SCALE);
    const grassMat = new THREE.MeshStandardMaterial({
      color: isDemon ? 0x27193b : 0x22c55e,
      roughness: 0.8,
    });

    const pathGeo = new THREE.BoxGeometry(TILE_SCALE, 0.45, TILE_SCALE);
    const pathMat = new THREE.MeshStandardMaterial({
      color: isDemon ? 0x3b334a : 0xcbd5e1,
      roughness: 0.6,
    });

    const waterGeo = new THREE.BoxGeometry(TILE_SCALE, 0.2, TILE_SCALE);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.1,
      metalness: 0.2,
      transparent: true,
      opacity: 0.85,
    });

    const wallGeo = new THREE.BoxGeometry(TILE_SCALE, 3.2, TILE_SCALE);
    const wallMat = new THREE.MeshStandardMaterial({
      color: isDemon ? 0x4c1d95 : 0x991b1b,
      roughness: 0.7,
    });

    const mountainGeo = new THREE.ConeGeometry(TILE_SCALE * 0.9, 6.0, 5);
    const mountainMat = new THREE.MeshStandardMaterial({
      color: isDemon ? 0x2e1065 : 0x78716c,
      roughness: 0.9,
    });

    // Populate Tiles
    for (let y = 0; y < currentMap.height; y++) {
      for (let x = 0; x < currentMap.width; x++) {
        const tile = currentMap.tiles[y][x];
        const worldX = x * TILE_SCALE;
        const worldZ = y * TILE_SCALE;

        let tileMesh: THREE.Mesh;
        if (tile === 1) {
          tileMesh = new THREE.Mesh(pathGeo, pathMat);
          tileMesh.position.set(worldX, 0, worldZ);
        } else if (tile === 2) {
          tileMesh = new THREE.Mesh(waterGeo, waterMat);
          tileMesh.position.set(worldX, -0.1, worldZ);
        } else if (tile === 3) {
          // Base
          tileMesh = new THREE.Mesh(grassGeo, grassMat);
          tileMesh.position.set(worldX, 0, worldZ);
          // Mountain Peak
          const peak = new THREE.Mesh(mountainGeo, mountainMat);
          peak.position.set(worldX, 3.0, worldZ);
          peak.castShadow = true;
          terrainGroup.add(peak);
        } else if (tile === 4) {
          // House / Wall
          tileMesh = new THREE.Mesh(grassGeo, grassMat);
          tileMesh.position.set(worldX, 0, worldZ);
          const wall = new THREE.Mesh(wallGeo, wallMat);
          wall.position.set(worldX, 1.6, worldZ);
          wall.castShadow = true;
          terrainGroup.add(wall);
        } else {
          // Grass / Ground / Altar / Bed
          tileMesh = new THREE.Mesh(grassGeo, grassMat);
          tileMesh.position.set(worldX, 0, worldZ);

          if (tile === 5) {
            // Church Altar with golden cross
            const crossMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.5, roughness: 0.3 });
            const vBar = new THREE.Mesh(new THREE.BoxGeometry(0.3, 2.2, 0.3), crossMat);
            vBar.position.set(worldX, 1.4, worldZ);
            const hBar = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.3, 0.3), crossMat);
            hBar.position.set(worldX, 1.8, worldZ);
            terrainGroup.add(vBar, hBar);
          } else if (tile === 6) {
            // Pedestal with glowing ring
            const pedMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x0284c7, emissiveIntensity: 0.5 });
            const ped = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.4, 1.2, 8), pedMat);
            ped.position.set(worldX, 0.6, worldZ);
            terrainGroup.add(ped);
          }
        }

        tileMesh.receiveShadow = true;
        terrainGroup.add(tileMesh);
      }
    }

    // 4. Party Character Models in 3D (Human or Dragon Quest Coffin)
    const partyGroup = new THREE.Group();
    scene.add(partyGroup);

    const characterMeshes: Array<{
      group: THREE.Group;
      human: THREE.Group;
      coffin: THREE.Group;
    }> = [];

    party.forEach((char, idx) => {
      const charGroup = new THREE.Group();

      // Human character 3D model
      const humanGroup = new THREE.Group();
      charGroup.add(humanGroup);

      // Body (Capsule/Cylinder)
      const bodyColor = char.appearance?.outfitColor || (idx === 0 ? 0x2563eb : idx === 1 ? 0xdc2626 : 0x7c3aed);
      const bodyMat = new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.5 });
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 1.4, 12), bodyMat);
      body.position.y = 0.9;
      body.castShadow = true;
      humanGroup.add(body);

      // Head
      const headMat = new THREE.MeshStandardMaterial({ color: 0xfed7aa, roughness: 0.6 });
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.45, 12, 12), headMat);
      head.position.y = 1.95;
      head.castShadow = true;
      humanGroup.add(head);

      // Hair
      const hairColor = char.appearance?.hairColor || (idx === 0 ? 0x3b82f6 : idx === 1 ? 0xfacc15 : 0xa855f7);
      const hairMat = new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.7 });
      const hair = new THREE.Mesh(new THREE.ConeGeometry(0.55, 0.6, 8), hairMat);
      hair.position.y = 2.4;
      humanGroup.add(hair);

      // Hero Sword on back (for hero or warriors)
      const swordMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8, roughness: 0.2 });
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.6, 0.05), swordMat);
      blade.position.set(0.3, 1.3, -0.4);
      blade.rotation.z = 0.3;
      humanGroup.add(blade);

      // 3D Dragon Quest Coffin (shown when char.hp <= 0)
      const coffinGroup = createCoffinGroup();
      charGroup.add(coffinGroup);

      const isDead = (char.hp ?? 0) <= 0;
      humanGroup.visible = !isDead;
      coffinGroup.visible = isDead;

      charGroup.position.set(playerPos.x * TILE_SCALE, 0, playerPos.y * TILE_SCALE);
      partyGroup.add(charGroup);
      characterMeshes.push({ group: charGroup, human: humanGroup, coffin: coffinGroup });
    });

    // 5. NPC Billboards in 3D
    const npcGroup = new THREE.Group();
    scene.add(npcGroup);

    currentMap.npcs.forEach(npc => {
      const g = new THREE.Group();
      g.position.set(npc.x * TILE_SCALE, 0, npc.y * TILE_SCALE);

      // Pedestal base
      const base = new THREE.Mesh(
        new THREE.CylinderGeometry(0.7, 0.8, 0.3, 10),
        new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.8 })
      );
      base.position.y = 0.15;
      g.add(base);

      // Character Pillar
      const body = new THREE.Mesh(
        new THREE.CylinderGeometry(0.45, 0.5, 1.3, 10),
        new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.6 })
      );
      body.position.y = 0.9;
      g.add(body);

      // Head
      const head = new THREE.Mesh(
        new THREE.SphereGeometry(0.42, 10, 10),
        new THREE.MeshStandardMaterial({ color: 0xfed7aa })
      );
      head.position.y = 1.85;
      g.add(head);

      // Floating Canvas Sprite with Name and Emoji
      const canvas = document.createElement('canvas');
      canvas.width = 256;
      canvas.height = 128;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.roundRect(10, 10, 236, 108, 16);
        ctx.fill();
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 4;
        ctx.stroke();

        ctx.font = '36px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(npc.sprite, 128, 55);

        ctx.font = 'bold 22px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.fillText(npc.name, 128, 95);
      }
      const texture = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.position.y = 3.4;
      sprite.scale.set(3, 1.5, 1);
      g.add(sprite);

      npcGroup.add(g);
    });

    // 6. Chests in 3D
    const chestGroup = new THREE.Group();
    scene.add(chestGroup);

    currentMap.chests.forEach(chest => {
      const isOpened = openedChests.includes(chest.id);
      const c = new THREE.Group();
      c.position.set(chest.x * TILE_SCALE, 0, chest.y * TILE_SCALE);

      const chestMat = new THREE.MeshStandardMaterial({
        color: isOpened ? 0x78350f : 0xd97706,
        roughness: 0.5,
        metalness: 0.3,
      });

      const box = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.9, 1.0), chestMat);
      box.position.y = 0.45;
      box.castShadow = true;
      c.add(box);

      // Lock
      const lock = new THREE.Mesh(
        new THREE.BoxGeometry(0.25, 0.25, 0.1),
        new THREE.MeshStandardMaterial({ color: 0xfde047, metalness: 0.8 })
      );
      lock.position.set(0, 0.5, 0.52);
      c.add(lock);

      chestGroup.add(c);
    });

    // 7. Symbol Monsters in 3D (with "！" alert indicator and 3-sec chase!)
    const monsterGroup = new THREE.Group();
    scene.add(monsterGroup);

    const monsterObjects = new Map<string, { group: THREE.Group; alertSprite: THREE.Sprite; updateAnim?: (time: number, isHit?: boolean, isTargeted?: boolean) => void }>();

    symbolMonsters.forEach(sm => {
      // Use distinct 3D models for Slime, Dracky, Ghost, Skeleton, Magician, Shadow Demon!
      const model = createMonsterModel(sm.monsterType, { scale: 0.85 });
      const mg = model.group;
      mg.position.set(sm.x, 0, sm.y);

      // "！" Exclamation Mark Alert Billboard
      const alertCanvas = document.createElement('canvas');
      alertCanvas.width = 128;
      alertCanvas.height = 128;
      const actx = alertCanvas.getContext('2d');
      if (actx) {
        actx.fillStyle = '#ef4444';
        actx.beginPath();
        actx.arc(64, 64, 56, 0, Math.PI * 2);
        actx.fill();
        actx.strokeStyle = '#ffffff';
        actx.lineWidth = 8;
        actx.stroke();

        actx.font = 'bold 72px sans-serif';
        actx.fillStyle = '#ffffff';
        actx.textAlign = 'center';
        actx.textBaseline = 'middle';
        actx.fillText('！', 64, 64);
      }
      const alertTex = new THREE.CanvasTexture(alertCanvas);
      const alertSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: alertTex, transparent: true }));
      alertSprite.position.y = 2.8;
      alertSprite.scale.set(1.5, 1.5, 1);
      alertSprite.visible = false;
      mg.add(alertSprite);

      monsterGroup.add(mg);
      monsterObjects.set(sm.id, { group: mg, alertSprite, updateAnim: model.updateAnimation });
    });

    // 8. Animation & Game Loop
    let animationFrameId: number;
    let lastTime = performance.now();
    let walkAnimClock = 0;

    const animate = (time: number) => {
      animationFrameId = requestAnimationFrame(animate);

      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;
      walkAnimClock += dt * 8;

      // Smooth player interpolation
      const playerPosRef = player3DPos.current;
      playerPosRef.x += (playerPosRef.targetX - playerPosRef.x) * Math.min(dt * 12, 1);
      playerPosRef.z += (playerPosRef.targetZ - playerPosRef.z) * Math.min(dt * 12, 1);

      // Record path history for party train
      if (
        pathHistory.current.length === 0 ||
        Math.hypot(
          pathHistory.current[0].x - playerPosRef.x,
          pathHistory.current[0].z - playerPosRef.z
        ) > 0.4
      ) {
        pathHistory.current.unshift({
          x: playerPosRef.x,
          z: playerPosRef.z,
          angle: playerPosRef.angle,
        });
        if (pathHistory.current.length > 50) {
          pathHistory.current.pop();
        }
      }

      // Update party character positions
      characterMeshes.forEach((mesh, idx) => {
        const char = party[idx];
        const isDead = (char?.hp ?? 0) <= 0;
        if (mesh.human.visible !== !isDead) mesh.human.visible = !isDead;
        if (mesh.coffin.visible !== isDead) mesh.coffin.visible = isDead;

        if (idx === 0) {
          // Leader
          mesh.group.position.set(playerPosRef.x, 0, playerPosRef.z);
          mesh.group.rotation.y = playerPosRef.angle;
          // Walk bobbing (only when alive!)
          const isMoving = Math.hypot(playerPosRef.targetX - playerPosRef.x, playerPosRef.targetZ - playerPosRef.z) > 0.05;
          mesh.group.position.y = (isMoving && !isDead) ? Math.abs(Math.sin(walkAnimClock)) * 0.25 : 0;
        } else {
          // Companion followers (train effect)
          const historyIndex = Math.min(idx * 7, pathHistory.current.length - 1);
          if (historyIndex >= 0 && pathHistory.current[historyIndex]) {
            const hist = pathHistory.current[historyIndex];
            mesh.group.position.set(hist.x, 0, hist.z);
            mesh.group.rotation.y = hist.angle;
          }
        }
      });

      // Smooth Camera tracking (third person chase cam)
      const camTargetX = playerPosRef.x;
      const camTargetZ = playerPosRef.z + 12; // behind player
      const camTargetY = 14; // overhead angle

      camera.position.x += (camTargetX - camera.position.x) * 0.08;
      camera.position.y += (camTargetY - camera.position.y) * 0.08;
      camera.position.z += (camTargetZ - camera.position.z) * 0.08;
      camera.lookAt(playerPosRef.x, 1.2, playerPosRef.z);

      // --- Symbol Monster AI Loop (Alert, Chase 5s, Encounter) ---
      symbolMonsters.forEach(sm => {
        if (defeatedSymbolsRef.current.has(sm.id)) return;
        const obj = monsterObjects.get(sm.id);
        if (!obj) return;

        const distToPlayer = Math.hypot(playerPosRef.x - sm.x, playerPosRef.z - sm.y);

        // State Machine
        if (sm.state === 'wandering') {
          obj.alertSprite.visible = false;
          // Detection range: 7 units!
          if (distToPlayer <= 7.0 && sm.cooldownTimer <= 0) {
            // Spotted player!
            sm.state = 'alert';
            sm.chaseTimer = 0;
            sm.alertTimer = 0.5; // flash alert
            dqAudio.playEncounter();
            obj.alertSprite.visible = true;
          } else {
            // Casual wandering
            sm.dir += (Math.random() - 0.5) * 0.1;
            sm.x += Math.cos(sm.dir) * dt * 0.8;
            sm.y += Math.sin(sm.dir) * dt * 0.8;
            if (sm.cooldownTimer > 0) sm.cooldownTimer -= dt;
          }
        } else if (sm.state === 'alert') {
          obj.alertSprite.visible = true;
          sm.alertTimer -= dt;
          if (sm.alertTimer <= 0) {
            sm.state = 'chasing';
          }
        } else if (sm.state === 'chasing') {
          obj.alertSprite.visible = true;
          sm.chaseTimer += dt;

          // Chase towards player!
          const angleToPlayer = Math.atan2(playerPosRef.z - sm.y, playerPosRef.x - sm.x);
          sm.dir = angleToPlayer;
          const chaseSpeed = 3.6; // fast chase
          sm.x += Math.cos(angleToPlayer) * chaseSpeed * dt;
          sm.y += Math.sin(angleToPlayer) * chaseSpeed * dt;

          // Check if caught player!
          if (distToPlayer <= 1.4) {
            // Encounter!!
            defeatedSymbolsRef.current.add(sm.id);
            obj.group.visible = false;
            onSymbolEncounter(sm.monsterData, sm.id);
            return;
          }

          // Check if 3-second chase expired!
          if (sm.chaseTimer >= 3.0) {
            // Lost interest / Player got away!
            sm.state = 'wandering';
            sm.cooldownTimer = 3.5; // Cooldown before spotting again
            obj.alertSprite.visible = false;
          }
        }

        // Apply 3D monster position & animations
        obj.group.position.set(sm.x, Math.abs(Math.sin(walkAnimClock * 1.5)) * 0.15, sm.y);
        obj.group.rotation.y = -sm.dir + Math.PI / 2;
        if (obj.updateAnim) {
          obj.updateAnim(walkAnimClock, false, false);
        }
      });

      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(animate);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      dispose();
    };
  }, [currentMap, symbolMonsters, party, openedChests]);

  return (
    <div className="relative w-full h-full overflow-hidden select-none bg-black">
      {/* Three.js 3D Viewport Canvas */}
      <div ref={mountRef} className="w-full h-full" />

      {/* On-Screen Touch / Mouse Controller (Bottom Left) */}
      <div className="absolute bottom-4 left-4 z-20 flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
        <button
          onClick={() => attemptMove(0, -1, 'up')}
          className="w-12 h-12 bg-slate-900 border-2 border-white rounded-t-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
        >
          ▲
        </button>
        <div className="flex gap-12">
          <button
            onClick={() => attemptMove(-1, 0, 'left')}
            className="w-12 h-12 bg-slate-900 border-2 border-white rounded-l-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
          >
            ◀
          </button>
          <button
            onClick={() => attemptMove(1, 0, 'right')}
            className="w-12 h-12 bg-slate-900 border-2 border-white rounded-r-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
          >
            ▶
          </button>
        </div>
        <button
          onClick={() => attemptMove(0, 1, 'down')}
          className="w-12 h-12 bg-slate-900 border-2 border-white rounded-b-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
        >
          ▼
        </button>
      </div>

      {/* Action / Inspect Button (Bottom Right) */}
      <div className="absolute bottom-4 right-4 z-20 flex gap-3">
        <button
          onClick={checkInteraction}
          className="px-5 py-3 bg-slate-900 border-2 border-amber-400 rounded-lg text-white font-bold text-sm shadow-xl active:scale-95 flex items-center gap-1"
        >
          <span>はなす/しらべる</span>
          <span className="text-xs text-amber-300">(Z/Space)</span>
        </button>
      </div>
    </div>
  );
};
