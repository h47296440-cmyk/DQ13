import React, { useState, useEffect } from 'react';
import { Character, Monster, Spell, Skill, Item, MonsterAction } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { ITEMS, SPELLS, SKILLS, BOSS_NEBULOS_PHASE2 } from '../data/gameData';
import { Battle3DView } from './Battle3DView';

interface BattleScreenProps {
  party: Character[];
  monsters: Monster[];
  isBoss: boolean;
  isLastBoss: boolean;
  backgroundTheme: 'plains' | 'town' | 'castle' | 'dark_abyss';
  onBattleEnd: (result: {
    victory: boolean;
    expGained: number;
    goldGained: number;
    defeatedMonsters: Monster[];
    updatedParty: Character[];
  }) => void;
  onEscapeSuccess: () => void;
}

export const BattleScreen: React.FC<BattleScreenProps> = ({
  party,
  monsters: initialMonsters,
  isBoss,
  isLastBoss,
  backgroundTheme,
  onBattleEnd,
  onEscapeSuccess,
}) => {
  const [monsters, setMonsters] = useState<Monster[]>(initialMonsters.map(m => ({ ...m })));
  const [currentParty, setCurrentParty] = useState<Character[]>(party.map(p => ({ ...p })));
  const [activePartyIdx, setActivePartyIdx] = useState<number>(0);

  // Menu navigation mode
  const [menuMode, setMenuMode] = useState<'main' | 'spell' | 'skill' | 'item' | 'target_enemy' | 'target_ally'>('main');
  const [cursorIdx, setCursorIdx] = useState<number>(0);
  const [targetEnemyIdx, setTargetEnemyIdx] = useState<number>(0);
  const [targetAllyIdx, setTargetAllyIdx] = useState<number>(0);

  // Stored pending selection
  const [activeActionPlan, setActiveActionPlan] = useState<{
    type: 'attack' | 'spell' | 'skill' | 'item';
    id?: string;
  } | null>(null);

  const [pendingActions, setPendingActions] = useState<Array<{
    charIdx: number;
    action: 'attack' | 'spell' | 'skill' | 'item' | 'defend' | 'escape';
    actionId?: string;
    targetMonsterIdx: number;
    targetAllyIdx?: number;
  }>>([]);

  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [message, setMessage] = useState<string>('');
  const [screenShaking, setScreenShaking] = useState<boolean>(false);
  const [flashColor, setFlashColor] = useState<string | null>(null);
  const [hitMonsterIdx, setHitMonsterIdx] = useState<number | null>(null);
  const [hitAllyIdx, setHitAllyIdx] = useState<number | null>(null);
  const [activeAttackEvent, setActiveAttackEvent] = useState<{
    charIdx: number;
    targetMonsterIdx: number;
    actionType: 'attack' | 'spell' | 'skill';
    timestamp: number;
  } | null>(null);
  const [monsterAttackEvent, setMonsterAttackEvent] = useState<{
    monsterIdx: number;
    targetCharIdx: number;
    actionType?: 'attack' | 'spell' | 'skill';
    actionName?: string;
    timestamp: number;
  } | null>(null);

  const currentChar = currentParty[activePartyIdx] || currentParty[0];

  // Start Battle BGM & SFX
  useEffect(() => {
    dqAudio.playEncounter();
    if (isLastBoss) {
      dqAudio.playBgm('lastboss');
    } else if (isBoss) {
      dqAudio.playBgm('boss');
    } else {
      dqAudio.playBgm('battle');
    }

    const enemyNames = monsters.map(m => m.name).join('と ');
    setMessage(`${enemyNames}が あらわれた！`);
  }, []);

  const triggerShake = () => {
    setScreenShaking(true);
    setTimeout(() => setScreenShaking(false), 350);
  };

  const triggerFlash = (color: string) => {
    setFlashColor(color);
    setTimeout(() => setFlashColor(null), 250);
  };

  // Direct Spell Selection
  const handleSelectSpell = (spell: Spell) => {
    dqAudio.playConfirm();
    if (currentChar.mp < spell.mpCost) {
      dqAudio.playCancel();
      setMessage('MPが たりない！');
      return;
    }

    if (spell.type === 'heal') {
      if (spell.target === 'all_allies') {
        queueAction({
          charIdx: activePartyIdx,
          action: 'spell',
          actionId: spell.id,
          targetMonsterIdx: 0,
        });
      } else {
        setActiveActionPlan({ type: 'spell', id: spell.id });
        setMenuMode('target_ally');
        setTargetAllyIdx(activePartyIdx);
      }
    } else {
      if (spell.target === 'all_enemies') {
        queueAction({
          charIdx: activePartyIdx,
          action: 'spell',
          actionId: spell.id,
          targetMonsterIdx: 0,
        });
      } else {
        setActiveActionPlan({ type: 'spell', id: spell.id });
        setMenuMode('target_enemy');
        setTargetEnemyIdx(0);
      }
    }
  };

  // Direct Skill Selection
  const handleSelectSkill = (skill: Skill) => {
    dqAudio.playConfirm();
    if (currentChar.mp < skill.mpCost) {
      dqAudio.playCancel();
      setMessage('MPが たりない！');
      return;
    }

    if (skill.target === 'all_enemies') {
      queueAction({
        charIdx: activePartyIdx,
        action: 'skill',
        actionId: skill.id,
        targetMonsterIdx: 0,
      });
    } else {
      setActiveActionPlan({ type: 'skill', id: skill.id });
      setMenuMode('target_enemy');
      setTargetEnemyIdx(0);
    }
  };

  // Direct Item Selection
  const handleSelectItem = (itemId: string) => {
    dqAudio.playConfirm();
    setActiveActionPlan({ type: 'item', id: itemId });
    setMenuMode('target_ally');
    setTargetAllyIdx(activePartyIdx);
  };

  // Queue Action and Advance Party Member
  const queueAction = (newAction: {
    charIdx: number;
    action: 'attack' | 'spell' | 'skill' | 'item' | 'defend' | 'escape';
    actionId?: string;
    targetMonsterIdx: number;
    targetAllyIdx?: number;
  }) => {
    const updated = [...pendingActions, newAction];
    setPendingActions(updated);

    const nextAliveIdx = currentParty.findIndex((c, idx) => idx > activePartyIdx && c.hp > 0);
    if (nextAliveIdx !== -1) {
      setActivePartyIdx(nextAliveIdx);
      setMenuMode('main');
      setCursorIdx(0);
      setActiveActionPlan(null);
    } else {
      executeTurn(updated);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isExecuting || isFinished) return;

      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        e.preventDefault();
        dqAudio.playCursor();
        setCursorIdx(prev => Math.max(0, prev - 1));
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        e.preventDefault();
        dqAudio.playCursor();
        setCursorIdx(prev => prev + 1);
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        e.preventDefault();
        if (menuMode === 'target_enemy') {
          dqAudio.playCursor();
          setTargetEnemyIdx(prev => (prev > 0 ? prev - 1 : monsters.length - 1));
        } else if (menuMode === 'target_ally') {
          dqAudio.playCursor();
          setTargetAllyIdx(prev => (prev > 0 ? prev - 1 : currentParty.length - 1));
        }
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        if (menuMode === 'target_enemy') {
          dqAudio.playCursor();
          setTargetEnemyIdx(prev => (prev < monsters.length - 1 ? prev + 1 : 0));
        } else if (menuMode === 'target_ally') {
          dqAudio.playCursor();
          setTargetAllyIdx(prev => (prev < currentParty.length - 1 ? prev + 1 : 0));
        }
      } else if (e.key === 'Enter' || e.key === ' ' || e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        confirmKeyboardSelection();
      } else if (e.key === 'Escape' || e.key === 'x' || e.key === 'X') {
        e.preventDefault();
        dqAudio.playCancel();
        handleCancel();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const confirmKeyboardSelection = () => {
    dqAudio.playConfirm();
    if (menuMode === 'main') {
      const commands = ['attack', 'spell', 'skill', 'item', 'defend', 'escape'];
      const cmd = commands[cursorIdx % commands.length];
      if (cmd === 'attack') {
        setActiveActionPlan({ type: 'attack' });
        setMenuMode('target_enemy');
        setTargetEnemyIdx(0);
      } else if (cmd === 'spell') {
        if (currentChar.spells && currentChar.spells.length > 0) {
          setMenuMode('spell');
          setCursorIdx(0);
        } else {
          setMessage(`${currentChar.name}は 唱えられるじゅもんが ない！`);
        }
      } else if (cmd === 'skill') {
        if (currentChar.skills && currentChar.skills.length > 0) {
          setMenuMode('skill');
          setCursorIdx(0);
        } else {
          setMessage(`${currentChar.name}は つかえるとくぎが ない！`);
        }
      } else if (cmd === 'item') {
        setMenuMode('item');
        setCursorIdx(0);
      } else if (cmd === 'defend') {
        queueAction({ charIdx: activePartyIdx, action: 'defend', targetMonsterIdx: 0 });
      } else if (cmd === 'escape') {
        if (isBoss || isLastBoss) {
          setMessage('しかし ここから にげることは できない！');
        } else {
          queueAction({ charIdx: activePartyIdx, action: 'escape', targetMonsterIdx: 0 });
        }
      }
    } else if (menuMode === 'spell') {
      const spell = currentChar.spells[cursorIdx % currentChar.spells.length];
      if (spell) handleSelectSpell(spell);
    } else if (menuMode === 'skill') {
      const skill = currentChar.skills[cursorIdx % currentChar.skills.length];
      if (skill) handleSelectSkill(skill);
    } else if (menuMode === 'item') {
      const itemKeys = ['yakusou', 'jouyakusou', 'seisui', 'sekaiju'];
      const itemId = itemKeys[cursorIdx % itemKeys.length];
      handleSelectItem(itemId);
    } else if (menuMode === 'target_enemy') {
      if (activeActionPlan) {
        queueAction({
          charIdx: activePartyIdx,
          action: activeActionPlan.type,
          actionId: activeActionPlan.id,
          targetMonsterIdx: targetEnemyIdx,
        });
      }
    } else if (menuMode === 'target_ally') {
      if (activeActionPlan) {
        queueAction({
          charIdx: activePartyIdx,
          action: activeActionPlan.type,
          actionId: activeActionPlan.id,
          targetMonsterIdx: 0,
          targetAllyIdx: targetAllyIdx,
        });
      }
    }
  };

  const handleCancel = () => {
    if (menuMode !== 'main') {
      setMenuMode('main');
      setCursorIdx(0);
      setActiveActionPlan(null);
    } else if (activePartyIdx > 0) {
      setActivePartyIdx(prev => prev - 1);
      setPendingActions(prev => prev.slice(0, prev.length - 1));
      setCursorIdx(0);
    }
  };

  const sleep = (ms: number) => new Promise(res => setTimeout(res, ms));

  // Weighted Random Action Selection for Monsters
  const chooseMonsterAction = (actions: MonsterAction[]): MonsterAction => {
    if (!actions || actions.length === 0) {
      return { type: 'attack', name: 'こうげき', chance: 1, message: 'こうげき！' };
    }
    const total = actions.reduce((sum, a) => sum + (a.chance || 1), 0);
    let rnd = Math.random() * total;
    for (const act of actions) {
      rnd -= (act.chance || 1);
      if (rnd <= 0) return act;
    }
    return actions[0];
  };

  // Turn Execution Logic with DQ9 animations
  const executeTurn = async (actionsToExecute: typeof pendingActions) => {
    setIsExecuting(true);
    setMenuMode('main');
    setCursorIdx(0);

    const tempParty = [...currentParty];
    const tempMonsters = [...monsters];

    // Check Escape first
    const escapeAction = actionsToExecute.find(a => a.action === 'escape');
    if (escapeAction) {
      const escapeSuccess = Math.random() < 0.65;
      if (escapeSuccess) {
        setMessage(`${tempParty[escapeAction.charIdx].name}たちは にげだした！`);
        await sleep(1000);
        onEscapeSuccess();
        return;
      } else {
        setMessage('しかし まわりこまれてしまった！');
        await sleep(900);
      }
    }

    // Party Members Action Loop (Dragon Quest IX Dash-up Melee/Magic Animations!)
    for (const act of actionsToExecute) {
      const char = tempParty[act.charIdx];
      if (char.hp <= 0) continue;

      const aliveMonsters = tempMonsters.filter(m => m.hp > 0);
      if (aliveMonsters.length === 0) break;

      let targetMonster = tempMonsters[act.targetMonsterIdx];
      if (!targetMonster || targetMonster.hp <= 0) {
        targetMonster = aliveMonsters[0];
      }
      const actualMonsterIdx = tempMonsters.indexOf(targetMonster);

      if (act.action === 'attack') {
        setMessage(`${char.name}の こうげき！`);
        // Trigger DQ9 Character Dash-up Animation in 3D Arena!
        setActiveAttackEvent({
          charIdx: act.charIdx,
          targetMonsterIdx: actualMonsterIdx,
          actionType: 'attack',
          timestamp: Date.now(),
        });

        // Wait for dash & strike impact
        await sleep(400);

        const isCrit = Math.random() < 0.15;
        let dmg = Math.max(1, Math.round(char.attack - targetMonster.defense / 2 + Math.random() * 4 - 2));
        if (isCrit) {
          dqAudio.playCritical();
          dmg = Math.round(char.attack * 1.85 + Math.random() * 12);
          setMessage(`かいしんの いちげき！！ ${targetMonster.name}に ${dmg}の 大ダメージ！`);
        } else {
          dqAudio.playAttack();
          setMessage(`${targetMonster.name}に ${dmg}の ダメージ！`);
        }

        setHitMonsterIdx(actualMonsterIdx);
        triggerShake();

        targetMonster.hp = Math.max(0, targetMonster.hp - dmg);
        setMonsters([...tempMonsters]);

        // Wait for character to return to formation
        await sleep(550);
        setHitMonsterIdx(null);
        setActiveAttackEvent(null);

        // Check defeat or Phase 2 transformation
        if (targetMonster.hp <= 0) {
          if (targetMonster.id === 'boss_nebulos_1' || (isLastBoss && targetMonster.id !== 'boss_nebulos_2')) {
            dqAudio.stopBgm();
            dqAudio.playEnemyDefeat();
            setMessage('大魔王ネビュロス「グオオオオッ……！ 認めん、人間ごときの痛みに負けてたまるか！」');
            await sleep(2200);

            setMessage('「世界中の絶望の結晶よ、我が身に宿れェェェッ！！」');
            triggerShake();
            triggerFlash('rgba(168, 85, 247, 0.75)');
            dqAudio.playCritical();
            await sleep(2000);

            // Replace with Phase 2!
            const phase2 = { ...BOSS_NEBULOS_PHASE2 };
            tempMonsters[actualMonsterIdx] = phase2;
            setMonsters([...tempMonsters]);

            dqAudio.playBgm('lastboss');
            triggerShake();
            triggerFlash('rgba(239, 68, 68, 0.7)');
            setMessage('（大魔王ネビュロスは 真・絶望の大魔王へと変貌した！！）');
            await sleep(2200);
          } else {
            dqAudio.playEnemyDefeat();
            setMessage(`${targetMonster.name}を たおした！`);
            await sleep(650);
          }
        }
      } else if (act.action === 'spell' && act.actionId) {
        const spell = SPELLS[act.actionId];
        if (spell) {
          char.mp = Math.max(0, char.mp - spell.mpCost);
          setCurrentParty([...tempParty]);
          dqAudio.playMagic();
          triggerFlash('rgba(99, 102, 241, 0.4)');
          setMessage(`${char.name}は ${spell.name}を となえた！`);

          // Trigger DQ9 Character Magic Cast Animation in 3D Arena!
          setActiveAttackEvent({
            charIdx: act.charIdx,
            targetMonsterIdx: actualMonsterIdx,
            actionType: 'spell',
            timestamp: Date.now(),
          });

          await sleep(500);

          if (spell.type === 'damage') {
            if (spell.target === 'single_enemy') {
              setHitMonsterIdx(actualMonsterIdx);
              triggerShake();
              const dmg = Math.round(spell.power + Math.random() * 8);
              targetMonster.hp = Math.max(0, targetMonster.hp - dmg);
              setMessage(`${targetMonster.name}に ${dmg}の ダメージ！`);
              setMonsters([...tempMonsters]);
              await sleep(500);
              setHitMonsterIdx(null);
              setActiveAttackEvent(null);

              if (targetMonster.hp <= 0) {
                if (targetMonster.id === 'boss_nebulos_1' || (isLastBoss && targetMonster.id !== 'boss_nebulos_2')) {
                  dqAudio.stopBgm();
                  dqAudio.playEnemyDefeat();
                  setMessage('大魔王ネビュロス「グオオオオッ……！ 認めん、人間ごときの痛みに負けてたまるか！」');
                  await sleep(2200);
                  setMessage('「世界中の絶望の結晶よ、我が身に宿れェェェッ！！」');
                  triggerShake();
                  triggerFlash('rgba(168, 85, 247, 0.75)');
                  dqAudio.playCritical();
                  await sleep(2000);
                  tempMonsters[actualMonsterIdx] = { ...BOSS_NEBULOS_PHASE2 };
                  setMonsters([...tempMonsters]);
                  dqAudio.playBgm('lastboss');
                  triggerShake();
                  setMessage('（大魔王ネビュロスは 真・絶望の大魔王へと変貌した！！）');
                  await sleep(2200);
                } else {
                  dqAudio.playEnemyDefeat();
                  setMessage(`${targetMonster.name}を たおした！`);
                  await sleep(650);
                }
              }
            } else {
              triggerShake();
              tempMonsters.forEach(m => {
                if (m.hp > 0) {
                  const dmg = Math.round(spell.power + Math.random() * 8);
                  m.hp = Math.max(0, m.hp - dmg);
                }
              });
              setMessage(`敵全体に ${spell.power}前後の 激しいダメージ！`);
              setMonsters([...tempMonsters]);
              await sleep(600);
              setActiveAttackEvent(null);
            }
          } else if (spell.type === 'heal') {
            dqAudio.playLevelUp();
            if (spell.target === 'all_allies') {
              tempParty.forEach(c => {
                if (c.hp > 0) c.hp = Math.min(c.maxHp, c.hp + spell.power);
              });
              setMessage(`仲間全員のHPが 約${spell.power} 回復した！`);
            } else {
              const targetChar = tempParty[act.targetAllyIdx ?? act.charIdx];
              targetChar.hp = Math.min(targetChar.maxHp, targetChar.hp + spell.power);
              setMessage(`${targetChar.name}のHPが ${spell.power} 回復した！`);
            }
            setCurrentParty([...tempParty]);
            await sleep(600);
            setActiveAttackEvent(null);
          }
        }
      } else if (act.action === 'skill' && act.actionId) {
        const skill = SKILLS[act.actionId];
        if (skill) {
          char.mp = Math.max(0, char.mp - skill.mpCost);
          setCurrentParty([...tempParty]);
          setMessage(`${char.name}の ${skill.name}！！`);

          // Trigger DQ9 Character Skill Dash Animation in 3D Arena!
          setActiveAttackEvent({
            charIdx: act.charIdx,
            targetMonsterIdx: actualMonsterIdx,
            actionType: 'skill',
            timestamp: Date.now(),
          });

          await sleep(450);
          dqAudio.playAttack();
          triggerShake();

          if (skill.target === 'all_enemies') {
            tempMonsters.forEach(m => {
              if (m.hp > 0) {
                const dmg = Math.round(char.attack * skill.powerMultiplier - m.defense / 3);
                m.hp = Math.max(0, m.hp - Math.max(5, dmg));
              }
            });
            setMessage(`神速の技が 敵全体を 切り裂いた！`);
            setMonsters([...tempMonsters]);
            await sleep(550);
            setActiveAttackEvent(null);
          } else {
            setHitMonsterIdx(actualMonsterIdx);
            const dmg = Math.round(char.attack * skill.powerMultiplier - targetMonster.defense / 3);
            targetMonster.hp = Math.max(0, targetMonster.hp - Math.max(10, dmg));
            setMessage(`${targetMonster.name}に ${dmg}の 痛烈なダメージ！`);
            setMonsters([...tempMonsters]);
            await sleep(500);
            setHitMonsterIdx(null);
            setActiveAttackEvent(null);

            if (targetMonster.hp <= 0) {
              if (targetMonster.id === 'boss_nebulos_1' || (isLastBoss && targetMonster.id !== 'boss_nebulos_2')) {
                dqAudio.stopBgm();
                dqAudio.playEnemyDefeat();
                setMessage('大魔王ネビュロス「グオオオオッ……！ 認めん、人間ごときの痛みに負けてたまるか！」');
                await sleep(2200);
                setMessage('「世界中の絶望の結晶よ、我が身に宿れェェェッ！！」');
                triggerShake();
                triggerFlash('rgba(168, 85, 247, 0.75)');
                dqAudio.playCritical();
                await sleep(2000);
                tempMonsters[actualMonsterIdx] = { ...BOSS_NEBULOS_PHASE2 };
                setMonsters([...tempMonsters]);
                dqAudio.playBgm('lastboss');
                triggerShake();
                setMessage('（大魔王ネビュロスは 真・絶望の大魔王へと変貌した！！）');
                await sleep(2200);
              } else {
                dqAudio.playEnemyDefeat();
                setMessage(`${targetMonster.name}を たおした！`);
                await sleep(600);
              }
            }
          }
        }
      } else if (act.action === 'item' && act.actionId) {
        const it = ITEMS[act.actionId];
        if (it) {
          dqAudio.playConfirm();
          const targetChar = tempParty[act.targetAllyIdx ?? act.charIdx];
          if (it.id === 'yakusou' || it.id === 'jouyakusou') {
            targetChar.hp = Math.min(targetChar.maxHp, targetChar.hp + (it.effectValue || 35));
            setMessage(`${char.name}は ${it.name}を 使った！ ${targetChar.name}のHPが回復した！`);
          } else if (it.id === 'seisui') {
            targetChar.mp = Math.min(targetChar.maxMp, targetChar.mp + 30);
            setMessage(`${char.name}は ${it.name}を 使った！ ${targetChar.name}のMPが30回復した！`);
          } else if (it.id === 'sekaiju') {
            targetChar.hp = targetChar.maxHp;
            setMessage(`${targetChar.name}は せかいじゅの葉の奇跡で 息を吹き返した！`);
          }
          setCurrentParty([...tempParty]);
          await sleep(650);
        }
      } else if (act.action === 'defend') {
        setMessage(`${char.name}は みをまもっている。`);
        await sleep(500);
      }

      if (tempMonsters.every(m => m.hp <= 0)) {
        handleVictory(tempParty, tempMonsters);
        return;
      }
    }

    // Monsters Turn (With Lunge Animations & prioritized Kafrizz / Shockwave!)
    for (let i = 0; i < tempMonsters.length; i++) {
      const monster = tempMonsters[i];
      if (monster.hp <= 0) continue;

      const aliveParty = tempParty.filter(c => c.hp > 0);
      if (aliveParty.length === 0) {
        handleDefeat(tempParty);
        return;
      }

      const action = chooseMonsterAction(monster.actions);
      const targetChar = aliveParty[Math.floor(Math.random() * aliveParty.length)];
      const targetAllyIdx = tempParty.indexOf(targetChar);

      setMessage(action.message);

      // Trigger 3D Monster lunge animation
      setMonsterAttackEvent({
        monsterIdx: i,
        targetCharIdx: targetAllyIdx,
        actionType: action.type as any,
        actionName: action.name,
        timestamp: Date.now(),
      });

      await sleep(450);
      setHitAllyIdx(targetAllyIdx);

      if (action.name.includes('メラゾーマ')) {
        // Kafrizz / メラゾーマ: Massive fireball and flame pillar!
        dqAudio.playMagic();
        dqAudio.playCritical();
        triggerFlash('rgba(239, 68, 68, 0.8)');
        triggerShake();
        const dmg = Math.max(1, Math.round((action.power || 90) - targetChar.defense / 4 + Math.random() * 12));
        targetChar.hp = Math.max(0, targetChar.hp - dmg);
        setCurrentParty([...tempParty]);
        setMessage(`紅蓮の獄炎が爆発する！ ${targetChar.name}は ${dmg}の 壊滅的ダメージ！`);
        await sleep(650);
      } else if (action.name.includes('しょうげきは') || action.target === 'all') {
        // Shockwave / しょうげきは: Sweeping shockwave hitting all allies!
        dqAudio.playDamage();
        triggerFlash('rgba(255, 255, 255, 0.85)');
        triggerShake();
        aliveParty.forEach(c => {
          const dmg = Math.max(1, Math.round((action.power || 60) - c.defense / 4 + Math.random() * 10));
          c.hp = Math.max(0, c.hp - dmg);
        });
        setCurrentParty([...tempParty]);
        setMessage(`大気をも震わす衝撃波が 仲間全員をなぎ倒した！`);
        await sleep(650);
      } else if (action.name.includes('いてつくはどう')) {
        dqAudio.playMagic();
        triggerFlash('rgba(147, 197, 253, 0.7)');
        setMessage(`大魔王ネビュロスの いてつくはどう！ すべての補助効果がかき消された！`);
        await sleep(650);
      } else if (action.type === 'attack') {
        dqAudio.playDamage();
        triggerShake();
        const dmg = Math.max(1, Math.round(monster.attack - targetChar.defense / 2 + Math.random() * 6 - 3));
        targetChar.hp = Math.max(0, targetChar.hp - dmg);
        setCurrentParty([...tempParty]);
        setMessage(`${targetChar.name}は ${dmg}の ダメージをうけた！`);
        await sleep(600);
      } else {
        dqAudio.playDamage();
        triggerShake();
        const dmg = Math.max(1, Math.round((action.power || 40) - targetChar.defense / 3 + Math.random() * 6));
        targetChar.hp = Math.max(0, targetChar.hp - dmg);
        setCurrentParty([...tempParty]);
        setMessage(`${targetChar.name}は ${dmg}の 激しいダメージをうけた！`);
        await sleep(600);
      }

      setHitAllyIdx(null);
      setMonsterAttackEvent(null);

      if (targetChar.hp <= 0) {
        setMessage(`${targetChar.name}は ちからつきてしまった……！`);
        await sleep(650);
      }

      if (tempParty.every(c => c.hp <= 0)) {
        handleDefeat(tempParty);
        return;
      }
    }

    // Reset for Next Turn
    setIsExecuting(false);
    setPendingActions([]);
    const firstAlive = tempParty.findIndex(c => c.hp > 0);
    setActivePartyIdx(firstAlive !== -1 ? firstAlive : 0);
    setMenuMode('main');
    setCursorIdx(0);
    setMessage('コマンド？');
  };

  const handleVictory = async (finalParty: Character[], defeated: Monster[]) => {
    setIsFinished(true);

    if (isLastBoss || defeated.some(m => m.id === 'boss_nebulos_2')) {
      // Epic Last Boss Defeat Sequence
      dqAudio.stopBgm();
      setMessage('真・絶望の大魔王ネビュロス「バカナ……！ 人間が……絶望を抱えたまま、前へ進むというのか……！？」');
      await sleep(2600);

      triggerFlash('rgba(255, 255, 255, 0.95)');
      triggerShake();
      setMessage('大魔王ネビュロスは 崩壊し、眩い光の粒子となって霧散した！');
      await sleep(2200);

      dqAudio.playVictoryFanfare();
      setMessage('アレクたちは ついに世界に光と真実の記憶を取り戻した！！');
      await sleep(2200);

      onBattleEnd({
        victory: true,
        expGained: 9999,
        goldGained: 9999,
        defeatedMonsters: defeated,
        updatedParty: finalParty,
      });
      return;
    }

    dqAudio.playVictoryFanfare();

    const totalExp = defeated.reduce((sum, m) => sum + m.exp, 0);
    const totalGold = defeated.reduce((sum, m) => sum + m.gold, 0);

    setMessage('魔物を やっつけた！');
    await sleep(1500);

    setMessage(`アレクたちは ${totalExp}ポイントの けいけんちを かくとく！`);
    await sleep(1200);

    setMessage(`${totalGold}ゴールドを てにいれた！`);
    await sleep(1200);

    // Calculate EXP & Level up progression on finalParty
    const updatedParty = finalParty.map(char => {
      const c = { ...char };
      if (c.hp > 0) {
        c.exp += totalExp;
        while (c.exp >= c.nextExp) {
          c.level += 1;
          c.maxHp += 12;
          c.hp = c.maxHp;
          c.maxMp += 6;
          c.mp = c.maxMp;
          c.attack += 5;
          c.defense += 4;
          c.agility += 3;
          c.nextExp = Math.round(c.nextExp * 1.85);
        }
      }
      return c;
    });

    setCurrentParty(updatedParty);

    // Check if anyone leveled up to show message
    for (const c of updatedParty) {
      const oldChar = finalParty.find(p => p.id === c.id);
      if (oldChar && c.level > oldChar.level) {
        dqAudio.playLevelUp();
        setMessage(`${c.name}は レベルが ${c.level}に あがった！`);
        await sleep(1500);
      }
    }

    const boss = defeated.find(m => m.defeatText);
    if (boss && boss.defeatText) {
      setMessage(boss.defeatText);
      await sleep(2000);
    }

    // Pass the leveled-up updatedParty back to App!
    onBattleEnd({
      victory: true,
      expGained: totalExp,
      goldGained: totalGold,
      defeatedMonsters: defeated,
      updatedParty,
    });
  };

  const handleDefeat = async (finalParty: Character[]) => {
    setIsFinished(true);
    dqAudio.playDamage();
    setMessage('……全滅してしまった……');
    await sleep(2000);
    onBattleEnd({
      victory: false,
      expGained: 0,
      goldGained: 0,
      defeatedMonsters: [],
      updatedParty: finalParty,
    });
  };

  return (
    <div className={`relative w-full h-full flex flex-col justify-between overflow-hidden select-none bg-black ${screenShaking ? 'shake-screen' : ''}`}>
      {/* 3D Battle Arena Viewport (Dragon Quest IX 3D Presentation) */}
      <div className="absolute inset-0">
        <Battle3DView
          party={currentParty}
          monsters={monsters}
          backgroundTheme={backgroundTheme}
          isBoss={isBoss}
          isLastBoss={isLastBoss}
          hitMonsterIdx={hitMonsterIdx}
          hitAllyIdx={hitAllyIdx}
          targetMonsterIdx={targetEnemyIdx}
          activeAttackEvent={activeAttackEvent}
          monsterAttackEvent={monsterAttackEvent}
        />
      </div>

      {/* Screen Flash Effect */}
      {flashColor && (
        <div
          className="absolute inset-0 pointer-events-none z-40 transition-opacity"
          style={{ backgroundColor: flashColor }}
        />
      )}

      {/* Top Header: Party Status Cards */}
      <div className="relative z-10 p-3 flex justify-center gap-3 flex-wrap">
        {currentParty.map((char, idx) => {
          const isActive = idx === activePartyIdx && !isExecuting && !isFinished;
          return (
            <div
              key={char.id}
              className={`dq-window px-4 py-2 min-w-[155px] transition-transform ${
                isActive ? 'border-amber-400 scale-105 shadow-[0_0_12px_rgba(245,158,11,0.5)]' : 'opacity-90'
              } ${char.hp <= 0 ? 'border-red-600 bg-red-950/70' : ''}`}
            >
              <div className="flex items-center justify-between text-sm font-bold border-b border-white/20 pb-1 mb-1">
                <span>{char.name}</span>
                <span className="text-xs text-amber-300">Lv.{char.level}</span>
              </div>
              <div className="text-xs flex justify-between">
                <span>H:</span>
                <span className={char.hp <= char.maxHp * 0.25 ? 'text-red-400 font-bold' : 'text-emerald-300 font-mono'}>
                  {char.hp}/{char.maxHp}
                </span>
              </div>
              <div className="text-xs flex justify-between">
                <span>M:</span>
                <span className="text-cyan-300 font-mono">{char.mp}/{char.maxMp}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Center Target Indicator HUD */}
      <div className="relative z-10 flex-1 flex items-center justify-center pointer-events-none">
        {menuMode === 'target_enemy' && (
          <div className="px-4 py-1.5 bg-black/70 border border-amber-400 rounded text-amber-300 text-sm font-bold animate-pulse">
            対象の魔物をえらんでください (◀ ▶ または クリック)
          </div>
        )}
      </div>

      {/* Bottom Area: Classic Dragon Quest Command & Message Box */}
      <div className="relative z-10 p-3 flex flex-col md:flex-row gap-3 items-stretch max-w-4xl mx-auto w-full">
        {/* Command Menu (Left Window) */}
        {!isExecuting && !isFinished && (
          <div className="dq-window p-3 min-w-[240px] flex-shrink-0">
            {menuMode === 'main' && (
              <div className="grid grid-cols-2 gap-y-2 text-sm">
                {[
                  { id: 'attack', label: 'たたかう' },
                  { id: 'spell', label: 'じゅもん' },
                  { id: 'skill', label: 'とくぎ' },
                  { id: 'item', label: 'どうぐ' },
                  { id: 'defend', label: 'ぼうぎょ' },
                  { id: 'escape', label: 'にげる' },
                ].map((item, idx) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (item.id === 'attack') {
                        setActiveActionPlan({ type: 'attack' });
                        setMenuMode('target_enemy');
                        setTargetEnemyIdx(0);
                      } else if (item.id === 'spell') {
                        if (currentChar.spells && currentChar.spells.length > 0) {
                          setMenuMode('spell');
                          setCursorIdx(0);
                        } else {
                          setMessage(`${currentChar.name}は 唱えられるじゅもんが ない！`);
                        }
                      } else if (item.id === 'skill') {
                        if (currentChar.skills && currentChar.skills.length > 0) {
                          setMenuMode('skill');
                          setCursorIdx(0);
                        } else {
                          setMessage(`${currentChar.name}は つかえるとくぎが ない！`);
                        }
                      } else if (item.id === 'item') {
                        setMenuMode('item');
                        setCursorIdx(0);
                      } else if (item.id === 'defend') {
                        queueAction({ charIdx: activePartyIdx, action: 'defend', targetMonsterIdx: 0 });
                      } else if (item.id === 'escape') {
                        if (isBoss || isLastBoss) {
                          setMessage('しかし ここから にげることは できない！');
                        } else {
                          queueAction({ charIdx: activePartyIdx, action: 'escape', targetMonsterIdx: 0 });
                        }
                      }
                    }}
                    className="text-left flex items-center hover:text-amber-300 py-1"
                  >
                    <span className="w-4 text-amber-400 font-bold">
                      {cursorIdx === idx ? '▶' : ' '}
                    </span>
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Spells Submenu */}
            {menuMode === 'spell' && (
              <div className="flex flex-col gap-1 text-sm max-h-40 overflow-y-auto">
                <div className="text-xs text-amber-400 font-bold border-b border-white/20 pb-1 mb-1 flex justify-between">
                  <span>【じゅもん】</span>
                  <span className="text-[10px] text-white/60">クリックで選択</span>
                </div>
                {currentChar.spells.map((spell, idx) => (
                  <button
                    key={spell.id}
                    onClick={() => handleSelectSpell(spell)}
                    className="text-left flex items-center justify-between hover:text-amber-300 hover:bg-white/10 p-1 rounded"
                  >
                    <span className="flex items-center">
                      <span className="w-4 text-amber-400 font-bold">
                        {cursorIdx === idx ? '▶' : ' '}
                      </span>
                      <span>{spell.name}</span>
                    </span>
                    <span className="text-xs text-cyan-300 font-mono">MP {spell.mpCost}</span>
                  </button>
                ))}
                <button
                  onClick={handleCancel}
                  className="mt-1 text-xs text-white/60 hover:text-white text-center py-1 border-t border-white/20"
                >
                  キャンセル (Esc)
                </button>
              </div>
            )}

            {/* Skills Submenu */}
            {menuMode === 'skill' && (
              <div className="flex flex-col gap-1 text-sm max-h-40 overflow-y-auto">
                <div className="text-xs text-amber-400 font-bold border-b border-white/20 pb-1 mb-1 flex justify-between">
                  <span>【とくぎ】</span>
                  <span className="text-[10px] text-white/60">クリックで選択</span>
                </div>
                {currentChar.skills.map((skill, idx) => (
                  <button
                    key={skill.id}
                    onClick={() => handleSelectSkill(skill)}
                    className="text-left flex items-center justify-between hover:text-amber-300 hover:bg-white/10 p-1 rounded"
                  >
                    <span className="flex items-center">
                      <span className="w-4 text-amber-400 font-bold">
                        {cursorIdx === idx ? '▶' : ' '}
                      </span>
                      <span>{skill.name}</span>
                    </span>
                    <span className="text-xs text-cyan-300 font-mono">MP {skill.mpCost}</span>
                  </button>
                ))}
                <button
                  onClick={handleCancel}
                  className="mt-1 text-xs text-white/60 hover:text-white text-center py-1 border-t border-white/20"
                >
                  キャンセル (Esc)
                </button>
              </div>
            )}

            {/* Items Submenu */}
            {menuMode === 'item' && (
              <div className="flex flex-col gap-1 text-sm">
                <div className="text-xs text-amber-400 font-bold border-b border-white/20 pb-1 mb-1">
                  【どうぐ】
                </div>
                {[
                  { id: 'yakusou', name: 'やくそう' },
                  { id: 'jouyakusou', name: '上やくそう' },
                  { id: 'seisui', name: 'まほうのせいすい' },
                  { id: 'sekaiju', name: 'せかいじゅの葉' },
                ].map((it, idx) => (
                  <button
                    key={it.id}
                    onClick={() => handleSelectItem(it.id)}
                    className="text-left flex items-center hover:text-amber-300 p-1 rounded hover:bg-white/10"
                  >
                    <span className="w-4 text-amber-400 font-bold">
                      {cursorIdx === idx ? '▶' : ' '}
                    </span>
                    <span>{it.name}</span>
                  </button>
                ))}
                <button
                  onClick={handleCancel}
                  className="mt-1 text-xs text-white/60 hover:text-white text-center py-1 border-t border-white/20"
                >
                  キャンセル (Esc)
                </button>
              </div>
            )}

            {/* Target Enemy Selection */}
            {menuMode === 'target_enemy' && (
              <div className="flex flex-col gap-1 text-sm">
                <div className="text-xs text-amber-400 font-bold border-b border-white/20 pb-1 mb-1">
                  【敵をえらぶ】
                </div>
                {monsters.map((m, idx) => (
                  <button
                    key={m.id + idx}
                    onClick={() => {
                      if (activeActionPlan) {
                        queueAction({
                          charIdx: activePartyIdx,
                          action: activeActionPlan.type,
                          actionId: activeActionPlan.id,
                          targetMonsterIdx: idx,
                        });
                      }
                    }}
                    className="text-left flex items-center hover:text-amber-300 p-1 rounded hover:bg-white/10"
                  >
                    <span className="w-4 text-amber-400 font-bold">
                      {targetEnemyIdx === idx ? '▶' : ' '}
                    </span>
                    <span>{m.name}</span>
                  </button>
                ))}
                <button
                  onClick={handleCancel}
                  className="mt-1 text-xs text-white/60 hover:text-white text-center py-1 border-t border-white/20"
                >
                  もどる (Esc)
                </button>
              </div>
            )}

            {/* Target Ally Selection */}
            {menuMode === 'target_ally' && (
              <div className="flex flex-col gap-1 text-sm">
                <div className="text-xs text-amber-400 font-bold border-b border-white/20 pb-1 mb-1">
                  【仲間をえらぶ】
                </div>
                {currentParty.map((p, idx) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      if (activeActionPlan) {
                        queueAction({
                          charIdx: activePartyIdx,
                          action: activeActionPlan.type,
                          actionId: activeActionPlan.id,
                          targetMonsterIdx: 0,
                          targetAllyIdx: idx,
                        });
                      }
                    }}
                    className="text-left flex items-center justify-between hover:text-amber-300 p-1 rounded hover:bg-white/10"
                  >
                    <span className="flex items-center">
                      <span className="w-4 text-amber-400 font-bold">
                        {targetAllyIdx === idx ? '▶' : ' '}
                      </span>
                      <span>{p.name}</span>
                    </span>
                    <span className="text-xs text-emerald-400 font-mono">
                      {p.hp}/{p.maxHp}
                    </span>
                  </button>
                ))}
                <button
                  onClick={handleCancel}
                  className="mt-1 text-xs text-white/60 hover:text-white text-center py-1 border-t border-white/20"
                >
                  もどる (Esc)
                </button>
              </div>
            )}
          </div>
        )}

        {/* Message Log Window (Right Window) */}
        <div className="dq-window flex-1 p-4 min-h-[90px] flex items-center">
          <p className="text-base leading-relaxed tracking-wide font-sans md:font-mono">
            {message}
          </p>
        </div>
      </div>
    </div>
  );
};
