import React, { useState } from 'react';
import { Character, CharacterAppearance } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { SPELLS, SKILLS } from '../data/gameData';

interface CharMakeModalProps {
  initialName?: string;
  isRecruiting?: boolean;
  onConfirm: (char: Character) => void;
  onCancel?: () => void;
}

const HAIR_COLORS = [
  { label: '青 (ブルー)', value: '#3b82f6' },
  { label: '金 (ゴールド)', value: '#facc15' },
  { label: '黒 (漆黒)', value: '#1e293b' },
  { label: '栗 (ブラウン)', value: '#854d0e' },
  { label: '赤 (クリムゾン)', value: '#ef4444' },
  { label: '銀 (プラチナ)', value: '#e2e8f0' },
  { label: '紫 (アメジスト)', value: '#a855f7' },
];

const OUTFIT_COLORS = [
  { label: 'ロトブルー', value: '#2563eb' },
  { label: '真紅の衣', value: '#dc2626' },
  { label: '翠緑の装束', value: '#059669' },
  { label: '漆黒のマント', value: '#0f172a' },
  { label: '黄金の鎧', value: '#d97706' },
  { label: '純白のローブ', value: '#f8fafc' },
];

const VOCATIONS = [
  { id: 'hero', name: '勇者', role: '勇者', desc: '剣と呪文を兼ね備えた万能の戦士' },
  { id: 'warrior', name: '戦士', role: '戦士', desc: '高いHPと力で敵を圧倒する武人' },
  { id: 'mage', name: '魔法使い', role: '魔法使い', desc: '攻撃呪文で敵を一掃する魔導士' },
  { id: 'cleric', name: '僧侶', role: '僧侶', desc: '回復と治療の奇跡を司る聖職者' },
  { id: 'martial_artist', name: '武闘家', role: '武闘家', desc: '素早さと会心の一撃を誇る拳士' },
  { id: 'thief', name: '盗賊', role: '盗賊', desc: '目にも留まらぬ速さで駆け巡る風の旅人' },
  { id: 'sage', name: '賢者', role: '賢者', desc: '深遠なる知恵で全てを操る万能賢者' },
];

const PERSONALITIES = [
  { name: '熱血漢', bonus: { attack: 3, defense: 1 }, desc: '力と守備が高くなりやすい' },
  { name: '冷静沈着', bonus: { agility: 2, maxMp: 4 }, desc: 'すばやさとMPが高くなりやすい' },
  { name: '豪快無比', bonus: { maxHp: 6, attack: 2 }, desc: '圧倒的な生命力と攻撃力' },
  { name: '優美高潔', bonus: { maxMp: 6, agility: 2 }, desc: '魔力と素早さに優れる' },
];

export const CharMakeModal: React.FC<CharMakeModalProps> = ({
  initialName = 'アレク',
  isRecruiting = false,
  onConfirm,
  onCancel,
}) => {
  const [name, setName] = useState<string>(initialName);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [hairColor, setHairColor] = useState<string>(HAIR_COLORS[0].value);
  const [outfitColor, setOutfitColor] = useState<string>(OUTFIT_COLORS[0].value);
  const [vocationIdx, setVocationIdx] = useState<number>(isRecruiting ? 1 : 0);
  const [personalityIdx, setPersonalityIdx] = useState<number>(0);

  // 5 Bonus stat points
  const [remainingPoints, setRemainingPoints] = useState<number>(5);
  const [bonusStrength, setBonusStrength] = useState<number>(0);
  const [bonusAgility, setBonusAgility] = useState<number>(0);
  const [bonusWisdom, setBonusWisdom] = useState<number>(0);
  const [bonusVitality, setBonusVitality] = useState<number>(0);

  const selectedVocation = VOCATIONS[vocationIdx];
  const selectedPersonality = PERSONALITIES[personalityIdx];

  const adjustStat = (stat: 'str' | 'agi' | 'wis' | 'vit', delta: number) => {
    if (delta > 0 && remainingPoints <= 0) return;
    if (delta < 0) {
      if (stat === 'str' && bonusStrength <= 0) return;
      if (stat === 'agi' && bonusAgility <= 0) return;
      if (stat === 'wis' && bonusWisdom <= 0) return;
      if (stat === 'vit' && bonusVitality <= 0) return;
    }

    dqAudio.playCursor();
    setRemainingPoints(prev => prev - delta);
    if (stat === 'str') setBonusStrength(prev => prev + delta);
    if (stat === 'agi') setBonusAgility(prev => prev + delta);
    if (stat === 'wis') setBonusWisdom(prev => prev + delta);
    if (stat === 'vit') setBonusVitality(prev => prev + delta);
  };

  const handleFinish = () => {
    dqAudio.playConfirm();
    const persBonus = selectedPersonality.bonus;

    // Calculate base stats based on vocation
    let baseHp = 30 + bonusVitality * 3 + (persBonus.maxHp || 0);
    let baseMp = 10 + bonusWisdom * 2 + (persBonus.maxMp || 0);
    let baseAtk = 15 + bonusStrength * 2 + (persBonus.attack || 0);
    let baseDef = 12 + (persBonus.defense || 0);
    let baseAgi = 10 + bonusAgility * 2 + (persBonus.agility || 0);

    const charSpells = [];
    const charSkills = [];

    if (selectedVocation.id === 'hero') {
      charSpells.push(SPELLS.hoimi, SPELLS.mera);
      charSkills.push(SKILLS.hayabusa);
    } else if (selectedVocation.id === 'warrior') {
      baseHp += 15;
      baseAtk += 6;
      baseDef += 4;
      baseMp = 0;
      charSkills.push(SKILLS.kabutowari, SKILLS.sutemi);
    } else if (selectedVocation.id === 'mage') {
      baseMp += 25;
      baseAtk -= 4;
      charSpells.push(SPELLS.mera, SPELLS.gira, SPELLS.rukanan);
    } else if (selectedVocation.id === 'cleric') {
      baseMp += 20;
      baseHp += 5;
      charSpells.push(SPELLS.hoimi, SPELLS.behoimi);
    } else if (selectedVocation.id === 'martial_artist') {
      baseAgi += 10;
      baseAtk += 4;
      charSkills.push(SKILLS.bakuretsuken);
    } else if (selectedVocation.id === 'thief') {
      baseAgi += 12;
      baseDef += 2;
      charSkills.push(SKILLS.hayabusa);
    } else if (selectedVocation.id === 'sage') {
      baseMp += 30;
      baseHp += 8;
      charSpells.push(SPELLS.hoimi, SPELLS.merami, SPELLS.begiragon);
    }

    const appearance: CharacterAppearance = {
      gender,
      hairColor,
      outfitColor,
      vocation: selectedVocation.id as any,
      personality: selectedPersonality.name,
    };

    const newChar: Character = {
      id: isRecruiting ? `custom_${Date.now()}` : 'hero',
      name: name.trim() || (gender === 'male' ? 'アレク' : 'エリーナ'),
      title: `${selectedPersonality.name}の${selectedVocation.name}`,
      role: selectedVocation.role,
      level: 1,
      hp: baseHp,
      maxHp: baseHp,
      mp: baseMp,
      maxMp: baseMp,
      attack: baseAtk,
      defense: baseDef,
      agility: baseAgi,
      exp: 0,
      nextExp: 15,
      spells: charSpells,
      skills: charSkills,
      equipment: {
        weapon: selectedVocation.id === 'mage' || selectedVocation.id === 'cleric' ? 'まどうしの杖' : 'どうのつるぎ',
        armor: selectedVocation.id === 'mage' || selectedVocation.id === 'cleric' ? 'たびびとの服' : 'かわのよろい',
        shield: '皮のたて',
        accessory: '初心者の指輪',
      },
      status: 'normal',
      appearance,
    };

    onConfirm(newChar);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 select-none">
      <div className="dq-window max-w-3xl w-full p-6 flex flex-col gap-5 max-h-[95vh] overflow-y-auto">
        <div className="border-b border-white/20 pb-2 flex items-center justify-between">
          <span className="text-xl font-bold text-amber-300">
            {isRecruiting ? '【ルイーダの酒場】冒険者登録' : '【キャラクターメイク】主人公作成'}
          </span>
          <span className="text-xs text-white/60">能力と姿を自由にカスタマイズ</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left: Settings Inputs */}
          <div className="flex flex-col gap-4 text-sm">
            {/* Name */}
            <div className="flex items-center gap-3">
              <span className="font-bold w-16">名前:</span>
              <input
                type="text"
                value={name}
                maxLength={6}
                onChange={(e) => setName(e.target.value)}
                placeholder="名前を入力"
                className="flex-1 bg-black/60 border-2 border-white px-3 py-1.5 rounded font-bold text-amber-300 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Gender */}
            <div className="flex items-center gap-3">
              <span className="font-bold w-16">性別:</span>
              <div className="flex gap-2">
                <button
                  onClick={() => { dqAudio.playCursor(); setGender('male'); }}
                  className={`px-4 py-1 rounded border ${
                    gender === 'male' ? 'bg-blue-600 text-white border-blue-400 font-bold' : 'border-white/30 text-white/70'
                  }`}
                >
                  男 ♂
                </button>
                <button
                  onClick={() => { dqAudio.playCursor(); setGender('female'); }}
                  className={`px-4 py-1 rounded border ${
                    gender === 'female' ? 'bg-pink-600 text-white border-pink-400 font-bold' : 'border-white/30 text-white/70'
                  }`}
                >
                  女 ♀
                </button>
              </div>
            </div>

            {/* Vocation (if recruiting, can select all) */}
            {isRecruiting && (
              <div className="flex flex-col gap-1">
                <span className="font-bold">職業:</span>
                <div className="grid grid-cols-3 gap-1.5">
                  {VOCATIONS.filter(v => v.id !== 'hero').map((voc, idx) => (
                    <button
                      key={voc.id}
                      onClick={() => { dqAudio.playCursor(); setVocationIdx(idx + 1); }}
                      className={`px-2 py-1 text-xs rounded border text-center ${
                        selectedVocation.id === voc.id ? 'bg-amber-500 text-black font-bold border-amber-300' : 'border-white/30 text-white'
                      }`}
                    >
                      {voc.name}
                    </button>
                  ))}
                </div>
                <div className="text-xs text-amber-200 mt-0.5">{selectedVocation.desc}</div>
              </div>
            )}

            {/* Hair Color */}
            <div className="flex flex-col gap-1">
              <span className="font-bold">髪の色:</span>
              <div className="flex gap-2 flex-wrap">
                {HAIR_COLORS.map(c => (
                  <button
                    key={c.value}
                    onClick={() => { dqAudio.playCursor(); setHairColor(c.value); }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform ${
                      hairColor === c.value ? 'scale-125 border-white shadow-lg' : 'border-white/20'
                    }`}
                    style={{ backgroundColor: c.value }}
                    title={c.label}
                  />
                ))}
              </div>
            </div>

            {/* Outfit Color */}
            <div className="flex flex-col gap-1">
              <span className="font-bold">装束の色:</span>
              <div className="flex gap-2 flex-wrap">
                {OUTFIT_COLORS.map(c => (
                  <button
                    key={c.value}
                    onClick={() => { dqAudio.playCursor(); setOutfitColor(c.value); }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform ${
                      outfitColor === c.value ? 'scale-125 border-white shadow-lg' : 'border-white/20'
                    }`}
                    style={{ backgroundColor: c.value }}
                    title={c.label}
                  />
                ))}
              </div>
            </div>

            {/* Personality */}
            <div className="flex flex-col gap-1">
              <span className="font-bold">性格:</span>
              <div className="grid grid-cols-2 gap-1.5">
                {PERSONALITIES.map((p, idx) => (
                  <button
                    key={p.name}
                    onClick={() => { dqAudio.playCursor(); setPersonalityIdx(idx); }}
                    className={`px-2.5 py-1 text-xs rounded border text-left ${
                      personalityIdx === idx ? 'bg-amber-500 text-black font-bold border-amber-300' : 'border-white/30 text-white'
                    }`}
                  >
                    <div>{p.name}</div>
                    <div className="text-[10px] opacity-80">{p.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right: 3D-Styled Character Preview & Stat Bonus Distribution */}
          <div className="flex flex-col gap-4">
            {/* Visual Character Avatar */}
            <div className="bg-black/60 border border-white/20 p-4 rounded-lg flex flex-col items-center justify-center">
              <div className="relative w-28 h-28 flex items-center justify-center rounded-2xl border-2 border-white/40 shadow-inner bg-gradient-to-b from-slate-900 to-black">
                {/* 3D Character Model Silhouette & Palette */}
                <div
                  className="w-16 h-16 rounded-full border-2 border-white/50 flex items-center justify-center shadow-lg transition-colors"
                  style={{ backgroundColor: hairColor }}
                >
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-2xl shadow"
                    style={{ backgroundColor: '#fed7aa' }}
                  >
                    {gender === 'male' ? '👦' : '👧'}
                  </div>
                </div>

                {/* Outfit badge */}
                <div
                  className="absolute bottom-1 w-20 h-6 rounded-md border border-white/40 shadow flex items-center justify-center text-[10px] font-bold text-white"
                  style={{ backgroundColor: outfitColor }}
                >
                  {selectedVocation.name}
                </div>
              </div>

              <div className="mt-2 text-center">
                <div className="text-base font-bold text-amber-300">{name || '名無しの勇士'}</div>
                <div className="text-xs text-white/70">{selectedPersonality.name}の{selectedVocation.name}</div>
              </div>
            </div>

            {/* Bonus Stat Points */}
            <div className="bg-black/50 border border-white/20 p-3 rounded-lg flex flex-col gap-2 text-xs">
              <div className="flex items-center justify-between font-bold border-b border-white/20 pb-1">
                <span className="text-amber-300">ボーナス能力値配分</span>
                <span className="text-cyan-300 font-mono">残りポイント: {remainingPoints}</span>
              </div>

              {[
                { id: 'str', label: 'ちから (攻撃力)', val: bonusStrength },
                { id: 'agi', label: 'すばやさ (素早さ)', val: bonusAgility },
                { id: 'wis', label: 'かしこさ (MP/魔力)', val: bonusWisdom },
                { id: 'vit', label: 'たいりょく (最大HP)', val: bonusVitality },
              ].map(s => (
                <div key={s.id} className="flex items-center justify-between">
                  <span>{s.label}:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => adjustStat(s.id as any, -1)}
                      className="w-6 h-6 bg-slate-800 border border-white/40 rounded flex items-center justify-center font-bold hover:bg-slate-700"
                    >
                      -
                    </button>
                    <span className="w-5 text-center font-mono font-bold text-amber-300">+{s.val}</span>
                    <button
                      onClick={() => adjustStat(s.id as any, 1)}
                      className="w-6 h-6 bg-slate-800 border border-white/40 rounded flex items-center justify-center font-bold hover:bg-slate-700"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="border-t border-white/20 pt-3 flex justify-between">
          {onCancel && (
            <button
              onClick={() => { dqAudio.playCancel(); onCancel(); }}
              className="px-5 py-2 border border-white/40 rounded text-xs hover:border-white text-white/80"
            >
              キャンセル
            </button>
          )}
          <button
            onClick={handleFinish}
            className="ml-auto px-8 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold text-sm rounded shadow-lg active:scale-95"
          >
            決定して登録する
          </button>
        </div>
      </div>
    </div>
  );
};
