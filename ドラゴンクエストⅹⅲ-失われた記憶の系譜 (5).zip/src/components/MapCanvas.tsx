import React, { useEffect, useRef, useState, useCallback } from 'react';
import { MapData, Character, NPC, Chest } from '../types/game';
import { dqAudio } from '../audio/dqAudio';
import { getConnectedWarpZone } from '../utils/coffinModel';

interface MapCanvasProps {
  currentMap: MapData;
  playerPos: { x: number; y: number; dir: 'up' | 'down' | 'left' | 'right' };
  party: Character[];
  openedChests: string[];
  solvedFlags: Record<string, boolean>;
  onMove: (newPos: { x: number; y: number; dir: 'up' | 'down' | 'left' | 'right' }) => void;
  onInteract: (target: { type: 'npc' | 'chest' | 'altar' | 'pedestal' | 'bed'; data: any }) => void;
  onWarp: (warp: { targetMap: string; targetX: number; targetY: number }) => void;
  onEncounter: () => void;
}

const TILE_SIZE = 48;

export const MapCanvas: React.FC<MapCanvasProps> = ({
  currentMap,
  playerPos,
  party,
  openedChests,
  solvedFlags,
  onMove,
  onInteract,
  onWarp,
  onEncounter,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [stepCount, setStepCount] = useState<number>(0);
  const [walkFrame, setWalkFrame] = useState<number>(0);

  // Warp exclusion zone (prevents warping back until player exits the connected entrance/exit area)
  const warpExclusionZoneRef = useRef<Set<string>>(
    getConnectedWarpZone(playerPos.x, playerPos.y, currentMap)
  );
  const lastMapIdRef = useRef<string>(currentMap.id);
  const lastPlayerPosRef = useRef<{ x: number; y: number }>({ x: playerPos.x, y: playerPos.y });

  useEffect(() => {
    const isNewMap = currentMap.id !== lastMapIdRef.current;
    const isTeleport = Math.hypot(playerPos.x - lastPlayerPosRef.current.x, playerPos.y - lastPlayerPosRef.current.y) > 1.5;

    if (isNewMap || isTeleport) {
      warpExclusionZoneRef.current = getConnectedWarpZone(playerPos.x, playerPos.y, currentMap);
      lastMapIdRef.current = currentMap.id;
    }
    lastPlayerPosRef.current = { x: playerPos.x, y: playerPos.y };
  }, [currentMap, playerPos.x, playerPos.y]);

  // Keyboard navigation
  useEffect(() => {
    let moveTimeout: number | null = null;

    const handleKeyDown = (e: KeyboardEvent) => {
      let dx = 0;
      let dy = 0;
      let newDir = playerPos.dir;

      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        dy = -1;
        newDir = 'up';
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        dy = 1;
        newDir = 'down';
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        dx = -1;
        newDir = 'left';
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        dx = 1;
        newDir = 'right';
      } else if (e.key === 'Enter' || e.key === ' ' || e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        checkInteraction();
        return;
      } else {
        return;
      }

      e.preventDefault();
      attemptMove(dx, dy, newDir);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (moveTimeout) clearTimeout(moveTimeout);
    };
  }, [playerPos, currentMap, openedChests, solvedFlags, stepCount]);

  const attemptMove = (dx: number, dy: number, newDir: 'up' | 'down' | 'left' | 'right') => {
    const targetX = playerPos.x + dx;
    const targetY = playerPos.y + dy;

    // Check bounds
    if (targetX < 0 || targetX >= currentMap.width || targetY < 0 || targetY >= currentMap.height) {
      onMove({ ...playerPos, dir: newDir });
      return;
    }

    // Check collision tiles
    const tile = currentMap.tiles[targetY]?.[targetX];
    const isSolid = tile === 2 || tile === 3 || tile === 4; // Water, Mountain, Wall

    // Check NPC collision
    const isNpcSolid = currentMap.npcs.some(npc => npc.x === targetX && npc.y === targetY);

    if (isSolid || isNpcSolid) {
      onMove({ ...playerPos, dir: newDir });
      return;
    }

    const targetKey = `${targetX},${targetY}`;
    const isTargetWarp = currentMap.tiles[targetY]?.[targetX] === 7 ||
      currentMap.warps.some(w => w.x === targetX && w.y === targetY);

    if (!isTargetWarp) {
      // Stepped onto a safe non-warp tile! Player has completely left the warp doorway
      warpExclusionZoneRef.current.clear();
    }

    // Valid move!
    setWalkFrame(prev => (prev + 1) % 4);
    onMove({ x: targetX, y: targetY, dir: newDir });

    // Check Warp
    const warp = currentMap.warps.find(w => w.x === targetX && w.y === targetY);
    if (warp) {
      if (!warpExclusionZoneRef.current.has(targetKey)) {
        dqAudio.playStairs();
        onWarp(warp);
        return;
      }
    }

    // Field Random Encounter check
    if (currentMap.id === 'world_map' || currentMap.id === 'demon_castle') {
      const newSteps = stepCount + 1;
      setStepCount(newSteps);
      if (newSteps > 5 && Math.random() < 0.15) {
        setStepCount(0);
        onEncounter();
      }
    }
  };

  const checkInteraction = () => {
    let checkX = playerPos.x;
    let checkY = playerPos.y;

    if (playerPos.dir === 'up') checkY -= 1;
    if (playerPos.dir === 'down') checkY += 1;
    if (playerPos.dir === 'left') checkX -= 1;
    if (playerPos.dir === 'right') checkX += 1;

    // 1. Check NPC
    const npc = currentMap.npcs.find(n => n.x === checkX && n.y === checkY);
    if (npc) {
      dqAudio.playConfirm();
      onInteract({ type: 'npc', data: npc });
      return;
    }

    // 2. Check Chest
    const chest = currentMap.chests.find(c => c.x === checkX && c.y === checkY);
    if (chest) {
      dqAudio.playChest();
      onInteract({ type: 'chest', data: chest });
      return;
    }

    // 3. Check Tile under/in front (altar, pedestal, bed)
    const targetTile = currentMap.tiles[checkY]?.[checkX];
    const standingTile = currentMap.tiles[playerPos.y]?.[playerPos.x];

    if (targetTile === 5 || standingTile === 5) {
      // Church altar save
      dqAudio.playChurchJingle();
      onInteract({ type: 'altar', data: null });
      return;
    }

    if (targetTile === 6 || standingTile === 6) {
      // Pedestal
      dqAudio.playTabletChime();
      onInteract({ type: 'pedestal', data: null });
      return;
    }

    if (targetTile === 8 || standingTile === 8) {
      // Inn bed
      dqAudio.playInnJingle();
      onInteract({ type: 'bed', data: null });
      return;
    }
  };

  // Canvas Rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Render viewport centered on player
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const viewCols = 13;
    const viewRows = 11;
    const viewWidth = viewCols * TILE_SIZE;
    const viewHeight = viewRows * TILE_SIZE;

    const offsetX = Math.floor(canvas.width / 2 - (playerPos.x + 0.5) * TILE_SIZE);
    const offsetY = Math.floor(canvas.height / 2 - (playerPos.y + 0.5) * TILE_SIZE);

    // 1. Draw Map Tiles
    for (let y = 0; y < currentMap.height; y++) {
      for (let x = 0; x < currentMap.width; x++) {
        const tile = currentMap.tiles[y][x];
        const screenX = offsetX + x * TILE_SIZE;
        const screenY = offsetY + y * TILE_SIZE;

        // Skip off-screen tiles
        if (screenX < -TILE_SIZE || screenX > canvas.width || screenY < -TILE_SIZE || screenY > canvas.height) {
          continue;
        }

        drawTile(ctx, tile, screenX, screenY, x, y, currentMap.id);
      }
    }

    // 2. Draw Chests
    currentMap.chests.forEach(chest => {
      const screenX = offsetX + chest.x * TILE_SIZE;
      const screenY = offsetY + chest.y * TILE_SIZE;
      const isOpened = openedChests.includes(chest.id);
      drawChest(ctx, screenX, screenY, isOpened);
    });

    // 3. Draw NPCs
    currentMap.npcs.forEach(npc => {
      const screenX = offsetX + npc.x * TILE_SIZE;
      const screenY = offsetY + npc.y * TILE_SIZE;
      drawNpc(ctx, npc, screenX, screenY);
    });

    // 4. Draw Party Members (Following Train! Dead members become iconic Dragon Quest coffins)
    for (let idx = party.length - 1; idx >= 0; idx--) {
      const char = party[idx];
      const isDead = (char?.hp ?? 0) <= 0;
      if (idx === 0) {
        if (isDead) {
          drawCoffinSprite(ctx, offsetX + playerPos.x * TILE_SIZE, offsetY + playerPos.y * TILE_SIZE, walkFrame);
        } else {
          drawCharacterSprite(ctx, offsetX + playerPos.x * TILE_SIZE, offsetY + playerPos.y * TILE_SIZE, 'hero', playerPos.dir, walkFrame);
        }
      } else {
        const followerPos = getTrailingPos(playerPos, idx);
        const role = idx === 1 ? 'jansen' : idx === 2 ? 'sierra' : 'hero';
        if (isDead) {
          drawCoffinSprite(ctx, offsetX + followerPos.x * TILE_SIZE, offsetY + followerPos.y * TILE_SIZE, walkFrame);
        } else {
          drawCharacterSprite(ctx, offsetX + followerPos.x * TILE_SIZE, offsetY + followerPos.y * TILE_SIZE, role, followerPos.dir, walkFrame);
        }
      }
    }

  }, [currentMap, playerPos, party, openedChests, walkFrame]);

  const getTrailingPos = (leaderPos: typeof playerPos, offset: number) => {
    let tx = leaderPos.x;
    let ty = leaderPos.y;
    if (leaderPos.dir === 'up') ty += offset;
    if (leaderPos.dir === 'down') ty -= offset;
    if (leaderPos.dir === 'left') tx += offset;
    if (leaderPos.dir === 'right') tx -= offset;
    return { x: tx, y: ty, dir: leaderPos.dir };
  };

  const drawTile = (ctx: CanvasRenderingContext2D, tile: number, x: number, y: number, gx: number, gy: number, mapId: string) => {
    switch (tile) {
      case 0: // Grass / Ground
        ctx.fillStyle = mapId === 'demon_castle' ? '#181824' : '#22c55e';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        // Small blades of grass
        ctx.fillStyle = mapId === 'demon_castle' ? '#2e2640' : '#16a34a';
        if ((gx + gy) % 3 === 0) {
          ctx.fillRect(x + 12, y + 16, 4, 8);
          ctx.fillRect(x + 28, y + 30, 4, 8);
        }
        break;

      case 1: // Cobblestone path
        ctx.fillStyle = mapId === 'demon_castle' ? '#334155' : '#cbd5e1';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        ctx.strokeStyle = mapId === 'demon_castle' ? '#1e293b' : '#94a3b8';
        ctx.lineWidth = 1;
        ctx.strokeRect(x + 2, y + 2, TILE_SIZE - 4, TILE_SIZE - 4);
        break;

      case 2: // Water
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        ctx.fillStyle = '#0284c7';
        ctx.fillRect(x + 8, y + 16, 16, 4);
        ctx.fillRect(x + 24, y + 32, 16, 4);
        break;

      case 3: // Mountains
        ctx.fillStyle = mapId === 'demon_castle' ? '#3b0764' : '#78716c';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        ctx.fillStyle = mapId === 'demon_castle' ? '#6b21a8' : '#a8a29e';
        ctx.beginPath();
        ctx.moveTo(x + TILE_SIZE / 2, y + 4);
        ctx.lineTo(x + TILE_SIZE - 4, y + TILE_SIZE - 4);
        ctx.lineTo(x + 4, y + TILE_SIZE - 4);
        ctx.closePath();
        ctx.fill();
        break;

      case 4: // Wall / Tree / House Roof
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        // Roof shingles
        ctx.fillStyle = mapId === 'demon_castle' ? '#581c87' : '#991b1b';
        ctx.fillRect(x + 4, y + 4, TILE_SIZE - 8, TILE_SIZE - 8);
        ctx.strokeStyle = '#fca5a5';
        ctx.strokeRect(x + 4, y + 4, TILE_SIZE - 8, TILE_SIZE - 8);
        break;

      case 5: // Church Altar
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        // Golden Cross
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(x + 20, y + 8, 8, 32);
        ctx.fillRect(x + 12, y + 16, 24, 8);
        break;

      case 6: // Pedestal (Ancient Altar)
        ctx.fillStyle = '#475569';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        // Glowing magic circle
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.strokeRect(x + 6, y + 6, TILE_SIZE - 12, TILE_SIZE - 12);
        ctx.fillStyle = '#67e8f9';
        ctx.fillRect(x + 18, y + 18, 12, 12);
        break;

      case 7: // Warp / Gate
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        ctx.strokeStyle = '#e2e8f0';
        ctx.strokeRect(x + 4, y + 4, TILE_SIZE - 8, TILE_SIZE - 8);
        break;

      case 8: // Inn Bed
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(x, y, TILE_SIZE, TILE_SIZE);
        ctx.fillStyle = '#3b82f6';
        ctx.fillRect(x + 6, y + 14, TILE_SIZE - 12, TILE_SIZE - 20);
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x + 10, y + 6, TILE_SIZE - 20, 8); // pillow
        break;
    }
  };

  const drawChest = (ctx: CanvasRenderingContext2D, x: number, y: number, opened: boolean) => {
    ctx.fillStyle = opened ? '#78350f' : '#b45309';
    ctx.fillRect(x + 8, y + 12, 32, 26);
    ctx.fillStyle = '#fde047';
    ctx.fillRect(x + 20, y + 20, 8, 10);
    ctx.strokeStyle = '#451a03';
    ctx.strokeRect(x + 8, y + 12, 32, 26);
  };

  const drawNpc = (ctx: CanvasRenderingContext2D, npc: NPC, x: number, y: number) => {
    // Character bubble
    ctx.font = '28px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(npc.sprite, x + TILE_SIZE / 2, y + TILE_SIZE / 2 - 2);

    // Prompt indicator
    ctx.fillStyle = '#f59e0b';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText(npc.name, x + TILE_SIZE / 2, y - 4);
  };

  const drawCharacterSprite = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    role: 'hero' | 'jansen' | 'sierra',
    dir: 'up' | 'down' | 'left' | 'right',
    frame: number
  ) => {
    const cx = x + TILE_SIZE / 2;
    const cy = y + TILE_SIZE / 2;

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(cx, cy + 16, 14, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    let emoji = '🗡️';
    if (role === 'hero') emoji = '🦸‍♂️';
    if (role === 'jansen') emoji = '🤺';
    if (role === 'sierra') emoji = '🧙‍♀️';

    ctx.font = '30px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Slight walk bounce
    const bounce = (frame % 2 === 1) ? -2 : 0;
    ctx.fillText(emoji, cx, cy + bounce);
  };

  const drawCoffinSprite = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    frame: number
  ) => {
    const cx = x + TILE_SIZE / 2;
    const cy = y + TILE_SIZE / 2;

    // Ground shadow
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.beginPath();
    ctx.ellipse(cx, cy + 16, 16, 7, 0, 0, Math.PI * 2);
    ctx.fill();

    // Subtle slide glide
    const slideOffset = (frame % 2 === 1) ? -1 : 0;
    const boxY = cy - 16 + slideOffset;

    // Outer Casket Outline (classic DQ casket shape)
    const boxW = 28;
    const boxH = 34;
    const bx = cx - boxW / 2;

    // Dark outline
    ctx.fillStyle = '#1c1917';
    ctx.fillRect(bx - 2, boxY - 2, boxW + 4, boxH + 4);

    // Rich dark oak wood body
    ctx.fillStyle = '#78350f';
    ctx.fillRect(bx, boxY, boxW, boxH);

    // Beveled inner lid
    ctx.fillStyle = '#92400e';
    ctx.fillRect(bx + 2, boxY + 2, boxW - 4, boxH - 4);

    // Iron corner straps / brackets (head and foot of casket)
    ctx.fillStyle = '#334155';
    ctx.fillRect(bx - 1, boxY + 3, boxW + 2, 4);
    ctx.fillRect(bx - 1, boxY + boxH - 7, boxW + 2, 4);

    // Royal Dragon Quest purple pall cloth draped in center
    ctx.fillStyle = '#6b21a8';
    ctx.fillRect(bx + 4, boxY + 8, boxW - 8, boxH - 16);
    ctx.fillStyle = '#7e22ce';
    ctx.fillRect(bx + 5, boxY + 9, boxW - 10, boxH - 18);

    // Holy Golden Cross on top of the purple cloth
    ctx.fillStyle = '#d97706';
    // Vertical bar
    ctx.fillRect(cx - 2, boxY + 11, 4, 14);
    // Horizontal bar
    ctx.fillRect(cx - 6, boxY + 14, 12, 4);

    // Golden cross highlight
    ctx.fillStyle = '#fde047';
    ctx.fillRect(cx - 1, boxY + 12, 2, 12);
    ctx.fillRect(cx - 5, boxY + 15, 10, 2);
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center bg-black overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        width={720}
        height={520}
        className="w-full h-full max-w-4xl max-h-[600px] object-contain dq-window"
      />

      {/* On-Screen Virtual Controller for Touch & Quick Mouse Play */}
      <div className="absolute bottom-4 left-4 z-20 flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
        <button
          onClick={() => attemptMove(0, -1, 'up')}
          className="w-12 h-12 bg-slate-900 border-2 border-white rounded-t-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
        >
          ▲
        </button>
        <div className="flex gap-12">
          <button
            onClick={() => attemptMove(-1, 0, 'left')}
            className="w-12 h-12 bg-slate-900 border-2 border-white rounded-l-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
          >
            ◀
          </button>
          <button
            onClick={() => attemptMove(1, 0, 'right')}
            className="w-12 h-12 bg-slate-900 border-2 border-white rounded-r-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
          >
            ▶
          </button>
        </div>
        <button
          onClick={() => attemptMove(0, 1, 'down')}
          className="w-12 h-12 bg-slate-900 border-2 border-white rounded-b-lg flex items-center justify-center text-white active:bg-amber-600 font-bold"
        >
          ▼
        </button>
      </div>

      {/* Action & Menu Button (Bottom Right) */}
      <div className="absolute bottom-4 right-4 z-20 flex gap-3">
        <button
          onClick={checkInteraction}
          className="px-5 py-3 bg-slate-900 border-2 border-amber-400 rounded-lg text-white font-bold text-sm shadow-xl active:scale-95 flex items-center gap-1"
        >
          <span>はなす/しらべる</span>
          <span className="text-xs text-amber-300">(Z/Space)</span>
        </button>
      </div>
    </div>
  );
};
