import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Character, Monster } from '../types/game';
import { createOptimizedRenderer } from '../utils/rendererHelper';
import { createMonsterModel, MonsterMeshResult } from '../utils/monsterModels';
import { createPartyMember3DModel, CharacterMeshResult } from '../utils/characterModels';

interface Battle3DViewProps {
  party: Character[];
  monsters: Monster[];
  backgroundTheme: 'plains' | 'town' | 'castle' | 'dark_abyss';
  isBoss: boolean;
  isLastBoss: boolean;
  hitMonsterIdx: number | null;
  hitAllyIdx?: number | null;
  targetMonsterIdx: number;
  activeAttackEvent?: {
    charIdx: number;
    targetMonsterIdx: number;
    actionType: 'attack' | 'spell' | 'skill';
    timestamp: number;
  } | null;
  monsterAttackEvent?: {
    monsterIdx: number;
    targetCharIdx: number;
    actionType?: 'attack' | 'spell' | 'skill';
    actionName?: string;
    timestamp: number;
  } | null;
  onAttackHit?: () => void;
  onAttackComplete?: () => void;
}

export const Battle3DView: React.FC<Battle3DViewProps> = ({
  party,
  monsters,
  backgroundTheme,
  isBoss,
  isLastBoss,
  hitMonsterIdx,
  hitAllyIdx,
  targetMonsterIdx,
  activeAttackEvent,
  monsterAttackEvent,
  onAttackHit,
  onAttackComplete,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // References for live 3D updates
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const monsterResultsRef = useRef<MonsterMeshResult[]>([]);
  const partyResultsRef = useRef<CharacterMeshResult[]>([]);
  const targetMarkerRef = useRef<THREE.Mesh | null>(null);
  const fxGroupRef = useRef<THREE.Group | null>(null);

  // Positions in arena
  const monsterPositionsRef = useRef<THREE.Vector3[]>([]);
  const partyPositionsRef = useRef<THREE.Vector3[]>([]);

  // Distinct IDs for stable scene creation (prevents tearing down scene on simple stat changes)
  const partyKey = party.map(p => p.id).join(',');
  const monstersKey = monsters.map(m => m.id).join(',');

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene & Camera (Dragon Quest IX 3rd person perspective)
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(
      48,
      container.clientWidth / container.clientHeight,
      0.1,
      150
    );
    // Positioned behind party, looking over shoulder towards the enemy monsters
    camera.position.set(0, 4.4, 9.5);
    camera.lookAt(0, 1.8, 0);
    cameraRef.current = camera;

    // 2. High performance WebGPU / WebGL Renderer
    const { renderer, dispose } = createOptimizedRenderer(container, {
      antialias: false,
      alpha: false,
      shadows: true,
    });

    // 3. Lighting & Environment Atmosphere
    let skyColor = 0x60a5fa;
    let groundColor = 0x22c55e;
    let fogDensity = 0.016;

    if (backgroundTheme === 'town') {
      skyColor = 0xfde68a;
      groundColor = 0x94a3b8;
    } else if (backgroundTheme === 'castle') {
      skyColor = 0x1e1b4b;
      groundColor = 0x475569;
      fogDensity = 0.022;
    } else if (backgroundTheme === 'dark_abyss') {
      skyColor = 0x0f0728;
      groundColor = 0x2e1065;
      fogDensity = 0.028;
    }

    scene.background = new THREE.Color(skyColor);
    scene.fog = new THREE.FogExp2(skyColor, fogDensity);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 1.35);
    keyLight.position.set(8, 22, 14);
    keyLight.castShadow = true;
    scene.add(keyLight);

    // Rim lighting
    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.6);
    rimLight.position.set(-10, 12, -10);
    scene.add(rimLight);

    // 4. Arena Floor & Scenery Props
    const sceneryGroup = new THREE.Group();
    scene.add(sceneryGroup);

    // Floor Arena
    const floorGeo = new THREE.CylinderGeometry(20, 21, 0.8, 24);
    const floorMat = new THREE.MeshStandardMaterial({
      color: groundColor,
      roughness: 0.8,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.position.y = -0.4;
    floor.receiveShadow = true;
    sceneryGroup.add(floor);

    // Environment Props based on theme
    if (backgroundTheme === 'plains') {
      for (let i = 0; i < 7; i++) {
        const treeGroup = new THREE.Group();
        const trunk = new THREE.Mesh(
          new THREE.CylinderGeometry(0.25, 0.35, 2.5, 6),
          new THREE.MeshStandardMaterial({ color: 0x78350f })
        );
        trunk.position.y = 1.25;
        const foliage = new THREE.Mesh(
          new THREE.ConeGeometry(1.6, 3.2, 6),
          new THREE.MeshStandardMaterial({ color: 0x15803d })
        );
        foliage.position.y = 3.5;
        treeGroup.add(trunk, foliage);
        const ang = (i / 7) * Math.PI * 1.5 - Math.PI * 0.75;
        treeGroup.position.set(Math.sin(ang) * 15, 0, -Math.cos(ang) * 15 - 4);
        sceneryGroup.add(treeGroup);
      }
    } else if (backgroundTheme === 'town') {
      [-8, 8].forEach(posX => {
        const house = new THREE.Mesh(
          new THREE.BoxGeometry(4.5, 5, 4.5),
          new THREE.MeshStandardMaterial({ color: 0xfef08a })
        );
        house.position.set(posX, 2.5, -6);
        const roof = new THREE.Mesh(
          new THREE.ConeGeometry(3.6, 2.4, 4),
          new THREE.MeshStandardMaterial({ color: 0xb91c1c })
        );
        roof.position.set(posX, 6.2, -6);
        roof.rotation.y = Math.PI / 4;
        sceneryGroup.add(house, roof);
      });
    } else if (backgroundTheme === 'castle') {
      [-6, -2, 2, 6].forEach(posX => {
        const pillar = new THREE.Mesh(
          new THREE.CylinderGeometry(0.7, 0.9, 9, 8),
          new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.6 })
        );
        pillar.position.set(posX, 4.5, -7);
        const torchLight = new THREE.PointLight(0xf59e0b, 1.2, 10);
        torchLight.position.set(posX > 0 ? posX - 0.7 : posX + 0.7, 4.0, -6.5);
        sceneryGroup.add(pillar, torchLight);
      });
    } else if (backgroundTheme === 'dark_abyss') {
      for (let i = 0; i < 8; i++) {
        const crystal = new THREE.Mesh(
          new THREE.OctahedronGeometry(0.9 + Math.random() * 0.6, 0),
          new THREE.MeshStandardMaterial({
            color: 0xa855f7,
            emissive: 0x7c3aed,
            emissiveIntensity: 0.9,
            roughness: 0.2,
          })
        );
        crystal.position.set((i - 3.5) * 3.6, 3.0 + Math.sin(i) * 1.5, -8.5);
        sceneryGroup.add(crystal);
      }
    }

    // 5. Party 3D Characters (Foreground - Dragon Quest IX Style)
    const partyGroup = new THREE.Group();
    scene.add(partyGroup);
    partyResultsRef.current = [];
    partyPositionsRef.current = [];

    party.forEach((char, idx) => {
      const charModel = createPartyMember3DModel(char, idx, party.length);
      partyGroup.add(charModel.group);
      partyResultsRef.current.push(charModel);
      partyPositionsRef.current.push(charModel.basePosition.clone());
    });

    // 6. Monsters 3D Models (Middleground)
    const monsterGroup = new THREE.Group();
    scene.add(monsterGroup);
    monsterResultsRef.current = [];
    monsterPositionsRef.current = [];

    const totalMonsters = monsters.length;
    const spacing = totalMonsters === 1 ? 0 : 3.6;

    monsters.forEach((monster, idx) => {
      const posX = (idx - (totalMonsters - 1) / 2) * spacing;
      const posZ = -2.6; // In front of party
      const pos = new THREE.Vector3(posX, 0, posZ);
      monsterPositionsRef.current.push(pos);

      const result = createMonsterModel(monster.id, {
        isBoss: isBoss || monster.isBoss,
        isLastBoss: isLastBoss || monster.isFinalBoss,
        scale: monster.scale || 1.0,
        color: monster.spriteColor,
      });

      result.group.position.copy(pos);
      // Face towards party in south (+z)
      result.group.rotation.y = Math.PI;

      monsterGroup.add(result.group);
      monsterResultsRef.current.push(result);
    });

    // 7. Visual Effects Group (Slashes, magic rings, elemental sparks)
    const fxGroup = new THREE.Group();
    scene.add(fxGroup);
    fxGroupRef.current = fxGroup;

    // 8. 3D Target Marker (Glowing gold cone pointing down at selected monster)
    const targetMarkerGeo = new THREE.ConeGeometry(0.35, 0.7, 4);
    const targetMarkerMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const targetMarker = new THREE.Mesh(targetMarkerGeo, targetMarkerMat);
    targetMarker.rotation.x = Math.PI; // Point downwards
    scene.add(targetMarker);
    targetMarkerRef.current = targetMarker;

    // 9. Game Loop & DQ9 Battle Animations
    let animationFrameId: number;
    let clock = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      clock += 0.04;

      // Update Party animations (idle breathing / running attacks / 3D coffin if fallen)
      partyResultsRef.current.forEach((res, idx) => {
        const isHit = hitAllyIdx === idx;
        const isDead = (party[idx]?.hp ?? 0) <= 0;
        res.updateAnimation(clock, isHit, isDead);
      });

      // Update Monsters animations
      monsterResultsRef.current.forEach((res, idx) => {
        const m = monsters[idx];
        const isAlive = (m?.hp ?? 0) > 0;
        if (!isAlive) {
          // Death fall/sink
          res.group.position.y = THREE.MathUtils.lerp(res.group.position.y, -3.5, 0.08);
          res.group.scale.multiplyScalar(0.95);
          if (res.group.position.y < -3.0) res.group.visible = false;
          return;
        }

        res.group.visible = true;
        const isTargeted = idx === targetMonsterIdx;
        const isHit = idx === hitMonsterIdx;
        if (res.updateAnimation) {
          res.updateAnimation(clock + idx * 0.5, isHit, isTargeted);
        }
      });

      // Update 3D Target Marker position
      if (targetMarkerRef.current) {
        const targetPos = monsterPositionsRef.current[targetMonsterIdx];
        const curMonster = monsters[targetMonsterIdx];
        if (targetPos && curMonster && curMonster.hp > 0) {
          targetMarkerRef.current.visible = true;
          const heightOffset = isLastBoss || curMonster.isFinalBoss ? 5.8 : isBoss ? 4.2 : 2.6;
          targetMarkerRef.current.position.set(
            targetPos.x,
            heightOffset + Math.sin(clock * 5) * 0.2,
            targetPos.z
          );
          targetMarkerRef.current.rotation.y = clock * 3;
        } else {
          targetMarkerRef.current.visible = false;
        }
      }

      // Camera breathing / slight dynamic framing
      camera.position.x = Math.sin(clock * 0.4) * 0.15;
      camera.position.y = 4.4 + Math.cos(clock * 0.5) * 0.08;
      camera.lookAt(0, 1.6, 0);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      dispose();
    };
  }, [partyKey, monstersKey, backgroundTheme, isBoss, isLastBoss]);

  // Handle Party Member Attack Event (DQ9 Dash-up Animation!)
  useEffect(() => {
    if (!activeAttackEvent) return;

    const { charIdx, targetMonsterIdx: targetIdx, actionType } = activeAttackEvent;
    const attacker = partyResultsRef.current[charIdx];
    const targetPos = monsterPositionsRef.current[targetIdx] || new THREE.Vector3(0, 0, -2.6);

    if (attacker) {
      attacker.playAttackAnimation(
        targetPos,
        actionType,
        () => {
          // Trigger hit slash arc & sound
          if (onAttackHit) onAttackHit();
          createImpactEffect(targetPos, actionType);
        },
        () => {
          // Return complete
          if (onAttackComplete) onAttackComplete();
        }
      );
    }
  }, [activeAttackEvent]);

  // Handle Monster Counter-Attack Event (Lunge forward towards party!)
  useEffect(() => {
    if (!monsterAttackEvent) return;

    const { monsterIdx, targetCharIdx, actionType, actionName } = monsterAttackEvent;
    const monster = monsterResultsRef.current[monsterIdx];
    const targetPos = partyPositionsRef.current[targetCharIdx] || new THREE.Vector3(0, 0, 4.2);

    if (monster && monster.playAttackAnimation) {
      monster.playAttackAnimation(
        targetPos,
        actionType || 'attack',
        () => {
          if (onAttackHit) onAttackHit();
          createMonsterImpactEffect(targetPos, actionType || 'attack', actionName);
        },
        () => {
          if (onAttackComplete) onAttackComplete();
        }
      );
    }
  }, [monsterAttackEvent]);

  // Player Impact Visual Effect (Slash Arc or Magic Burst)
  const createImpactEffect = (targetPos: THREE.Vector3, type: 'attack' | 'spell' | 'skill') => {
    if (!fxGroupRef.current) return;
    const fx = fxGroupRef.current;

    if (type === 'spell') {
      // Magic blast burst
      const burstMat = new THREE.MeshBasicMaterial({
        color: 0x67e8f9,
        transparent: true,
        opacity: 0.9,
      });
      const sphere = new THREE.Mesh(new THREE.SphereGeometry(1.4, 10, 10), burstMat);
      sphere.position.set(targetPos.x, 1.8, targetPos.z);
      fx.add(sphere);

      setTimeout(() => {
        fx.remove(sphere);
      }, 350);
    } else if (type === 'skill') {
      // Cross-Slash in brilliant cyan & gold
      [-0.4, 0.4].forEach((rot, i) => {
        const slashMat = new THREE.MeshBasicMaterial({
          color: i === 0 ? 0x38bdf8 : 0xfacc15,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.95,
        });
        const slash = new THREE.Mesh(
          new THREE.RingGeometry(0.8, 1.6, 16, 1, 0, Math.PI * 0.85),
          slashMat
        );
        slash.position.set(targetPos.x, 1.8, targetPos.z + 0.6);
        slash.rotation.z = (i === 0 ? 1 : -1) * Math.PI * 0.35;
        fx.add(slash);

        setTimeout(() => {
          fx.remove(slash);
        }, 380);
      });
    } else {
      // Sweeping Golden Slash Arc
      const slashMat = new THREE.MeshBasicMaterial({
        color: 0xfef08a,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95,
      });
      const slash = new THREE.Mesh(
        new THREE.RingGeometry(0.8, 1.5, 16, 1, 0, Math.PI * 0.8),
        slashMat
      );
      slash.position.set(targetPos.x, 1.8, targetPos.z + 0.6);
      slash.rotation.z = Math.PI * 0.35;
      fx.add(slash);

      setTimeout(() => {
        fx.remove(slash);
      }, 300);
    }
  };

  // Monster Impact Visual Effect (Kafrizz/メラゾーマ pillar, Shockwave/しょうげきは, or dark slash)
  const createMonsterImpactEffect = (
    targetPos: THREE.Vector3,
    type: 'attack' | 'spell' | 'skill',
    actionName?: string
  ) => {
    if (!fxGroupRef.current) return;
    const fx = fxGroupRef.current;

    if (actionName?.includes('メラゾーマ')) {
      // メラゾーマ: Massive towering pillar of fiery red/crimson flame!
      const flameGroup = new THREE.Group();
      const fireMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
        transparent: true,
        opacity: 0.92,
      });
      const coreMat = new THREE.MeshBasicMaterial({
        color: 0xfbbf24,
        transparent: true,
        opacity: 0.95,
      });

      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 1.3, 4.5, 10), fireMat);
      pillar.position.set(targetPos.x, 2.2, targetPos.z);

      const core = new THREE.Mesh(new THREE.SphereGeometry(1.2, 8, 8), coreMat);
      core.position.set(targetPos.x, 1.6, targetPos.z);

      flameGroup.add(pillar, core);
      fx.add(flameGroup);

      setTimeout(() => {
        fx.remove(flameGroup);
      }, 550);
    } else if (actionName?.includes('しょうげきは') || type === 'skill') {
      // しょうげきは: Expanding circular shockwave ring sweeping across the party!
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x67e8f9,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.85,
      });
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.5, 2.8, 20), ringMat);
      ring.position.set(0, 1.2, targetPos.z);
      ring.rotation.x = Math.PI / 2;
      fx.add(ring);

      setTimeout(() => {
        fx.remove(ring);
      }, 450);
    } else {
      // Dark claw / slash impact on party member
      const clawMat = new THREE.MeshBasicMaterial({
        color: 0x9333ea,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9,
      });
      const claw = new THREE.Mesh(
        new THREE.RingGeometry(0.6, 1.2, 12, 1, 0, Math.PI * 0.6),
        clawMat
      );
      claw.position.set(targetPos.x, 1.4, targetPos.z - 0.4);
      claw.rotation.z = -Math.PI * 0.25;
      fx.add(claw);

      setTimeout(() => {
        fx.remove(claw);
      }, 300);
    }
  };

  return (
    <div className="relative w-full h-full select-none overflow-hidden">
      <div ref={mountRef} className="w-full h-full" />
    </div>
  );
};
