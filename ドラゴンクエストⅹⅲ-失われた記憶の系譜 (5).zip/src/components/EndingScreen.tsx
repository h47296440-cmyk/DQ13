import React, { useEffect, useState } from 'react';
import { dqAudio } from '../audio/dqAudio';

interface EndingScreenProps {
  heroName: string;
  onRestart: () => void;
}

export const EndingScreen: React.FC<EndingScreenProps> = ({ heroName, onRestart }) => {
  const [slideIdx, setSlideIdx] = useState<number>(0);

  const endingSlides = [
    `大魔王ネビュロスは崩壊し、
100年もの間、世界を覆っていた忘却の霧が晴れ渡った。`,
    `大聖堂の鐘が、今までにない澄んだ音色で鳴り響く。
人々は、悲しみや悔しさの記憶を抱きしめた。
「辛い思い出だけど……忘れてはいけなかったんだ。」
人は傷を負うからこそ、他人の痛みに優しくなれる。`,
    `失恋の痛みを乗り越え、再び手を取り合ったバーレンの恋人たち。
敗北を悔しさとして受け止め、民と共に立ち上がったガルガルド王。
戦友の笑顔を思い出し、涙を浮かべたヤンセン。
失われた真実の歴史を紡ぎ始めたシエラ。`,
    `そして、${heroName}は故郷の「ココヤしの村」へと帰還した。
村の広場には……`,
    `「――${heroName}！！」
そこには、笑顔で手を振る幼馴染エリーナの姿があった。
黒い影となって消えていた人々が、温かな体温を取り戻し、
この世界に帰ってきたのだ。`,
    `「${heroName}は　ついに
　ほんとうの平和を　とりもどした！」`,
  ];

  useEffect(() => {
    dqAudio.playBgm('ending');
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === 'Enter' ||
        e.key === ' ' ||
        e.key === 'z' ||
        e.key === 'Z' ||
        e.key === 'ArrowRight' ||
        e.key === 'ArrowDown'
      ) {
        e.preventDefault();
        if (slideIdx < endingSlides.length - 1) {
          dqAudio.playConfirm();
          setSlideIdx(prev => prev + 1);
        } else {
          dqAudio.playConfirm();
          onRestart();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [slideIdx, endingSlides.length, onRestart]);

  const handleNext = () => {
    if (slideIdx < endingSlides.length - 1) {
      dqAudio.playConfirm();
      setSlideIdx(prev => prev + 1);
    }
  };

  return (
    <div
      onClick={handleNext}
      className="relative w-full h-full flex flex-col items-center justify-center bg-black text-white select-none overflow-hidden p-6 cursor-pointer"
    >
      {/* Background with dramatic lighting */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-40"
        style={{ backgroundImage: `url('/src/assets/images/dq13_title_art_1790826606946.jpg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/90" />

      {/* Slide Box */}
      <div className="relative z-10 max-w-2xl w-full">
        {slideIdx < endingSlides.length ? (
          <div className="dq-window p-8 min-h-[260px] flex flex-col justify-between shadow-2xl animate-fade-in">
            <div className="text-lg md:text-xl leading-relaxed tracking-widest whitespace-pre-line text-amber-200">
              {endingSlides[slideIdx]}
            </div>

            <div className="self-end text-amber-400 text-sm font-bold dq-cursor mt-6">
              ▼ 次へ (画面クリック / Enter)
            </div>
          </div>
        ) : null}

        {/* Final Staff Roll when finished */}
        {slideIdx === endingSlides.length - 1 && (
          <div className="mt-8 text-center flex flex-col items-center gap-4 animate-fade-in">
            <div className="text-2xl font-black text-amber-400 tracking-widest">
              ドラゴンクエストⅩⅢ　失われた記憶の系譜
            </div>
            <div className="text-sm text-white/80">
              THE END
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onRestart();
              }}
              className="mt-4 px-8 py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold text-base rounded shadow-lg active:scale-95"
            >
              タイトル画面にもどる
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
